<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="b97eed75f-621b-2436-a0a2-6dd7e5bd9a98">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-29</creationDate>
            <imgeo:LV-publicatiedatum>2024-08-01T16:29:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-07-29T12:13:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.79460faff7ee4c5f826d2297affc2f48</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">fontein</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171061.501 558367.461</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="bba6b0eed-e873-bb3f-e43a-37cfc08d7b31">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-09-27T14:17:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T13:11:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.126508f1d663451eb8f4859ca651785f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172619.948 559578.041</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="b9c863734-1eb5-9ffe-bac4-439da7dcf6c8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-09-27T14:18:33</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T13:12:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.491e1f91791b465188b3394b76fce097</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172667.432 559570.647</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="b04fce3c2-3af0-e47f-9fa0-8c33ad812a38">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-09-27T14:21:02</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T13:12:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ed256f690d31445687d4dd6551f9f359</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172761.203 559564.160</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="b9f3be388-6e47-a759-9be6-2dd00c2d4173">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-09-27T14:17:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.126508f1d663451eb8f4859ca651785f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172619.896 559578.047</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="baa812817-892e-b6eb-ff53-049ffdf4310d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-09-27T14:18:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.491e1f91791b465188b3394b76fce097</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172667.505 559570.564</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Straatmeubilair gml:id="b0e5fd41c-072b-2c7b-0c0b-0b9c4c6cba82">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-09-27T14:21:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ed256f690d31445687d4dd6551f9f359</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilair">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeStraatmeubilairPlus">bank</imgeo:plus-type>
            <imgeo:geometrie2dStraatmeubilair><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172761.234 559564.157</gml:pos></gml:Point></imgeo:geometrie2dStraatmeubilair>
        </imgeo:Straatmeubilair>
    </cityObjectMember>
</CityModel>