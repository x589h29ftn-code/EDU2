<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b0a01e9cf-5961-7180-a578-e4797ab01224">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-04</creationDate>
            <imgeo:LV-publicatiedatum>2019-05-23T15:03:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-03-04T15:19:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2571d399d5de417db57ae3e7be2e6e2e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171023.682 558273.790 171024.346 558268.767 171012.504 558267.050 171011.504 558266.922 171011.649 558265.927 171011.710 558265.763 171011.834 558265.639 171011.999 558265.578 171012.174 558265.593 171024.035 558267.322 171025.718 558267.595 171024.769 558273.968 171023.682 558273.790</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bdc9cdccd-0c42-b11c-ad07-3ebd3d541c00">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-04</creationDate>
            <imgeo:LV-publicatiedatum>2019-05-23T15:03:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-03-04T15:19:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2ad9dd39924c463b83afe2d8688e4249</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171021.335 558289.591 171022.802 558279.638 171023.896 558279.824 171022.416 558289.763 171021.335 558289.591</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b689af2c0-4d3a-88a6-cee9-018e9ffc3815">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-04</creationDate>
            <imgeo:LV-publicatiedatum>2019-05-23T15:03:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-03-04T15:19:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5d99d089ac5447219dcf53389e172e7e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171019.004 558305.398 171020.483 558295.453 171021.544 558295.615 171020.062 558305.559 171018.500 558316.047 171017.488 558315.899 171018.158 558311.176 171019.004 558305.398</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5ee1d04f-d57b-b3d2-1b06-5bdac5578e8d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:12:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0af81978851545ed806cf974fb17d2ea</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171087.217 558320.742 171097.278 558322.164 171097.148 558323.026 171052.544 558316.529 171049.551 558316.093 171049.678 558315.117 171050.571 558315.238 171050.534 558315.568 171052.349 558315.824 171087.217 558320.742</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd06adc83-49fa-3000-17e4-f90aced1442a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:12:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1087751709d24c34a810f14494fb6767</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171053.805 558292.681 171050.848 558313.310 171049.894 558313.175 171052.819 558292.558 171053.805 558292.681</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b53ad0a1c-f1a5-ee64-6f31-b9fdb0c3be20">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:12:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.27ff1f01b8074da3ba9c308f913fc26f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171002.387 558235.387 171010.757 558236.604 171010.626 558237.425 171002.269 558236.206 171002.387 558235.387</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b460ba208-2f15-19b9-649e-f12db5917caa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:12:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.87147b8f6bc343198b7ca8d55d0e8d80</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171057.827 558265.662 171057.200 558270.463 171054.251 558289.528 171053.267 558289.402 171055.380 558272.883 171057.935 558256.418 171058.995 558256.545 171059.094 558256.559 171058.958 558257.514 171057.827 558265.662</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b47620fc8-8bd0-68af-8a30-f6d77f8dde3e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:25:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.969c744e86864799849934cbe84f0639</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171119.064 558454.147 171121.919 558456.796 171122.029 558456.898 171122.230 558456.590 171123.782 558458.064 171123.868 558458.145 171123.501 558458.850 171123.257 558459.318 171114.140 558450.840 171110.457 558447.422 171111.006 558446.672 171119.064 558454.147</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b63cc6a34-7798-f61d-7c70-0a9e1d760363">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:12:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bd7dfb3323fa4a4195d769f6b8721dab</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171058.054 558250.567 171057.911 558251.595 171053.039 558255.293 171052.648 558254.884 171052.162 558254.434 171051.650 558254.014 171051.113 558253.626 171050.554 558253.271 171049.974 558252.950 171049.376 558252.665 171048.763 558252.417 171048.135 558252.206 171047.538 558252.043 171043.839 558251.300 171042.861 558251.102 171041.521 558250.865 171041.341 558250.823 171041.173 558250.747 171041.023 558250.639 171040.897 558250.504 171040.872 558250.470 171040.782 558250.309 171040.725 558250.133 171040.703 558249.950 171040.714 558249.815 171040.718 558249.765 171040.733 558249.695 171040.900 558248.245 171048.845 558249.318 171057.670 558250.515 171058.054 558250.567</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="baa7d3217-123a-056c-36e3-5613cb62faf2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-01</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-01T13:25:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cf6f79a6e0024f0882c68d5d34b9d602</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171108.213 558445.340 171093.750 558431.920 171091.571 558429.930 171091.737 558429.938 171091.687 558428.536 171104.145 558440.308 171110.050 558445.786 171109.496 558446.530 171108.213 558445.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd26d5857-6b35-43f7-76fe-bf34c953bb2a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-02-26</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-04-22</terminationDate>
            <imgeo:LV-publicatiedatum>2024-03-01T11:34:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-04-22T13:22:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-02-26T13:09:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.84b54b10c71b46ddaee2c15590baeae9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171257.490 558100.756 171257.665 558100.788 171257.901 558100.832 171260.482 558101.331 171260.747 558101.380 171260.801 558101.467 171260.926 558101.563 171261.076 558101.728 171261.169 558101.891 171261.229 558102.060 171261.250 558102.192 171261.266 558102.294 171261.248 558102.521 171260.737 558105.257 171256.265 558104.368 171256.752 558101.626 171256.827 558101.448 171256.904 558101.264 171257.150 558101.006 171257.294 558100.920 171257.376 558100.845 171257.490 558100.756</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b079e8fe4-ea51-c5c2-1cb1-0a95fcaf28e9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-02-26</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-04-22</terminationDate>
            <imgeo:LV-publicatiedatum>2024-05-06T15:58:46</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-04-22T13:22:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-02-26T13:09:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.84b54b10c71b46ddaee2c15590baeae9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171257.490 558100.756 171257.665 558100.788 171257.901 558100.832 171260.482 558101.331 171260.747 558101.380 171260.801 558101.467 171260.926 558101.563 171261.076 558101.728 171261.169 558101.891 171261.229 558102.060 171261.250 558102.192 171261.266 558102.294 171261.248 558102.521 171260.737 558105.257 171256.265 558104.368 171256.752 558101.626 171256.827 558101.448 171256.904 558101.264 171257.150 558101.006 171257.294 558100.920 171257.376 558100.845 171257.490 558100.756</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b611688ab-15e8-a013-baaa-910544f3e7f0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-02-29</creationDate>
            <imgeo:LV-publicatiedatum>2024-03-01T11:34:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-02-29T13:56:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2d4cb7d9534e4bbe9a46090464fe7f6f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170291.879 558372.298 170286.167 558387.544 170282.376 558386.707 170278.755 558396.862 170277.360 558397.160 170281.664 558384.722 170285.280 558385.620 170285.480 558385.630 170285.650 558385.600 170285.750 558385.500 170290.397 558372.483 170291.879 558372.298</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b57407890-f84d-97ee-8377-da0a1337d87c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-02-29</creationDate>
            <imgeo:LV-publicatiedatum>2024-03-01T11:34:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-02-29T13:56:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f49f8b8c66cd467a98c6128d3e9904c7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170299.167 558335.987 170303.147 558337.715 170303.771 558339.086 170295.293 558362.523 170292.383 558371.306 170290.961 558370.901 170302.550 558338.430 170302.510 558338.260 170302.280 558338.210 170298.741 558337.288 170299.167 558335.987</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7e1d9e7c-89d2-dfa1-0744-402b482b1da9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2017-11-01T10:21:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T15:03:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.341bb08dae734bb69f17d1d91aaf6754</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171926.966 559908.202 171927.172 559907.747 171929.037 559908.586 171930.880 559909.210 171933.836 559910.339 171935.246 559911.336 171935.033 559911.677 171933.614 559910.790 171930.765 559909.702 171928.955 559909.086 171926.966 559908.202</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bdb4b2a5d-8ed0-c167-a36c-80288f42be6b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2017-11-01T10:21:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-01-24T07:07:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-24T15:03:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.623eb94038ad4d9a9c5457179a32f55e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171847.102 559936.540 171851.077 559936.739 171854.314 559937.365 171857.153 559938.417 171860.176 559940.293 171862.051 559941.751 171863.616 559943.213 171864.980 559944.786 171866.018 559946.343 171865.602 559946.620 171864.582 559945.090 171863.379 559943.702 171862.098 559942.480 171860.093 559940.862 171856.932 559938.868 171854.178 559937.848 171851.017 559937.236 171846.937 559937.032 171842.449 559937.848 171820.011 559950.496 171819.765 559950.060 171842.277 559937.372 171846.904 559936.530 171847.102 559936.540</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6a65e60c-0a14-66fc-9680-0a1b41e8037c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2017-11-01T10:21:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T15:03:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a107bd61c6db4027a0e994c645f96bb7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171954.617 559930.944 171955.038 559930.673 171957.781 559934.941 171960.628 559940.227 171960.187 559940.464 171957.350 559935.195 171954.617 559930.944</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd6d7df56-7bc1-cd7e-00c5-09e88cddb821">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:39:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9e52ac77b7874af4bf8718c9f428c1bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172002.690 559308.930 172000.486 559311.823 171999.448 559313.320 171998.489 559314.697 171997.491 559316.254 171996.393 559317.711 171995.555 559319.148 171994.617 559320.406 171992.820 559323.480 171991.773 559325.156 171991.762 559325.174 171991.509 559325.022 171992.550 559323.180 171993.490 559321.620 171994.370 559320.200 171995.230 559318.940 171996.150 559317.480 171997.230 559315.960 171998.210 559314.460 171999.190 559313.040 172000.000 559311.900 172000.250 559311.560 172001.170 559310.240 172002.349 559308.675 172002.690 559308.930</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b184f77cb-d6b1-892b-98d9-2bfb9283d86d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-23</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-23T16:14:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.00fb78193c084604ba6986766f03987f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170564.401 558291.698 170570.639 558293.798 170565.071 558311.537 170564.506 558311.335 170569.890 558294.179 170564.216 558292.269 170564.401 558291.698</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bcb9c8188-e24e-a945-1bab-336544f2272a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-24T10:02:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.44212c9edb93465ca40d36b0f8463fc5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170908.334 558208.146 170901.525 558226.421 170900.905 558226.148 170907.693 558207.929 170908.334 558208.146</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b48e09064-3658-cd1f-431b-e20ce15163bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-23</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-23T16:14:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5f8dc2d7b06d4e61b563aef9bc8380fc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170553.113 558328.241 170558.652 558329.973 170564.077 558312.697 170564.644 558312.893 170559.045 558330.725 170556.444 558329.912 170552.944 558328.817 170553.113 558328.241</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bcf82efd2-da4e-b2fe-18c3-a2536c0636e5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-24T10:02:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.74b7c5731a0147e58ba02886b6f08c30</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170900.209 558228.011 170900.828 558228.216 170891.210 558253.718 170890.406 558254.006 170900.209 558228.011</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b17355072-5ccf-d5b2-24a3-33b85d061629">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-23</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-23T19:05:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.93bd525f1450481ab63d58d29d2c4e65</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170834.116 558349.080 170833.399 558349.687 170841.573 558361.213 170842.881 558360.150 170854.979 558377.888 170853.753 558379.196 170854.162 558379.932 170857.846 558377.432 170858.170 558377.819 170854.152 558380.625 170853.083 558379.010 170854.470 558377.840 170850.900 558372.480 170846.530 558365.950 170842.880 558360.700 170841.480 558361.830 170832.906 558349.588 170833.883 558348.814 170834.116 558349.080</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3212298b-b55f-4dca-2933-01c0c6d183e6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-24T10:23:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.faa6b4704dc342deaafeed7079127bed</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171038.278 558276.836 171032.904 558312.959 171032.920 558313.079 171032.984 558313.181 171033.179 558313.268 171037.386 558313.906 171037.502 558313.949 171037.602 558314.020 171037.700 558314.152 171037.741 558314.268 171037.746 558314.432 171037.597 558315.508 171037.555 558315.609 171037.489 558315.695 171037.336 558315.791 171037.193 558315.815 171037.085 558315.800 171032.746 558315.181 171032.593 558315.270 171032.544 558315.421 171027.455 558348.885 171026.152 558348.674 171031.242 558315.135 171031.151 558314.972 171031.014 558314.921 171026.440 558314.252 171026.282 558314.164 171026.210 558314.081 171026.163 558313.982 171026.143 558313.874 171026.167 558313.715 171026.314 558312.657 171026.356 558312.543 171026.427 558312.444 171026.593 558312.329 171026.791 558312.295 171026.911 558312.317 171031.344 558312.987 171031.542 558312.894 171031.617 558312.689 171037.089 558276.628 171038.278 558276.836</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9f5d68d9-023a-678e-83ca-80f86be30a74">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T09:41:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.00ff833a257a49058e3705642c8a54d8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171135.056 558346.081 171097.398 558339.616 171100.774 558319.894 171101.267 558319.978 171097.976 558339.207 171135.140 558345.588 171135.056 558346.081</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4c819c0b-03ad-26e5-6b62-6f427c6ec7dc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T09:47:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b2ea2d2c25244ea48407d9f904473db1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170892.995 558257.538 170893.427 558257.682 170891.168 558263.688 170898.691 558266.504 170896.806 558271.390 170896.292 558271.196 170897.978 558266.824 170890.544 558264.044 170891.483 558261.552 170892.995 558257.538</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="baf14f570-079b-52e4-6549-5986b7565643">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T09:47:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b6423de1215b45a1a9ec668e3ec12dd9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170899.784 558240.869 170899.784 558240.871 170895.978 558250.920 170895.536 558250.788 170899.335 558240.700 170899.784 558240.869</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b73ed25fd-a856-aaa6-191c-2eca4d6fb7f7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T09:41:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cca34435d89e4bb5afbb8575f0470724</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171101.296 558317.966 171111.503 558256.120 171111.996 558256.203 171101.790 558318.046 171101.296 558317.966</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b859c8fe4-f252-7961-1268-945b913e36e5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T10:00:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d3599b0fc9744d1a8f505bba7de30020</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171016.490 558236.850 171029.116 558238.796 171025.922 558258.714 171025.675 558258.674 171025.485 558258.640 171028.586 558239.163 171016.428 558237.299 171016.490 558236.850</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b83a8f12f-5150-a709-1d70-ace0fc7056d0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-23T09:10:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T10:00:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dd805197f0d64ecf8b1e9ef59a31960f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170972.052 558240.063 170972.086 558239.748 170986.478 558241.818 170987.960 558232.383 170997.346 558233.838 170997.270 558234.381 170988.182 558232.977 170986.723 558242.219 170972.052 558240.063</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b02bf2923-259d-6866-24c6-f4cdc87d1a69">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2018-06-14T14:27:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-19T11:44:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3cecd0df01d549eb8cf41c4a787ae7dc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171058.199 558035.820 171057.597 558037.342 171056.678 558036.964 171057.332 558035.421 171058.199 558035.820</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b53bac3da-8268-4b58-09a4-68f14789c927">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2018-06-14T14:27:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T12:26:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.63225b15c9e84e4aaeebda159c5018fe</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171062.981 558017.339 171063.537 558017.621 171062.716 558021.741 171062.271 558023.972 171061.756 558026.556 171061.551 558027.583 171061.363 558028.527 171060.717 558031.769 171060.156 558031.512 171062.981 558017.339</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3b872ae9-dd10-d0f1-2da5-bf491437bd8c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2018-07-17T16:30:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:30:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.502edec972a44dce8c8eed54010610a4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170557.705 558290.308 170549.991 558315.290 170540.200 558313.283 170540.320 558312.797 170549.647 558314.709 170557.123 558290.497 170557.287 558289.995 170557.705 558290.308</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3ab2c394-63ab-078c-7636-f4e186e57144">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2018-07-17T16:30:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T13:37:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e18c41cf69a4426988b79508b85e031e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170577.578 558431.528 170580.293 558434.033 170583.020 558434.576 170584.872 558432.470 170583.983 558429.838 170581.413 558427.514 170581.763 558427.147 170584.415 558429.555 170585.438 558432.583 170583.205 558435.123 170580.057 558434.496 170577.228 558431.893 170577.578 558431.528</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf0078643-c4bd-8600-88cb-064a670b2c5d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.164c07e1cc014983b97c228fa487be3c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170823.013 558161.784 170823.947 558163.596 170822.383 558164.382 170821.419 558162.511 170823.013 558161.784</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="beaf17173-bb91-4a71-f4d9-28db10f18ec0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2938961e516843e3a1bed38366d0f3a1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170814.050 558180.815 170812.537 558181.488 170811.857 558179.930 170813.364 558179.259 170814.050 558180.815</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5fb52340-ca93-60a5-8a9b-93bec060879d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T13:17:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.381f6845430b49ee8b5849b04b425ca3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170863.796 558384.495 170859.963 558387.394 170861.720 558391.756 170862.010 558393.307 170862.127 558395.596 170861.430 558396.440 170861.287 558393.339 170860.462 558390.346 170859.164 558387.926 170858.995 558387.610 170858.924 558387.508 170862.787 558384.476 170863.381 558384.010 170863.796 558384.495</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf2b35ff1-b640-2ba7-4657-57f9d11be7b1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.394e697d790549be9969603b926e77e0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170808.118 558168.000 170808.913 558170.036 170807.283 558170.674 170806.484 558168.626 170808.118 558168.000</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5798ed6e-dbd7-d218-5a2e-e32fa1ee7591">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-21</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-21T09:05:10.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4836aad52bfb42128b3bf6c0b4616fad</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170907.206 558114.302 170906.913 558115.817 170905.970 558115.640 170905.936 558115.823 170886.386 558112.606 170886.444 558112.424 170886.552 558111.890 170888.523 558111.951 170892.781 558112.323 170902.463 558113.675 170907.206 558114.302</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4a9c6d6d-7d65-7453-d3e2-5fbacf5baf0b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4c3cc3d4e63f46c2b4ee3174092ecc08</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170790.574 558191.225 170789.862 558189.681 170791.421 558188.966 170792.123 558190.514 170790.574 558191.225</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf8299f18-d4bd-2921-4b76-2ffedf2d98bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-19T12:19:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4d64bc4908ea498d8ff14f411df1407e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170866.472 558043.075 170868.669 558043.494 170871.138 558035.555 170874.824 558036.640 170875.320 558036.710 170875.211 558037.275 170871.469 558036.174 170869.014 558044.069 170866.377 558043.566 170866.472 558043.075</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8e765f8a-0a69-5a0b-433f-d510258dbbbc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.653ccdbce0684912b86ea1712e1ea2bf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170784.212 558177.164 170785.846 558176.537 170786.632 558178.553 170784.985 558179.147 170784.212 558177.164</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b09f4bbb6-f68e-023a-d964-06e03a86f82e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6940195891c84539ae96bef246b4dd7b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170776.370 558180.151 170778.005 558179.530 170778.735 558181.401 170777.089 558181.995 170776.370 558180.151</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba83e616c-7545-4583-adaf-037f5951313d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6ab1d5365524410ab02886c7c8c82aeb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170769.229 558201.886 170768.468 558200.365 170769.971 558199.614 170770.749 558201.126 170769.229 558201.886</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1877f606-00ed-e083-2c02-dd28c9ad2b6d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-19T12:19:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7ea995ecd8ae450ebea283a96e0b7c11</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170874.151 558019.361 170878.692 558020.712 170878.695 558020.713 170878.592 558021.196 170878.097 558021.057 170873.997 558019.837 170874.151 558019.361</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b666ade86-8dc0-737b-ef2e-984269f8ce44">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.809604be8276407396a7badeec2affc5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170769.203 558182.779 170770.848 558182.180 170771.542 558183.959 170769.890 558184.541 170769.203 558182.779</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bfdd3ac81-f775-69af-b81e-5d2fcdae075c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.83e7795a2a5d49f29eceb2f8cee54d49</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170800.909 558170.763 170801.723 558172.849 170800.086 558173.468 170799.275 558171.390 170800.909 558170.763</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5ece8fcb-7e09-bef7-dae9-c0b5e199f8f1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9e97c9a8cded41df9b6a9d36f390358f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170783.451 558194.603 170782.680 558193.088 170784.232 558192.296 170784.976 558193.825 170783.451 558194.603</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7446c732-ad9b-0b54-baf7-93372e31d939">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a9e74babc3f946f6b2c45221bc750387</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170799.427 558187.246 170797.853 558187.940 170797.161 558186.387 170798.743 558185.689 170799.427 558187.246</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="be95cfb5a-6b4c-7623-7235-ad7c6d125892">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cc87918115954376bdd56fc74e0837c0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170816.170 558164.905 170816.949 558166.893 170815.319 558167.530 170814.538 558165.539 170816.052 558164.959 170816.170 558164.905</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b48d76ceb-a6e3-4e63-3873-cfa8ddfbbe23">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cda73911c8e2469f8c18564c780d8f01</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170821.409 558177.585 170819.868 558178.271 170819.182 558176.716 170820.714 558176.033 170821.409 558177.585</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b29de8c42-9f2a-5da5-b3e7-e5aa60408ecf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cfecd53b44044a6aa46330fc143cd28e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170776.308 558198.182 170775.545 558196.662 170777.117 558195.915 170777.867 558197.441 170776.308 558198.182</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8b34027c-eccb-9c96-bb0f-9e1c1f505d7c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-03-13T11:58:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d2ff3104c4cb46abbb13b5c88ab429b4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170791.743 558174.277 170793.377 558173.650 170794.177 558175.701 170792.540 558176.320 170791.743 558174.277</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5cd5798c-bce9-fdec-3e81-f13ed0811501">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e7793507178d4fc1a5d4a54fa739aea8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170806.754 558183.962 170805.201 558184.724 170804.486 558183.181 170806.045 558182.416 170806.754 558183.962</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b64f82ce6-8583-d0c8-bc23-898f0a07f1c3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-08</creationDate>
            <imgeo:LV-publicatiedatum>2020-09-15T11:37:32</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-08T13:34:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a67e4a9f5af5411ebddb6f5f000acf69</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170788.255 558124.909 170769.728 558138.861 170757.435 558122.317 170757.669 558121.580 170757.701 558121.627 170769.927 558137.686 170787.887 558124.593 170788.255 558124.909</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf7666f7e-d9bb-5d4c-f3ff-dcd0dad982fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-07-17T16:30:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-14T10:17:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-03-13T13:37:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9a065f0ead2541138b4a70f37cee43e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170574.598 558428.798 170576.091 558430.158 170575.748 558430.532 170574.633 558429.506 170574.247 558429.187 170574.598 558428.798</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf4fd7191-e266-9a62-20e9-22c09fe1e05b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-03-15T20:27:10</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-14T10:17:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-03-13T13:37:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9a065f0ead2541138b4a70f37cee43e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170574.598 558428.798 170576.091 558430.158 170575.748 558430.532 170574.633 558429.506 170574.247 558429.187 170574.598 558428.798</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="be516239b-ab03-4c54-3e92-94888660ea5a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-07</terminationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-07T16:21:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a656323f72f84cbf80d3f260034bef9d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170828.762 558174.371 170827.120 558175.009 170826.378 558173.587 170827.996 558172.869 170828.762 558174.371</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4c582ef0-0e87-c990-f0d7-f38726447479">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-07</terminationDate>
            <imgeo:LV-publicatiedatum>2024-03-15T20:27:10</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-07T16:21:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T14:07:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a656323f72f84cbf80d3f260034bef9d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170828.762 558174.371 170827.120 558175.009 170826.378 558173.587 170827.996 558172.869 170828.762 558174.371</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3e677213-be0a-ee70-2458-d7ae791cd735">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-07-17T16:30:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-14T10:17:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-03-13T13:37:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e59f2200507747789dd86f223f279698</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170578.704 558424.363 170579.071 558424.703 170580.170 558425.701 170579.827 558426.077 170578.370 558424.738 170578.704 558424.363</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bdf5ab159-b313-8d2d-eca8-c956966246da">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-03-15T20:27:10</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-03-14T10:17:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-03-13T13:37:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e59f2200507747789dd86f223f279698</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170578.704 558424.363 170579.071 558424.703 170580.170 558425.701 170579.827 558426.077 170578.370 558424.738 170578.704 558424.363</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bae99146f-8671-8c80-5eaa-c2a3af1bb855">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-03-21</creationDate>
            <imgeo:LV-publicatiedatum>2024-03-25T16:44:33</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-03-21T16:51:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8c41062a1f34463cb40d01cd8a99bb72</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170828.762 558174.371 170827.120 558175.009 170826.378 558173.587 170827.996 558172.869 170828.762 558174.371</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6c3a9340-a46d-c4a6-8eb8-fecf25edfce3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-07T12:36:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-24T07:07:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.623eb94038ad4d9a9c5457179a32f55e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171849.270 559935.941 171852.877 559936.523 171856.213 559937.415 171858.501 559938.578 171862.497 559941.061 171864.630 559943.039 171866.259 559945.172 171866.686 559945.987 171866.018 559946.343 171865.602 559946.620 171864.582 559945.090 171863.379 559943.702 171862.098 559942.480 171860.093 559940.862 171856.932 559938.868 171854.178 559937.848 171851.017 559937.236 171846.937 559937.032 171842.449 559937.848 171820.011 559950.496 171819.765 559950.060 171819.442 559949.439 171832.742 559942.040 171841.473 559937.182 171844.421 559936.290 171849.270 559935.941</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bc8acf584-6b8b-6ba3-c8ba-c45352dfe828">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e27b5f9e03e42328c130a3c27f5afaa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173788.211 559995.150 173789.471 559993.343 173789.881 559993.629 173788.621 559995.436 173788.211 559995.150</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6eb57830-b87a-5f93-78f7-f3a07d27599a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d47bcd6407e94319a43f9cbc3d9d41fc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173783.533 560001.806 173786.705 559997.289 173787.114 559997.576 173783.942 560002.094 173783.533 560001.806</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b17417012-7bda-d503-9240-93049383d34f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f9424680deed4557a07007a28b733a38</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173791.234 559990.608 173792.870 559988.144 173793.286 559988.420 173791.651 559990.884 173791.234 559990.608</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf5e7f1ac-6fe8-84f5-502c-ae1ffa164d50">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c856305c1fd944c1bd1d1b74a3db5867</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173802.386 559975.452 173801.442 559976.900 173800.332 559978.554 173800.012 559978.343 173802.101 559975.260 173802.386 559975.452</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b31405ff6-76b5-741d-0bf1-df9a4fe5110f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dcb8e1dc5cf348948380294bd0f2115e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173810.256 559963.388 173808.644 559965.853 173804.215 559972.646 173804.193 559972.633 173803.775 559972.359 173809.848 559963.119 173810.256 559963.388</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1bfaf41a-a9b8-6b03-5ff1-6922636ff1ec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5578f7403f404edebe2d29b6b7d28d11</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173813.232 559957.801 173813.977 559956.609 173814.401 559956.874 173813.656 559958.066 173813.232 559957.801</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b911bbf91-8fbd-896f-0271-47b02cc3f024">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.af08356ba9a84ccead5b5742fa5623cb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173822.941 559943.988 173817.225 559952.730 173817.195 559952.701 173816.781 559952.421 173822.587 559943.696 173822.630 559943.778 173822.941 559943.988</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9b455f1a-5fdd-539a-aa06-453517b51f24">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.de864b1406d84d6381e7c77607f3540b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173836.026 559918.171 173800.550 559894.119 173800.432 559894.045 173800.587 559893.690 173801.869 559894.414 173839.169 559919.699 173838.863 559920.145 173837.432 559922.234 173837.077 559921.962 173838.607 559919.967 173838.630 559919.937 173836.026 559918.171</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b86317d28-06ed-a4b9-2992-3da6c965a7fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7ef5693b4be24a2e93ee3436c84c9d5e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173835.384 559925.224 173831.578 559930.780 173829.535 559933.905 173829.149 559933.645 173834.998 559924.965 173835.384 559925.224</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bdf6ee0fb-fbc6-693a-7e7d-a15267ddceba">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7f7470dec0684c3790da58613034dc90</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173853.189 559988.707 173855.079 559985.891 173855.494 559986.170 173853.604 559988.986 173853.189 559988.707</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bfc5d03bf-8dca-d20d-a2b3-fb3f371dfad7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7f7470dec0684c3790da58613034dc90</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173853.189 559988.707 173855.079 559985.891 173855.494 559986.170 173853.604 559988.986 173853.189 559988.707</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bcdb4730d-f110-30af-cb1b-c93b904e3303">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T07:43:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e057d1dde19b441684a707e7dc2a8992</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173826.423 559938.663 173825.890 559939.479 173825.558 559939.129 173826.116 559938.421 173826.423 559938.663</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bfe963b6d-636c-c7a5-da0c-8d35aad247ae">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1bea0f21e01548e08585fdaff8793ac3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173856.884 560002.279 173856.627 560005.335 173855.985 560006.515 173855.881 560006.447 173855.446 560006.200 173855.897 560005.406 173856.119 560004.842 173856.258 560003.898 173856.241 560002.757 173855.870 560001.466 173855.198 560000.050 173852.846 559997.607 173852.025 559996.556 173851.559 559995.333 173851.353 559993.574 173851.850 559993.516 173851.946 559993.505 173851.960 559994.041 173852.285 559995.550 173853.010 559996.983 173853.660 559997.709 173854.710 559998.645 173855.749 559999.656 173855.898 560000.000 173856.884 560002.279</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8f95ed2c-57da-3245-25dd-0da2111d98ce">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.96820f50b02e4a68b1d676df30c74d9e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173872.160 559960.509 173875.192 559956.022 173875.606 559956.302 173872.574 559960.789 173872.160 559960.509</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bc8ba715e-4114-3a16-f97e-885d511404f4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.96820f50b02e4a68b1d676df30c74d9e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173872.160 559960.509 173875.192 559956.022 173875.606 559956.302 173872.574 559960.789 173872.160 559960.509</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7e2dd149-79fc-fe34-a2ce-e15b893e16cd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.337fc1def82b4bd1b8d21c4db4f222c9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173865.859 559969.824 173868.175 559966.312 173868.592 559966.587 173866.277 559970.099 173865.859 559969.824</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bedb16e2a-714a-6cda-812a-62a333feaed0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.337fc1def82b4bd1b8d21c4db4f222c9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173865.859 559969.824 173868.175 559966.312 173868.592 559966.587 173866.277 559970.099 173865.859 559969.824</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b85eb0c05-5d7c-b44a-af0a-bfb45ad6d503">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:14</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.25036fad0c3d4f5aa884b32c21a7c533</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173858.678 559980.316 173861.636 559976.106 173862.046 559976.393 173859.087 559980.603 173858.678 559980.316</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b40bb0c8d-6c4f-e792-80a6-004b2c6a9d03">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-13</terminationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-13T11:45:14</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T08:05:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.25036fad0c3d4f5aa884b32c21a7c533</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173858.678 559980.316 173861.636 559976.106 173862.046 559976.393 173859.087 559980.603 173858.678 559980.316</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8fe5907f-dc5b-779a-43a8-56c5a89a30c4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.00c00bbea6fd4bcb98569e9ae938d2ff</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173903.668 559946.096 173903.809 559945.893 173913.388 559952.532 173913.248 559952.734 173913.103 559952.943 173903.524 559946.304 173903.668 559946.096</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b15ca5e36-aa9f-d9dd-0da0-ef722d188464">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d4122ecc719448e299b6d58c6c374095</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173914.010 559953.261 173914.149 559953.060 173922.620 559958.930 173922.481 559959.131 173922.335 559959.341 173913.864 559953.471 173914.010 559953.261</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bae243509-b710-fd32-6535-8814425b85be">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.46c5df0458a44178a173cb1509e5d513</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173900.329 559943.786 173900.471 559943.581 173903.127 559945.421 173902.987 559945.624 173902.843 559945.832 173900.187 559943.991 173900.329 559943.786</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bea01457f-255e-1b4a-8f63-c03e3043d561">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.54e578425ae64a96bc8541768a40937a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173945.282 559974.936 173945.422 559974.734 173955.222 559981.526 173955.081 559981.730 173954.937 559981.937 173945.137 559975.145 173945.282 559974.936</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b618a4cce-6c64-e563-84f5-26a471b75610">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.69f6849f93a345cf8d0069a20d48068c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173935.088 559967.868 173935.227 559967.668 173944.539 559974.122 173944.399 559974.324 173944.254 559974.533 173934.942 559968.079 173935.088 559967.868</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b0c428b29-f678-01a2-64a8-3d736a416932">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8b9450bdfc0444ecb97dd4f28a995bf3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173923.395 559959.764 173923.534 559959.564 173934.483 559967.152 173934.344 559967.353 173934.198 559967.563 173923.249 559959.975 173923.395 559959.764</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba4823efc-30fd-ef2e-c3e2-6c629dd43688">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-01T20:50:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T14:05:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.655910816b6e46b2abc981f99ba8a0a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173940.008 559816.543 173957.971 559821.060 173960.868 559822.041 173960.739 559822.526 173957.830 559821.540 173954.031 559820.585 173953.161 559820.366 173939.855 559817.020 173940.008 559816.543</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3b8b09cb-1267-fb5c-cc45-6cf076e96d80">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1854439c35614d0d9753d91a8d72b638</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173965.089 559988.668 173965.231 559988.463 173966.249 559989.168 173966.107 559989.374 173965.965 559989.579 173964.946 559988.874 173965.089 559988.668</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7ae7dda1-65d0-1905-65de-032467f03a56">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.84f40083694b4830870c152116ffcbb4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173955.719 559982.172 173955.860 559981.968 173964.593 559988.020 173964.451 559988.226 173964.308 559988.431 173955.575 559982.379 173955.719 559982.172</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3a174229-6b02-2a78-8b16-214ca4b6ea26">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:31:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cfd8dfad0e834c139e864246438a74a5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173949.952 558690.031 173949.944 558689.470 173970.323 558689.209 173970.583 558704.960 173969.982 558704.968 173969.798 558689.739 173949.952 558690.031</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7dd8dab4-a8fc-55f4-b042-ff9f8229f501">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-08-08</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-08-08T10:20:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5c246b4d56d8400db5c4af2a3757192e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173999.825 559102.987 174001.583 559098.009 174002.343 559095.856 174003.014 559093.831 174005.508 559086.739 174006.239 559084.667 174008.680 559077.642 174009.169 559077.714 174009.464 559077.803 174009.421 559077.900 174006.978 559084.930 174006.232 559087.043 174003.758 559094.080 174003.085 559096.110 174002.231 559098.529 174000.569 559103.238 173999.825 559102.987</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba17c4681-99db-3cff-f797-5f16442e5ef4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:39:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-25T13:15:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f6a7b7dc43f14d7f8f502307f61fd9bd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173696.063 558850.071 173696.512 558866.452 173696.012 558866.466 173695.563 558850.085 173696.063 558850.071</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb2328a66-8a70-b1e6-9bc7-b271ab1b19af">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-23T10:39:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f6a7b7dc43f14d7f8f502307f61fd9bd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173696.656 558850.055 173697.196 558866.432 173696.012 558866.466 173695.563 558850.085 173696.656 558850.055</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd635522f-e07f-dcc5-ff23-925658f26a53">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-04-13T10:22:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.116ad963bf88452483e603cdf905972e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173881.127 559900.659 173899.565 559913.168 173900.752 559914.010 173900.543 559914.253 173899.459 559915.818 173886.700 559934.226 173886.289 559933.942 173899.040 559915.544 173899.846 559914.382 173899.088 559913.863 173881.098 559901.552 173879.553 559903.773 173879.141 559903.489 173879.143 559903.487 173880.971 559900.859 173881.127 559900.659</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7a0e3961-1a9c-cb08-cc3c-31a76d9c1295">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-04-13</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:10:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.116ad963bf88452483e603cdf905972e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173881.127 559900.659 173899.565 559913.168 173900.752 559914.010 173900.543 559914.253 173899.459 559915.818 173886.700 559934.226 173886.289 559933.942 173899.040 559915.544 173899.846 559914.382 173881.098 559901.552 173879.553 559903.773 173879.141 559903.489 173879.143 559903.487 173880.971 559900.859 173881.127 559900.659</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7f46194d-ee35-9e7a-b2a4-5150e03f54c7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:39:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-25T13:15:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e77862d1ba184396bf17f0f2799894c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173662.193 558850.996 173662.657 558867.415 173662.157 558867.429 173661.693 558851.010 173662.193 558850.996</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b154d1109-b8ac-c436-fd9a-081ced62a9f2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-23T10:39:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e77862d1ba184396bf17f0f2799894c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173662.351 558850.992 173663.066 558867.403 173661.673 558867.443 173661.230 558851.023 173662.351 558850.992</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb17e3910-0379-a25f-43db-5a5b7b76d50c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:29:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7927ddffc10b456db5e50e584a85e21e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173435.196 558888.183 173425.028 558890.042 173423.531 558891.324 173421.989 558892.551 173420.404 558893.723 173418.778 558894.836 173417.114 558895.891 173415.412 558896.886 173413.676 558897.819 173411.908 558898.689 173410.110 558899.495 173408.284 558900.237 173406.432 558900.912 173404.558 558901.521 173404.286 558901.317 173403.982 558901.373 173403.889 558900.542 173409.210 558898.093 173412.765 558896.962 173415.335 558895.764 173415.771 558895.708 173415.754 558895.569 173416.202 558895.360 173417.687 558894.339 173420.275 558892.558 173424.136 558889.425 173435.081 558887.348 173435.196 558888.183</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd1553ce9-4f40-4fe1-e8d6-52c2dda6d733">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:29:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.93604c921ad4474095118e796bda93ad</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173400.808 558880.626 173402.756 558880.545 173404.705 558880.533 173406.653 558880.591 173408.598 558880.717 173410.538 558880.912 173412.469 558881.176 173414.390 558881.508 173416.298 558881.908 173418.190 558882.376 173420.064 558882.910 173421.919 558883.510 173423.751 558884.176 173434.379 558882.243 173434.499 558883.114 173423.698 558884.952 173417.553 558883.280 173414.351 558882.291 173410.043 558881.584 173406.638 558881.141 173400.908 558881.301 173400.808 558880.626</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b0cec5538-7188-abe0-918a-696c7ab42ebc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:29:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.26d404ea19e9425fb01fa9134749e5f3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173359.106 558900.956 173368.324 558898.945 173369.289 558898.945 173371.102 558899.345 173382.120 558902.713 173383.274 558902.925 173385.793 558903.019 173388.924 558902.972 173393.429 558902.440 173393.647 558903.673 173393.286 558903.706 173392.924 558903.736 173392.561 558903.764 173392.199 558903.790 173391.837 558903.813 173391.474 558903.834 173391.111 558903.852 173390.748 558903.868 173390.385 558903.881 173390.022 558903.893 173389.659 558903.901 173389.295 558903.908 173388.932 558903.912 173388.569 558903.913 173388.206 558903.913 173387.842 558903.909 173387.479 558903.904 173387.116 558903.896 173386.753 558903.885 173386.390 558903.872 173386.027 558903.857 173385.664 558903.840 173385.301 558903.820 173384.939 558903.797 173384.576 558903.773 173384.214 558903.745 173383.852 558903.716 173383.490 558903.684 173383.128 558903.649 173382.767 558903.613 173382.406 558903.574 173382.045 558903.532 173381.684 558903.488 173381.324 558903.442 173380.964 558903.393 173380.604 558903.342 173380.245 558903.289 173379.886 558903.233 173379.527 558903.175 173379.169 558903.114 173378.811 558903.051 173378.454 558902.986 173378.097 558902.918 173377.740 558902.848 173377.384 558902.776 173377.029 558902.701 173376.674 558902.624 173376.319 558902.545 173375.965 558902.463 173375.612 558902.379 173375.259 558902.293 173374.907 558902.204 173374.555 558902.113 173374.204 558902.020 173373.854 558901.924 173373.504 558901.826 173373.155 558901.726 173372.806 558901.623 173372.458 558901.519 173372.111 558901.411 173371.765 558901.302 173371.419 558901.190 173371.074 558901.076 173370.730 558900.960 173370.387 558900.841 173370.044 558900.720 173369.702 558900.597 173369.361 558900.472 173369.021 558900.344 173368.819 558900.267 173366.174 558900.747 173359.336 558901.988 173359.274 558901.710 173359.106 558900.956</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b384c095d-a1e6-9824-7ba0-060ee65d9085">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.269fde3b7f2d420a9d05003f4c91b429</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173313.558 558913.806 173314.335 558913.580 173322.697 558945.769 173322.469 558945.891 173322.916 558947.719 173322.461 558947.476 173313.886 558915.165 173313.785 558914.757 173313.551 558913.810 173313.558 558913.806</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b130041e8-08af-037e-4758-bcd274aa6f5c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:29:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.384df85f6bf2434b8eb1f732d8b33b65</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173390.072 558883.387 173384.876 558885.311 173379.579 558887.431 173374.941 558889.880 173370.538 558893.036 173368.254 558895.179 173358.279 558897.262 173358.018 558896.097 173367.542 558894.401 173367.815 558894.161 173368.089 558893.922 173368.364 558893.685 173368.642 558893.451 173368.920 558893.218 173369.201 558892.986 173369.483 558892.757 173369.766 558892.530 173370.051 558892.304 173370.337 558892.080 173370.625 558891.859 173370.915 558891.639 173371.205 558891.421 173371.497 558891.205 173371.791 558890.990 173372.086 558890.778 173372.382 558890.568 173372.680 558890.360 173372.979 558890.153 173373.280 558889.949 173373.582 558889.747 173373.885 558889.547 173374.189 558889.348 173374.495 558889.152 173374.802 558888.958 173375.111 558888.765 173375.420 558888.575 173375.731 558888.387 173376.043 558888.201 173376.356 558888.017 173376.671 558887.835 173376.987 558887.655 173377.304 558887.477 173377.622 558887.302 173377.941 558887.128 173378.261 558886.957 173378.583 558886.787 173378.905 558886.620 173379.229 558886.455 173379.554 558886.292 173379.880 558886.131 173380.207 558885.973 173380.535 558885.816 173380.864 558885.662 173381.194 558885.510 173381.525 558885.360 173381.857 558885.212 173382.190 558885.066 173382.523 558884.923 173382.858 558884.782 173383.194 558884.643 173383.531 558884.506 173383.868 558884.372 173384.207 558884.239 173384.546 558884.109 173384.886 558883.982 173385.227 558883.856 173385.569 558883.733 173385.912 558883.612 173386.255 558883.493 173386.599 558883.376 173386.944 558883.262 173387.290 558883.150 173387.637 558883.041 173387.984 558882.933 173388.332 558882.828 173388.680 558882.725 173389.029 558882.625 173389.379 558882.527 173389.730 558882.431 173389.894 558882.387 173390.072 558883.387</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba1f997ca-46fd-c870-64a0-d452ea0f03d2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b23dd416799445d19d2cf8f29d42d8ce</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173256.073 558939.842 173262.228 558963.608 173261.438 558963.809 173255.519 558939.985 173256.073 558939.842</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b89d9d3fb-3550-301c-f5c8-c680769f234c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.742c283aaf2c4de4b4f6655d5831e09f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173253.983 558941.897 173259.980 558964.179 173259.820 558964.221 173259.382 558964.337 173256.497 558953.936 173255.338 558949.311 173253.524 558942.086 173253.509 558942.031 173253.983 558941.897</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b610e461d-bc47-f4fb-a8c0-8e8cd6cf5f43">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e134d2435d194b8585163dc076190a17</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173311.446 558904.831 173311.551 558905.252 173311.600 558905.447 173304.221 558905.277 173296.876 558905.788 173290.929 558906.394 173286.299 558907.007 173278.479 558908.307 173272.866 558909.326 173266.807 558910.659 173258.626 558912.671 173252.315 558914.292 173252.163 558914.047 173251.959 558913.773 173251.732 558913.518 173251.484 558913.284 173251.217 558913.072 173250.932 558912.884 173250.632 558912.721 173250.319 558912.585 173249.996 558912.476 173249.664 558912.396 173249.327 558912.344 173248.986 558912.322 173248.645 558912.329 173248.306 558912.366 173247.903 558912.493 173247.742 558911.812 173241.257 558887.749 173241.598 558887.659 173241.769 558887.614 173247.900 558910.094 173248.318 558911.623 173249.047 558911.497 173250.002 558911.712 173251.092 558912.183 173252.168 558912.789 173252.666 558913.260 173259.621 558911.389 173268.404 558909.299 173277.724 558907.465 173287.683 558905.974 173297.629 558904.900 173302.222 558904.735 173305.171 558904.737 173306.427 558904.738 173311.446 558904.831</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba103c280-ab47-4a8c-5fde-ef09bc9b2cd7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.97176f7753a140aa9c1ad716ec31477b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173304.031 558872.939 173312.241 558905.282 173311.551 558905.252 173311.446 558904.831 173303.094 558871.399 173303.655 558871.252 173304.031 558872.939</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b0d6d4225-9e74-ddd9-489f-68ef614ab69e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.77f1a0fe6d0d48a1a0457c07fd5afdd7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173255.983 558939.482 173256.073 558939.842 173255.519 558939.985 173255.441 558939.672 173255.283 558939.037 173255.603 558938.926 173255.879 558938.815 173256.144 558938.681 173256.397 558938.523 173256.634 558938.344 173256.855 558938.145 173257.057 558937.927 173257.240 558937.692 173257.401 558937.442 173257.539 558937.179 173257.654 558936.905 173257.744 558936.621 173257.809 558936.331 173257.848 558936.036 173257.860 558935.739 173257.853 558935.579 173265.940 558933.221 173273.200 558931.011 173276.202 558929.981 173282.821 558927.672 173289.531 558925.291 173291.344 558924.539 173300.713 558920.629 173303.872 558919.208 173308.769 558916.570 173310.841 558915.352 173313.551 558913.810 173313.785 558914.757 173308.702 558917.728 173302.196 558920.881 173297.052 558923.246 173294.341 558924.322 173288.374 558926.691 173281.293 558929.180 173276.604 558930.717 173264.545 558934.612 173258.422 558936.483 173258.267 558936.953 173257.841 558937.788 173257.345 558938.549 173256.813 558939.058 173256.251 558939.388 173255.983 558939.482</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5773359d-5ebe-c26b-dbaa-c47ecceab1a3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.34d222a2f7894482836f4584a831beee</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173239.665 558888.170 173245.747 558910.574 173245.214 558910.748 173240.672 558894.327 173239.124 558888.317 173239.665 558888.170</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6ab9de45-069e-c100-8c03-ce7f88a364f8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.213cdc3f5b6d411e9b198087aa3ce5f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173246.175 558912.152 173246.372 558912.877 173246.061 558913.013 173245.763 558913.175 173245.479 558913.362 173245.214 558913.574 173244.968 558913.808 173244.743 558914.062 173244.541 558914.335 173244.363 558914.624 173244.212 558914.928 173244.087 558915.244 173243.990 558915.570 173243.922 558915.902 173243.884 558916.240 173243.877 558916.488 173225.326 558921.908 173212.990 558926.312 173203.749 558930.011 173197.805 558932.577 173188.977 558937.490 173187.691 558938.282 173187.659 558938.175 173187.411 558937.343 173192.055 558934.847 173196.272 558932.581 173206.994 558927.951 173216.262 558924.239 173225.232 558921.130 173243.171 558915.737 173243.266 558914.913 173243.619 558914.041 173244.466 558912.981 173245.337 558912.416 173245.604 558912.332 173245.241 558910.843 173245.214 558910.748 173245.747 558910.574 173246.175 558912.152</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b67cead3b-bbea-0099-cba2-4bdc0ad07f9b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3d2e6548872641579e8dbdc4b0e3d5bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173196.643 558947.325 173194.122 558947.396 173191.288 558947.250 173190.046 558947.493 173189.863 558946.835 173194.263 558946.667 173200.394 558946.505 173207.307 558945.856 173216.211 558944.698 173220.281 558944.128 173226.304 558943.027 173230.687 558942.150 173239.893 558940.101 173249.477 558937.775 173249.541 558937.912 173249.695 558938.172 173249.871 558938.418 173250.068 558938.648 173250.285 558938.858 173250.521 558939.049 173250.772 558939.218 173251.037 558939.363 173251.314 558939.485 173251.601 558939.581 173251.896 558939.651 173252.195 558939.694 173252.497 558939.711 173252.800 558939.700 173253.100 558939.663 173253.369 558939.617 173253.983 558941.897 173253.509 558942.031 173252.985 558940.101 173252.178 558940.209 173251.209 558940.128 173250.738 558939.899 173249.447 558939.011 173249.124 558938.728 173240.527 558940.800 173232.706 558942.593 173228.783 558943.421 173219.575 558945.118 173207.097 558946.649 173202.953 558947.120 173198.265 558947.280 173196.643 558947.325</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bcfb83b08-942a-ecc5-a78b-17e658779d33">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8d9b53d6b42a45c2a582917650689d7b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173190.046 558947.493 173199.210 558980.391 173198.153 558980.668 173189.158 558947.667 173188.941 558946.871 173189.863 558946.835 173190.046 558947.493</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb378661f-0c38-1267-5c1e-9bc49abf8d7b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:51:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.11b665cb7de54579943f8bfd5f2e8048</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173141.809 558957.299 173132.237 558960.163 173131.273 558961.429 173130.259 558962.655 173129.198 558963.841 173128.091 558964.983 173126.939 558966.081 173124.986 558967.733 173122.989 558969.332 173120.949 558970.876 173118.869 558972.365 173116.750 558973.798 173114.292 558975.240 173112.899 558976.025 173112.654 558975.589 173114.043 558974.807 173116.483 558973.375 173118.583 558971.955 173120.653 558970.473 173122.682 558968.937 173124.668 558967.347 173126.605 558965.709 173127.739 558964.628 173128.832 558963.500 173129.880 558962.329 173130.881 558961.118 173131.938 558959.731 173141.660 558956.841 173141.809 558957.299</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1f537a6f-c72d-7d3a-2bbc-2c44bc67c316">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:51:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bfaa7b21f01542e49fd0a3779267cfbf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173139.398 558952.457 173139.393 558952.458 173131.688 558954.846 173123.614 558955.706 173122.939 558955.583 173122.167 558955.426 173121.337 558955.280 173121.078 558955.242 173120.582 558955.168 173120.532 558955.159 173120.297 558955.138 173119.218 558955.038 173119.043 558955.029 173118.226 558954.998 173117.466 558954.998 173116.779 558954.998 173116.039 558955.045 173115.295 558955.095 173114.919 558955.146 173112.542 558955.469 173110.442 558955.772 173110.280 558955.286 173110.781 558955.212 173111.532 558955.103 173111.996 558955.036 173112.162 558955.012 173112.448 558954.971 173112.653 558954.942 173113.029 558954.887 173113.230 558954.859 173113.568 558954.810 173113.681 558954.794 173113.815 558954.774 173115.177 558954.602 173116.530 558954.506 173117.886 558954.484 173119.242 558954.536 173120.592 558954.662 173121.934 558954.862 173123.263 558955.134 173123.633 558955.201 173123.817 558955.182 173131.335 558954.381 173131.586 558954.354 173134.751 558953.379 173136.474 558952.843 173138.333 558952.262 173139.254 558951.969 173139.398 558952.457</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba74e089c-6780-3a56-24a2-95b5b5627975">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-01-26</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-01-26T09:11:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.24460c5d94fc4259a700669f569dd463</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173178.281 558904.227 173185.442 558930.721 173186.627 558934.717 173187.411 558937.343 173187.659 558938.175 173186.757 558938.858 173177.370 558904.418 173178.281 558904.227</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba0281d1c-ffbd-b78c-1135-495efb075419">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:51:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3d1f488c25584220870b1d4659ee5ceb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173110.280 558955.286 173110.442 558955.772 173110.348 558955.786 173108.732 558956.028 173107.549 558956.379 173107.443 558955.886 173107.699 558955.810 173107.938 558955.740 173108.637 558955.534 173109.073 558955.466 173110.280 558955.286</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd0cea008-035c-e638-be3a-23070b609043">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-08-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-08-29T09:26:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-08-20T15:22:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ce19bb0b93e44fbd9fdf70e8f546e0c7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173093.740 559615.315 173092.144 559615.459 173092.023 559614.291 173091.956 559613.646 173091.865 559612.668 173093.497 559612.505 173093.661 559614.403 173095.223 559614.268 173095.267 559614.900 173095.348 559615.553 173095.407 559615.903 173095.500 559616.242 173095.582 559616.463 173095.780 559616.732 173096.056 559616.860 173099.092 559616.619 173106.406 559616.008 173111.217 559616.034 173118.448 559615.439 173123.294 559615.007 173130.496 559614.389 173135.288 559614.006 173142.551 559613.408 173147.489 559612.992 173147.492 559613.026 173147.464 559613.336 173147.356 559613.837 173147.330 559613.904 173121.092 559616.224 173105.322 559617.724 173098.475 559618.319 173097.406 559618.359 173096.768 559618.339 173096.448 559618.299 173096.178 559618.219 173095.769 559618.080 173095.460 559617.920 173095.070 559617.620 173094.841 559617.411 173094.661 559617.211 173094.491 559616.912 173094.264 559616.294 173093.995 559615.292 173093.740 559615.315</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf407f1dc-0fda-a012-13bd-b5cc9588dd6d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-08-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-08-29T09:26:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-08-20T15:22:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d9b4208aa7324f80abc66e518d1681bd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173091.197 559585.898 173093.419 559611.595 173091.780 559611.766 173089.372 559586.074 173091.197 559585.898</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6c7e079e-1348-25db-7dda-923da622496f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-31</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-07-31T08:45:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-25T15:18:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ed769a55bda94a58b334eb311a281568</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173180.939 559962.231 173185.624 559961.873 173194.092 559961.225 173194.108 559961.432 173194.130 559961.723 173184.803 559962.437 173172.248 559963.397 173172.231 559963.171 173172.210 559962.899 173180.939 559962.231</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8660afef-8096-358d-569b-bc1cd8b328f0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-31</terminationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-07-31T08:45:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-25T15:18:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ed769a55bda94a58b334eb311a281568</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173180.939 559962.231 173185.624 559961.873 173194.092 559961.225 173194.108 559961.432 173194.130 559961.723 173184.803 559962.437 173172.248 559963.397 173172.231 559963.171 173172.210 559962.899 173180.939 559962.231</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b2ddc8ec6-7e5c-8014-6404-c3c4527b4a56">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-31</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-07-31T08:45:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fc2b13aa61f2449fa1940dd9a74b7e5e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173180.939 559962.231 173183.033 559962.071 173183.059 559962.570 173172.248 559963.397 173172.231 559963.171 173172.210 559962.899 173180.939 559962.231</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b3b789684-b630-a565-6119-e0986bda8a0d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T15:18:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b18f83bca2fe4ceda95405214de535f9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173226.992 559959.736 173226.977 559959.737 173199.722 559961.876 173199.682 559961.378 173226.937 559959.239 173226.951 559959.238 173226.992 559959.736</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb29dc17c-a033-3fc1-09e5-3124674538f4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-31</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-07-31T08:45:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4460cf04d53f4f6cb54f83e29a2b249e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173184.803 559962.437 173194.130 559961.723 173194.405 559961.695 173194.487 559962.711 173192.703 559962.868 173191.898 559962.927 173186.689 559963.356 173185.871 559963.417 173184.890 559963.506 173184.803 559962.437</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd40bf299-df1f-dc63-1920-f31426cb335d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-21</creationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-23T10:48:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2d3230d2dec3401bbb419ac0e05d312a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173275.173 559912.725 173273.670 559912.902 173272.241 559892.075 173273.547 559891.954 173274.201 559899.549 173274.211 559899.739 173274.244 559899.862 173274.299 559899.978 173274.372 559900.082 173274.462 559900.172 173276.101 559901.524 173276.278 559901.745 173276.360 559901.915 173276.411 559902.097 173276.429 559902.285 173276.413 559902.473 173276.363 559902.656 173276.283 559902.827 173274.941 559904.479 173274.849 559904.578 173274.774 559904.691 173274.719 559904.814 173274.686 559904.946 173274.675 559905.080 173274.874 559907.526 173275.173 559912.725</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1c7049fb-bd2e-5311-0ff7-c0378372a34f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-02</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-23</terminationDate>
            <imgeo:LV-publicatiedatum>2024-09-06T10:00:46</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:48:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-09-02T11:42:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.859ff777b6da48119f09aa8c544f55d7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173274.220 559899.773 173274.675 559905.080 173274.874 559907.526 173275.173 559912.725 173274.006 559912.862 173272.240 559892.076 173273.547 559891.954 173274.201 559899.549 173274.211 559899.739 173274.220 559899.773</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9e3da07c-3320-1a56-6dc1-8c7da40057b1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-02</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-23</terminationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:48:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-09-02T11:42:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.859ff777b6da48119f09aa8c544f55d7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173274.220 559899.773 173274.675 559905.080 173274.874 559907.526 173275.173 559912.725 173274.006 559912.862 173272.240 559892.076 173273.547 559891.954 173274.201 559899.549 173274.211 559899.739 173274.220 559899.773</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bdf8502da-4a10-080d-ec97-23f37e4e50ec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-21</creationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-23T10:48:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2a91a20dbc094d31b62af7c26e1f1ccc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173267.761 559826.413 173268.515 559832.605 173268.628 559833.902 173269.129 559839.667 173269.146 559839.774 173269.174 559839.879 173269.211 559839.982 173269.257 559840.080 173269.313 559840.173 173269.377 559840.261 173270.866 559841.578 173270.933 559841.653 173270.994 559841.733 173271.047 559841.819 173271.092 559841.909 173271.129 559842.003 173271.157 559842.099 173271.177 559842.198 173271.187 559842.298 173271.189 559842.399 173271.181 559842.499 173271.164 559842.598 173271.139 559842.696 173271.105 559842.791 173271.062 559842.882 173271.012 559842.969 173269.783 559844.609 173269.695 559844.735 173269.629 559844.874 173269.587 559845.022 173269.571 559845.252 173269.883 559848.628 173268.740 559848.619 173267.059 559826.490 173267.761 559826.413</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf34bc264-8845-cfc4-31b5-9731a7fec4bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-02</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-23</terminationDate>
            <imgeo:LV-publicatiedatum>2024-09-06T10:00:46</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:48:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-09-02T11:42:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.974a254793424ee69e26c4efb095066a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173268.515 559832.605 173268.628 559833.902 173269.129 559839.667 173269.587 559845.022 173269.571 559845.252 173269.863 559848.407 173268.526 559848.513 173266.637 559827.825 173267.870 559827.713 173268.515 559832.605</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6113aefa-edfc-8a13-a9f2-8c8aa7cea61e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-02</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-10-23</terminationDate>
            <imgeo:LV-publicatiedatum>2024-10-23T11:15:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-23T10:48:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-09-02T11:42:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.974a254793424ee69e26c4efb095066a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173268.515 559832.605 173268.628 559833.902 173269.129 559839.667 173269.587 559845.022 173269.571 559845.252 173269.863 559848.407 173268.526 559848.513 173266.637 559827.825 173267.870 559827.713 173268.515 559832.605</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b23cae8da-5e58-1856-d555-94ce79ac55de">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-02-07</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-02-07T15:55:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bb3b8f18abd646a0b136c83753a0b1f6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173306.505 559597.889 173293.146 559598.970 173293.109 559598.572 173306.439 559597.485 173306.505 559597.889</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7f64cc09-cf73-9d34-b31c-50f0d557bbab">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-08-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-08-29T09:26:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-08-20T14:39:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8619f29aaa394648a5dceed4ef13153e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173205.496 559587.580 173174.310 559590.377 173174.245 559589.549 173179.151 559589.127 173179.131 559588.909 173204.257 559586.621 173203.891 559581.496 173205.013 559581.395 173205.496 559587.580</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf50fb3c3-304f-0b9e-7437-eeccf9b9cc64">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T12:49:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.196c18b3ad29405cb49f28695410d0a8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173233.842 559407.705 173244.907 559407.267 173244.926 559407.766 173233.862 559408.205 173233.842 559407.705</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b070c5dd7-51ee-e526-c2cc-511530de2902">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T12:52:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.318fa2a23e994023896de5ed1b6a60af</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173359.709 559197.226 173359.685 559197.051 173359.662 559196.876 173359.643 559196.700 173359.625 559196.525 173359.611 559196.349 173359.598 559196.172 173359.588 559195.996 173359.580 559195.820 173359.575 559195.643 173359.572 559195.466 173359.571 559195.290 173359.573 559195.113 173359.577 559194.937 173359.584 559194.760 173359.593 559194.584 173359.604 559194.407 173359.618 559194.231 173359.635 559194.056 173359.653 559193.880 173359.674 559193.705 173359.698 559193.530 173359.723 559193.355 173359.751 559193.180 173359.782 559193.006 173359.815 559192.833 173359.850 559192.660 173359.888 559192.487 173359.927 559192.315 173359.970 559192.144 173360.014 559191.973 173360.061 559191.802 173360.110 559191.633 173360.162 559191.464 173360.216 559191.296 173360.272 559191.128 173360.330 559190.962 173360.391 559190.796 173360.454 559190.631 173360.519 559190.466 173360.586 559190.303 173360.655 559190.141 173360.727 559189.979 173360.801 559189.819 173360.877 559189.659 173360.955 559189.501 173361.036 559189.344 173361.118 559189.188 173361.203 559189.033 173361.290 559188.879 173361.378 559188.726 173361.469 559188.575 173361.562 559188.424 173361.657 559188.275 173361.754 559188.128 173361.853 559187.982 173361.954 559187.837 173362.057 559187.693 173362.162 559187.551 173362.269 559187.410 173362.377 559187.271 173362.488 559187.133 173362.600 559186.997 173362.714 559186.862 173362.831 559186.729 173362.949 559186.598 173363.068 559186.468 173363.190 559186.339 173363.313 559186.213 173363.438 559186.088 173363.564 559185.965 173363.692 559185.843 173363.822 559185.723 173363.953 559185.606 173364.087 559185.489 173364.221 559185.375 173364.357 559185.262 173364.495 559185.152 173364.634 559185.043 173364.775 559184.936 173364.917 559184.831 173365.060 559184.728 173365.205 559184.627 173365.351 559184.528 173365.499 559184.431 173365.648 559184.336 173365.798 559184.243 173365.949 559184.152 173366.102 559184.063 173366.256 559183.976 173366.411 559183.891 173366.567 559183.809 173366.724 559183.728 173366.882 559183.650 173367.042 559183.574 173367.202 559183.500 173367.363 559183.428 173367.526 559183.358 173367.689 559183.291 173367.853 559183.226 173368.018 559183.163 173368.184 559183.102 173368.351 559183.043 173368.518 559182.987 173368.686 559182.933 173368.855 559182.882 173369.025 559182.832 173369.195 559182.785 173369.366 559182.741 173369.537 559182.698 173369.709 559182.658 173369.882 559182.621 173370.055 559182.585 173370.228 559182.552 173370.402 559182.522 173370.577 559182.493 173370.734 559183.623 173370.240 559183.651 173368.363 559184.328 173366.747 559185.185 173365.235 559186.212 173364.041 559187.395 173363.029 559188.736 173362.292 559190.246 173361.687 559191.814 173361.266 559193.942 173361.128 559195.848 173361.215 559196.857 173359.709 559197.226</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b616bd7c4-aa2d-2f97-7562-55d7d3e72ba7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T12:52:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.069ae876b1344c5b891101524a210e1f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173361.522 559198.992 173362.512 559201.435 173364.127 559203.519 173366.227 559205.113 173368.238 559206.052 173370.993 559206.681 173371.981 559206.599 173372.075 559208.331 173371.898 559208.323 173371.722 559208.313 173371.546 559208.300 173371.370 559208.285 173371.194 559208.267 173371.019 559208.247 173370.843 559208.225 173370.668 559208.200 173370.494 559208.173 173370.320 559208.144 173370.146 559208.112 173369.973 559208.078 173369.800 559208.041 173369.627 559208.002 173369.456 559207.961 173369.284 559207.918 173369.114 559207.872 173368.944 559207.824 173368.775 559207.773 173368.606 559207.721 173368.438 559207.665 173368.271 559207.608 173368.105 559207.549 173367.939 559207.487 173367.775 559207.423 173367.611 559207.356 173367.448 559207.288 173367.286 559207.217 173367.125 559207.144 173366.965 559207.069 173366.806 559206.992 173366.649 559206.912 173366.492 559206.831 173366.336 559206.747 173366.182 559206.661 173366.029 559206.573 173365.876 559206.483 173365.726 559206.391 173365.576 559206.297 173365.428 559206.201 173365.281 559206.103 173365.135 559206.003 173364.991 559205.901 173364.848 559205.797 173364.707 559205.691 173364.567 559205.583 173364.429 559205.474 173364.292 559205.362 173364.156 559205.249 173364.022 559205.133 173363.890 559205.016 173363.759 559204.898 173363.630 559204.777 173363.503 559204.655 173363.377 559204.530 173363.253 559204.405 173363.131 559204.277 173363.010 559204.148 173362.891 559204.017 173362.774 559203.885 173362.659 559203.751 173362.546 559203.616 173362.434 559203.479 173362.324 559203.340 173362.217 559203.200 173362.111 559203.059 173362.007 559202.916 173361.905 559202.772 173361.805 559202.626 173361.707 559202.479 173361.611 559202.331 173361.517 559202.181 173361.425 559202.030 173361.335 559201.878 173361.247 559201.725 173361.161 559201.571 173361.078 559201.415 173360.996 559201.258 173360.917 559201.100 173360.839 559200.941 173360.764 559200.782 173360.692 559200.621 173360.621 559200.459 173360.552 559200.296 173360.486 559200.132 173360.422 559199.967 173360.360 559199.802 173360.301 559199.636 173360.244 559199.468 173360.189 559199.302 173361.522 559198.992</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9c5a632e-4fd8-10bf-24ce-08c24855be0c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-02-07</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-02-07T15:55:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.aba4fd322db141a7a03656de50d0c2a6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173385.337 559591.244 173348.136 559597.325 173347.993 559596.467 173385.266 559590.386 173385.337 559591.244</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="be365cc0f-7e30-3464-6d52-99f70de6c6cc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T12:52:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.723ae66e60f74f93ad3a599ef19f7882</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173385.430 559193.428 173385.455 559193.603 173385.477 559193.778 173385.497 559193.954 173385.515 559194.129 173385.530 559194.305 173385.543 559194.482 173385.553 559194.658 173385.562 559194.834 173385.567 559195.011 173385.570 559195.187 173385.571 559195.364 173385.570 559195.541 173385.566 559195.717 173385.560 559195.894 173385.551 559196.070 173385.540 559196.247 173385.526 559196.423 173385.510 559196.598 173385.492 559196.774 173385.471 559196.950 173385.448 559197.125 173385.423 559197.300 173385.395 559197.474 173385.365 559197.648 173385.332 559197.822 173385.297 559197.995 173385.260 559198.168 173385.220 559198.340 173385.179 559198.511 173385.134 559198.682 173385.088 559198.853 173385.039 559199.022 173384.988 559199.191 173384.934 559199.360 173384.878 559199.527 173384.820 559199.694 173384.760 559199.860 173384.697 559200.025 173384.633 559200.190 173384.566 559200.353 173384.496 559200.516 173384.425 559200.677 173384.351 559200.838 173384.276 559200.997 173384.198 559201.156 173384.117 559201.313 173384.035 559201.470 173383.951 559201.625 173383.865 559201.779 173383.776 559201.932 173383.685 559202.083 173383.593 559202.234 173383.498 559202.383 173383.401 559202.531 173383.303 559202.677 173383.202 559202.822 173383.099 559202.966 173382.995 559203.108 173382.888 559203.249 173382.780 559203.389 173382.670 559203.527 173382.557 559203.663 173382.443 559203.798 173382.327 559203.931 173382.210 559204.063 173382.090 559204.193 173381.969 559204.322 173381.846 559204.449 173381.722 559204.574 173381.595 559204.697 173381.467 559204.819 173381.338 559204.939 173381.207 559205.057 173381.074 559205.174 173380.939 559205.288 173380.803 559205.401 173380.666 559205.512 173380.527 559205.621 173380.387 559205.728 173380.245 559205.833 173380.101 559205.937 173379.957 559206.038 173379.811 559206.137 173379.663 559206.235 173379.515 559206.330 173379.365 559206.423 173379.213 559206.515 173379.061 559206.604 173378.907 559206.691 173378.753 559206.776 173378.597 559206.859 173378.440 559206.940 173378.281 559207.019 173378.122 559207.095 173377.962 559207.169 173377.801 559207.242 173377.638 559207.312 173377.475 559207.379 173377.311 559207.445 173377.146 559207.508 173376.981 559207.569 173376.814 559207.628 173376.647 559207.684 173376.479 559207.739 173376.310 559207.791 173376.140 559207.840 173375.970 559207.887 173375.799 559207.933 173375.628 559207.975 173375.456 559208.016 173375.283 559208.054 173375.110 559208.089 173374.937 559208.123 173374.763 559208.154 173374.589 559208.182 173374.472 559208.200 173374.374 559206.399 173375.052 559206.342 173377.975 559205.666 173380.778 559203.925 173382.421 559201.895 173383.460 559200.033 173384.172 559198.024 173384.404 559195.905 173384.306 559194.184 173384.205 559193.713 173385.430 559193.428</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b78b0d979-da66-1d4a-d029-93fd6f295534">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T12:52:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e6eb437ee95b46b493efdec1eaae64bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173373.068 559182.349 173373.245 559182.357 173373.361 559182.364 173373.477 559182.371 173373.593 559182.380 173373.773 559182.395 173373.886 559182.406 173374.124 559182.433 173374.300 559182.455 173374.416 559182.471 173374.533 559182.489 173374.649 559182.507 173374.822 559182.536 173374.938 559182.557 173375.054 559182.579 173375.170 559182.602 173375.342 559182.639 173375.572 559182.691 173375.798 559182.747 173376.034 559182.810 173376.143 559182.840 173376.256 559182.873 173376.368 559182.907 173376.535 559182.959 173376.705 559183.015 173376.816 559183.053 173376.985 559183.112 173377.097 559183.153 173377.209 559183.195 173377.366 559183.257 173377.478 559183.302 173377.695 559183.392 173377.857 559183.463 173377.964 559183.511 173378.173 559183.609 173378.281 559183.661 173378.388 559183.714 173378.494 559183.768 173378.647 559183.848 173378.756 559183.906 173378.960 559184.019 173379.165 559184.136 173379.367 559184.258 173379.567 559184.383 173379.711 559184.477 173379.868 559184.581 173379.961 559184.645 173380.151 559184.779 173380.247 559184.848 173380.436 559184.989 173380.529 559185.061 173380.622 559185.133 173380.714 559185.206 173380.851 559185.318 173380.985 559185.431 173381.121 559185.547 173381.252 559185.664 173381.383 559185.783 173381.469 559185.863 173381.555 559185.944 173381.640 559186.026 173381.765 559186.150 173381.847 559186.232 173381.928 559186.316 173382.009 559186.400 173382.090 559186.486 173382.172 559186.576 173382.251 559186.663 173382.329 559186.750 173382.408 559186.841 173382.484 559186.930 173382.597 559187.065 173382.671 559187.156 173382.818 559187.340 173382.932 559187.488 173383.000 559187.579 173383.068 559187.672 173383.135 559187.764 173383.238 559187.909 173383.337 559188.054 173383.403 559188.152 173383.468 559188.250 173383.532 559188.349 173383.598 559188.454 173383.658 559188.552 173383.718 559188.650 173383.806 559188.799 173383.895 559188.955 173383.981 559189.110 173384.037 559189.213 173384.143 559189.417 173384.197 559189.523 173384.250 559189.631 173384.303 559189.739 173384.380 559189.903 173384.451 559190.060 173384.521 559190.222 173384.566 559190.328 173384.613 559190.440 173384.656 559190.548 173384.720 559190.713 173384.761 559190.823 173384.802 559190.934 173384.841 559191.045 173383.695 559191.344 173383.557 559190.703 173382.977 559189.204 173382.189 559187.803 173381.120 559186.604 173379.858 559185.609 173378.478 559184.786 173376.997 559184.162 173375.456 559183.704 173373.871 559183.444 173373.130 559183.486 173373.068 559182.349</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b18e95121-4e8a-30be-b2e9-785cbfefe917">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:12:10.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6a37aefcc5544390b2015fe2ad15d12a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173549.945 559172.865 173549.802 559172.767 173549.527 559172.579 173549.549 559172.543 173551.885 559168.312 173551.924 559168.235 173552.045 559168.296 173552.323 559168.555 173549.987 559172.783 173549.945 559172.865</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b26d3a848-1e03-83de-b8a3-ecba5f4802c4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T13:12:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.308827eb3ae540b697b0db45f28e769b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173543.597 559181.419 173543.650 559181.366 173545.651 559178.704 173547.207 559176.410 173548.608 559174.126 173548.727 559173.926 173549.008 559174.146 173549.129 559174.233 173549.035 559174.388 173547.627 559176.681 173546.058 559178.995 173544.050 559181.667 173543.978 559181.741 173543.764 559181.552 173543.597 559181.419</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1712e2bc-942c-0c24-dcda-eb83bc563015">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-02-15T14:47:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.35e9e517cf824c45ae901244c302d713</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172619.233 559994.393 172620.024 560004.624 172619.526 560004.662 172618.732 559994.428 172619.233 559994.393</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb6e9ab40-e8c2-8e9b-07a1-1272fb75e6c9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-02-15T14:47:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-24T15:41:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.35e9e517cf824c45ae901244c302d713</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172619.233 559994.393 172620.024 560004.624 172619.526 560004.662 172618.735 559994.431 172619.233 559994.393</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b2647a685-1e8a-7d54-bd6d-4803c4308f10">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T15:41:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b9ebbf8eb11b492e9bff28aa84b13c01</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172606.666 559992.812 172607.164 559992.771 172607.595 559997.885 172607.097 559997.927 172606.666 559992.812</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4c1840e3-ef93-0092-adbc-c4b91dc577c3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-06-07</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-06-07T11:13:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d244aeb174d04936a8a95097f33be2a3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172545.607 559139.816 172545.722 559140.989 172542.804 559141.256 172542.651 559140.089 172545.607 559139.816</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b0b5f7450-0088-472a-2b32-33843b74f924">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-02-06</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-02-06T10:50:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c27b554f48eb4ba58fdb844c64c00271</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172894.787 559796.476 172895.527 559796.188 172903.689 559818.850 172903.074 559819.068 172894.787 559796.476</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b414185cc-4c2a-3c9d-6738-058319c92f18">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-25</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-25T14:02:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a43c21b824a1448e86f0774e9a801601</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173045.205 559639.242 173047.539 559669.132 173046.987 559678.195 173044.491 559684.531 173035.961 559694.465 173030.415 559698.312 173019.885 559702.979 173019.663 559702.530 173030.169 559697.874 173035.623 559694.091 173044.057 559684.269 173046.493 559678.085 173047.038 559669.136 173044.728 559639.558 173044.717 559639.559 173044.693 559639.256 173044.728 559639.254 173045.205 559639.242</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b76b49f02-5d9c-3bb4-81cb-89f1a0291a2a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.f22440e4b2c14270b5f5dd452596d808</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172884.160 558605.897 172887.087 558605.433 172885.673 558590.153</gml:posList></gml:LineString></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bbdaf223a-06cd-c6d8-69d4-590a0e53f6d7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.acd1a62a2ade4ae6af0dc2e3fd69825c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172885.230 558582.857 172885.539 558588.336</gml:posList></gml:LineString></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b58a9c935-80d7-aaf3-e1b7-5aa5459c3146">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.fe71c19624d34b7ea283229465a1432c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172867.063 558112.641 172868.906 558110.572</gml:posList></gml:LineString></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b5fa05693-5746-81ec-088c-f300149c7d33">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:47:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e08c879144d944b8a96eecac68d69699</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172766.655 558918.656 172764.992 558920.921 172762.514 558921.249 172755.953 558922.118 172753.554 558920.428 172754.168 558919.841 172756.054 558921.325 172764.680 558920.143 172766.038 558918.231 172766.655 558918.656</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b6f3759e6-1b90-05b1-50cd-12926f25e203">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-19T11:38:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dcafe8b7334e43ed9304c588cbe54161</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172672.532 558998.204 172675.026 559017.025 172673.946 559017.113 172671.383 558998.514 172672.532 558998.204</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1bf597c8-9000-83c7-f92e-e2cd00dfc8d9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-12-27</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-12-27T11:19:20</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-07-19T07:36:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c907f105675f4c0dbde095c64ed7b69f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172571.712 559070.518 172570.200 559070.657 172566.231 559071.023 172566.034 559064.656 172565.717 559062.569 172565.189 559061.909 172563.103 559061.513 172553.704 559061.751 172540.714 559061.724 172540.813 559059.746 172565.788 559059.233 172568.320 559060.928 172569.279 559062.847 172568.896 559065.438 172568.585 559067.538 172570.910 559069.085 172571.712 559070.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b32ba3488-bc2b-9179-a006-255c0e708fe1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-07-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-12-27</terminationDate>
            <imgeo:LV-publicatiedatum>2019-01-11T13:39:16</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-12-27T11:19:20</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-07-19T07:36:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c907f105675f4c0dbde095c64ed7b69f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172571.712 559070.518 172570.200 559070.657 172566.231 559071.023 172566.034 559064.656 172565.717 559062.569 172565.189 559061.909 172563.103 559061.513 172553.704 559061.751 172540.714 559061.724 172540.813 559059.746 172565.788 559059.233 172568.320 559060.928 172569.279 559062.847 172568.896 559065.438 172568.585 559067.538 172570.910 559069.085 172571.712 559070.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bfee3feab-140c-877f-4d32-9a8467725d3a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-01-10T15:26:37</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-04-19T10:03:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c86bccb78eae4788afce9bc65281ab2b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172323.962 559078.641 172302.051 559092.227 172301.972 559092.570 172300.928 559090.348 172301.237 559090.461 172322.888 559076.884 172323.962 559078.641</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b7f4c5be4-1b8f-90b8-d01c-aa2914f44ce1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-19</creationDate>
            <imgeo:LV-publicatiedatum>2023-01-10T16:41:10</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2023-01-10T15:26:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c86bccb78eae4788afce9bc65281ab2b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172323.962 559078.641 172301.971 559092.246 172300.956 559090.623 172322.888 559076.884 172323.962 559078.641</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bbc5234cc-8cbc-a5b4-f82e-bf527d4cff71">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:54:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f4eccb9ed82c4c8c97292eafebda7939</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172055.625 559256.239 172053.762 559257.401 172051.095 559259.472 172045.817 559263.556 172042.187 559266.756 172040.357 559268.389 172040.002 559267.975 172044.440 559264.007 172046.284 559262.549 172053.414 559257.095 172055.349 559255.839 172055.625 559256.239</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b715d7489-6d9b-0b41-42ff-ddbf59a1aa21">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:19:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.09138d6d973644dab2da648c620c6312</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172044.349 559351.474 172041.460 559355.690 172038.896 559359.264 172037.998 559358.820 172043.954 559349.920 172044.973 559350.564 172044.349 559351.474</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b2bb0096c-becb-7cc0-c4fa-81fe737262d7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:19:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7f78a8e0a88341ee915c635019c3bc31</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172052.132 559340.310 172049.740 559343.610 172047.173 559347.355 172046.554 559348.258 172045.613 559347.535 172051.327 559339.620 172052.132 559340.310</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="be1a0fc05-5fe9-ec15-1866-e40d0f724b4b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:19:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.66416af42ca742028b86bd598cfbd2d0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172081.532 559309.800 172077.670 559312.740 172074.809 559314.844 172073.949 559314.082 172081.657 559308.349 172081.804 559308.534 172082.331 559309.191 172081.532 559309.800</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b70f69bf3-2d2a-fbb0-1f96-07d50f207fc4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T11:19:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.49b0590949c54a069ccc615c64b70cb0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172092.414 559301.334 172089.440 559303.780 172085.530 559306.756 172084.604 559307.461 172083.969 559306.764 172091.788 559300.150 172092.414 559301.334</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="be78c5d56-9539-1ffa-40d4-5ebe64022868">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:00:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.79f0028ed1a645c4be1c65957e5c111c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172241.367 559467.063 172246.746 559461.550 172247.104 559461.899 172241.725 559467.412 172241.367 559467.063</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4ccf0d34-176e-4f33-c8bc-2aea5aa890b3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-19</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-19T14:20:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-21T09:35:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ab75f9a64e2143b3af6667122d744792</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172232.967 559434.797 172238.562 559439.712 172238.441 559440.105 172238.082 559440.483 172231.814 559435.920 172232.893 559434.864 172232.967 559434.797</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bc4d692a1-379d-a4f8-f0c6-8de2901ae100">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-19</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-19T14:20:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-21T09:35:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ab75f9a64e2143b3af6667122d744792</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172232.967 559434.797 172238.562 559439.712 172238.441 559440.105 172238.082 559440.483 172231.814 559435.920 172232.893 559434.864 172232.967 559434.797</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bf80f2b33-1d01-0e74-4eec-056cdea1f440">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:00:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.08b0697b51244161b7bc1158b5ed300d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172233.882 559474.862 172238.947 559469.663 172239.305 559470.012 172234.240 559475.211 172233.882 559474.862</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b1303619a-06f7-85e1-5ea1-de705d557278">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:00:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.461b9772f0cf49faaae4fc2410e8ee65</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172227.252 559482.991 172232.613 559476.491 172232.999 559476.809 172227.638 559483.309 172227.252 559482.991</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b25c81095-6ff1-f0d1-55eb-0a06492f8318">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:00:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.df53088f946048dda76f6ab9bab91ad3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172218.106 559492.890 172223.871 559486.505 172224.242 559486.840 172218.477 559493.225 172218.106 559492.890</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b12513950-59d5-c8df-0495-cc1c44f5e7ff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:52:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.68c25cd54984454aba39d7cb322e3d90</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172185.458 559255.113 172185.787 559266.600 172184.361 559266.653 172183.904 559255.113 172185.458 559255.113</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b8b2abd1b-cf84-6da1-4492-ef3a35c5ecb3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:52:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.240c6a2e35d545a594ba1e8d1deaa842</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172183.268 559240.439 172185.057 559240.453 172185.521 559254.184 172183.817 559254.230 172183.268 559240.439</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b964c9443-9b86-d846-4059-a2455e1c8fff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:52:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.74bd449094d54b978b923007cefafbda</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172218.516 559185.869 172219.587 559187.258 172213.432 559191.590 172212.662 559190.866 172213.432 559190.232 172216.464 559187.726 172218.516 559185.869</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9f27d025-f800-839b-4315-c5607a061cb8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:37:47.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4c7fd72d670c4e04bd3edcf64ce51c95</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172314.648 559228.702 172305.295 559229.514 172305.211 559228.926 172314.586 559228.159 172314.648 559228.702</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b956e0835-707b-1312-d01d-cd9cfb2a5a2a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-06-07</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-01</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-01T10:56:28</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-06-07T11:13:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c51b3a34898b479083797e1ab0f25e3d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172542.217 559140.124 172542.314 559141.292 172540.505 559141.426 172540.413 559140.267 172542.217 559140.124</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b38209a2f-fa28-b824-94a4-b59d4bb9346f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-06-07</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-01</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-01T10:56:28</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-06-07T11:13:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c51b3a34898b479083797e1ab0f25e3d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172542.217 559140.124 172542.314 559141.292 172540.505 559141.426 172540.413 559140.267 172542.217 559140.124</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b43815db7-cb3d-d440-fd9c-c869f526dcf6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:29:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9b2faf7f54cd45f5848d1a1f36a2be4b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172485.595 559380.208 172489.152 559383.120 172488.928 559383.375 172484.421 559383.772 172484.148 559383.525 172483.899 559380.567 172485.595 559380.208</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bee7d97dd-266c-3d75-7651-5f76424a6c1b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-04-24</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-04-24T13:26:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4f3343ae5979412ca9a375475739da75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172456.774 559478.659 172458.813 559497.513 172458.315 559497.567 172456.277 559478.713 172456.774 559478.659</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b9802c139-7b03-e8c1-9f7a-5e47b2b32e8e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.133b9df88bca408bbe4f324d1b25e425</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172688.437 559116.713 172689.931 559116.310 172691.529 559136.365 172690.127 559136.541 172690.093 559135.817 172688.437 559116.713</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bb297451d-5eb8-528a-b66c-9cfb3cdbe09f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.133b9df88bca408bbe4f324d1b25e425</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172688.437 559116.713 172689.931 559116.310 172691.529 559136.365 172690.127 559136.541 172690.093 559135.817 172688.437 559116.713</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b55815663-7755-971b-0477-65844c76542b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4b540ba98ced4e4aa253940e9f213551</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172703.863 559096.154 172723.289 559094.532 172723.409 559095.974 172722.407 559096.051 172703.996 559097.470 172703.863 559096.154</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b2c4361e0-6bef-2931-ec3f-7b62b4f14dc2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4b540ba98ced4e4aa253940e9f213551</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172703.863 559096.154 172723.289 559094.532 172723.409 559095.974 172722.407 559096.051 172703.996 559097.470 172703.863 559096.154</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b21cb802e-fa12-6132-6859-65d5a4f17f83">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5eef4748d6a84af8b92a5ca020721f75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172724.217 559117.734 172724.633 559117.719 172724.658 559118.415 172725.354 559118.391 172725.424 559120.413 172725.186 559120.947 172724.518 559122.137 172724.568 559123.417 172722.534 559123.411 172722.300 559121.375 172724.003 559119.256 172723.843 559117.747 172724.217 559117.734</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b19ee5d95-5d3e-5d3d-342a-a0a35d28cb9b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5eef4748d6a84af8b92a5ca020721f75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172724.217 559117.734 172724.633 559117.719 172724.658 559118.415 172725.354 559118.391 172725.424 559120.413 172725.186 559120.947 172724.518 559122.137 172724.568 559123.417 172722.534 559123.411 172722.300 559121.375 172724.003 559119.256 172723.843 559117.747 172724.217 559117.734</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bd0cfefab-f1ac-e632-9a56-a405dbeadbe0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6a2bb0498cf04f4bbf1ecf5eef5b2a46</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172725.385 559133.980 172723.408 559133.980 172722.620 559124.894 172724.659 559125.018 172725.385 559133.980</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bca2fb3a1-5162-79dd-36dc-588f63133636">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6a2bb0498cf04f4bbf1ecf5eef5b2a46</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172725.385 559133.980 172723.408 559133.980 172722.620 559124.894 172724.659 559125.018 172725.385 559133.980</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bc99b362f-992b-ed53-ed89-40e7467ae070">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d6e95b11b84e41679355012abc55a5f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172702.270 559096.374 172702.370 559097.631 172688.531 559098.734 172689.044 559105.174 172687.472 559105.569 172686.782 559097.608 172702.270 559096.374</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b798d0d2a-f425-ba8e-cc23-a5a53700a0e5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d6e95b11b84e41679355012abc55a5f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172702.270 559096.374 172702.370 559097.631 172688.531 559098.734 172689.044 559105.174 172687.472 559105.569 172686.782 559097.608 172702.270 559096.374</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="b4de94579-da31-64ec-47d7-898989eab3bf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e6fda5102f954b1ebc6231b70a729b8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172687.603 559107.078 172689.167 559106.714 172689.804 559114.715 172688.294 559115.054 172687.603 559107.078</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bcf97089c-f62a-b68c-95e4-403d0835fb51">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T12:16:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-08-16T09:39:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e6fda5102f954b1ebc6231b70a729b8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172687.603 559107.078 172689.167 559106.714 172689.804 559114.715 172688.294 559115.054 172687.603 559107.078</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="ba0aaa1cf-cb09-55fb-ac99-cc8c52cfe5af">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-06-13</creationDate>
            <imgeo:LV-publicatiedatum>2025-07-11T11:46:48</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-06-13T12:06:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c110de7e54e64bb1af8da7fb3979677a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172847.049 559050.293 172848.438 559055.330 172852.510 559105.243 172853.789 559121.449 172853.793 559121.478 172853.793 559121.489 172852.543 559121.662 172851.329 559105.959 172847.178 559055.702 172845.826 559050.608 172847.049 559050.293</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
    <cityObjectMember>
        <SolitaryVegetationObject xmlns="http://www.opengis.net/citygml/vegetation/2.0" gml:id="bde45dc29-8f8a-5f16-9999-83f2b75a073e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-06-13</creationDate>
            <imgeo:LV-publicatiedatum>2025-07-11T11:46:48</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-06-13T12:06:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e144f1616e2e4ac4a1ee5c62be720e55</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObject">niet-bgt</class>
            <imgeo:geometrie2dVegetatieObject><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172853.513 559143.639 172853.804 559147.278 172848.810 559147.663 172848.748 559146.897 172851.242 559146.697 172853.094 559146.549 172852.859 559143.679 172853.513 559143.639</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dVegetatieObject>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeVegetatieObjectPlus">haag</imgeo:plus-type>
        </SolitaryVegetationObject>
    </cityObjectMember>
</CityModel>