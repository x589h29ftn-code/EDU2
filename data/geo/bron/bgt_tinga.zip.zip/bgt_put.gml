<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Put gml:id="b0c09a819-cee3-00d4-671e-0bd8edd1e4ed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:22:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0a56288c8f5448138e1b75cfddd30bb4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173091.153 559560.659</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bf65c0801-3ba8-454a-7c95-85239229d4e8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:28:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.239524be9e264affafaf77f6c1da379e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173398.308 559578.617</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b741254d0-978d-0a03-52df-81a3b6d716c4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T14:59:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4abe3758d13b48be9c0ac57e2a8211e8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173183.141 559552.522</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b2b652deb-3036-dbc8-a32f-83da891e2d73">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:23:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.57bde4e2adc24e61adba3066959fd3df</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173146.340 559555.728</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bc1e53d34-8d12-ccc5-7c51-ecb39a5cd77c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:18:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5a78b4c84cce418eb825d3fd31b02049</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173032.507 559628.192</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bbdda42b9-cfb0-e797-9e16-cc640d2c48ac">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:27:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5f87d7021a7c4179885f22a9d8f29811</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173355.526 559582.428</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b54d24be9-07a7-637f-875c-675b156ae2cd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-07-20T16:40:20</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T14:55:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.62ba55207b8f41d2b95f452a3035eeb5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173475.162 559625.579</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="ba1cfa15d-8505-2f59-e725-1af842d47923">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:25:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.65fb7b14d3774ae3b5e5824c61692be4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173248.827 559571.336</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b94f369a7-a90a-a3ff-5af0-20caefaf74b1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T14:54:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6b11a9bf90304383ad386c129d3442e0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173468.545 559605.872</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b46ca8da8-dd85-1103-830f-ed31b1011797">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:26:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6c180860d9ce42e381f1569d109cd3f4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173273.895 559589.489</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b1be59af6-0cc0-5897-374f-1675f7e6c9c1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-09-27T14:20:01</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T13:18:10.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8266cd278ccf4de3adc538c72b539dbd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173013.885 559630.800</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bc2c48324-3334-ebea-6c96-c68ceb491065">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:20:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8c7ab52e0ac342df93351aa9aa10f1c9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173055.371 559568.609</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b09d415fc-4858-c1f6-ad98-a2c325ce6aba">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:24:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.982e6b3f0baa4a4bac8c52c6bc13b7eb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173219.973 559549.349</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b2728ec6b-6041-1c72-d3d7-5fa5a23e52e1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:23:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9f60be16b38447a5b906e6d8064ae20c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173127.896 559557.384</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b8ec23663-a778-c33c-3bc8-f59b270c188a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:19:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a5488f226b4d4b74ad0b950ba6244e4a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173031.545 559615.725</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bfd98685d-1be2-b0ca-c2ba-534d40d2c36d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:33:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ab00c6e3dc8045a4b303404066b850f2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173417.399 559583.365</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b30612675-fec9-4db7-87b0-e19012c4aa5d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:19:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.acf05c6323694a7b9f7e29bc2dc9fa3d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173041.723 559580.979</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b3ec9e312-9d63-dc6b-d9fb-819ea9a435b4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:21:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.afa88c83d5c843cdade142553d38cd1e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173072.708 559562.473</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b2836babf-6659-41be-43cd-19b3f5ddd5d5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:22:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b4349f889fd2488e96717b84ecf8e580</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173109.536 559559.016</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b4f611a58-d5be-8b86-ad08-908efce889cd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:26:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b53ef23f96b44a50a2875fe650794f81</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173295.359 559587.687</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bf9b42972-29e2-fe64-ac72-01985b59ab26">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:27:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c0975e7f7d35480b823967aceba26309</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173335.134 559584.181</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b8b5b487f-aebd-52c0-7ec5-0f67328b8887">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:23:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c9ba45c4122c4613b19e34f5c065682d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173164.712 559554.085</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b6a16b672-28c7-11ef-0738-0f01c314beaf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:24:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cbf6229d5fe54e6eb8e123e34eb7fb8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173237.578 559554.328</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b0398a5e9-c098-7c9d-552f-57e5690c067f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:25:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cc8f1a4eb7bf465d99488dd02ba26283</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173259.334 559585.021</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b18453ec9-91eb-8200-4e57-bfc349bcd7ff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:24:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d10ed19aa23c487a895b0d6b356324c4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173201.565 559550.883</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b1bbb29e2-d56e-a9b9-05fe-dbbcf6d8643e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-09-27T14:20:01</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T13:17:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dbe803df1f9b4677987bb95c22ff5071</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173002.926 559628.864</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b60446247-f259-18f7-60d7-97eecb535456">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:29:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ddaf9de1071146b491052a7e9b0b44fd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173416.668 559576.998</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b5a4acbb7-1901-3661-903b-2d952e7ca093">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:19:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f3e5a954f8f24349ba8f6fb8e72d61fa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173033.444 559597.378</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b1c88a336-f4ae-a184-9c1f-7560a352051b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:28:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fc298c0286ac4f05a7577c1e04e90cbd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173376.917 559580.467</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bc821ab28-1eee-77ad-5b32-0ade0a9f7907">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:33:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fc62528ad084483898961d9609ba2eec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173436.832 559588.137</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bb89514ff-e356-f93b-f89c-62ef871531d4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-19T13:26:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fe136823dbdb4b45a21b3960da73126d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173316.762 559585.824</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b1558e1fd-34f1-910e-e510-ce40fe95337e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.12a5a6da884946279c57681aa29aa423</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172873.568 558273.276</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bbd9d5f10-231d-0abf-d840-992b33230d06">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.207baec21b4641758cd69d225f9cb85c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172849.980 558302.661</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b898be9c7-4914-bc60-a5a9-9f440b3d3fe0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.94e288f6950e4632a470deac21f57421</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172873.623 558279.600</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b4ba45307-8d93-6151-af74-b608189da2d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.9cc631c110ed4c04adf8f5e5edc6dc75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172870.942 558291.492</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bd7171c39-40cb-938d-d4d9-befebe4cf839">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.a22babaae024422e809b16ed6a2e19d8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172850.514 558282.746</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="ba99ba5c5-6a63-aaf6-7b0d-cb44a35ebfcf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.c1541fdc470d44ca97af10f801dfee16</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172888.936 558273.402</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b6f75cba8-d324-6d72-9062-374610d4981a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-01-03</creationDate>
            <imgeo:LV-publicatiedatum>2017-01-05T13:02:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-01-05T10:32:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.cc2a2dbca8dc43d9aab53f70263e0601</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">172868.083 558303.697</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bfe170cf8-dea4-4c08-bb58-f888ac119a65">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-09-27T14:20:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8266cd278ccf4de3adc538c72b539dbd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173013.848 559630.784</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="bf3b504d4-7874-b090-df17-f517100a1002">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-09-27T14:20:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dbe803df1f9b4677987bb95c22ff5071</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173002.889 559628.855</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Put gml:id="b445e5381-e798-3b0d-c1b6-077c1a8be417">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-19</creationDate>
            <imgeo:LV-publicatiedatum>2021-07-20T17:00:45</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2021-07-20T16:40:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.62ba55207b8f41d2b95f452a3035eeb5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePut">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePutPlus">kolk</imgeo:plus-type>
            <imgeo:geometrie2dPut><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">173475.173 559625.530</gml:pos></gml:Point></imgeo:geometrie2dPut>
        </imgeo:Put>
    </cityObjectMember>
</CityModel>