<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bdae66f41-c599-dee3-cd8d-8b7700651c84">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.5e08829a55714ec094b140ed653e7146</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170377.339 558677.750 170415.429 558709.584</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b53769917-8c44-3d0d-0a00-e645dc090832">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf6325528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170375.562 558670.817 170371.098 558666.119 170365.611 558660.342</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be527b7bb-c16a-1e38-efa6-20ac4ffccba0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:24:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf47a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170368.751 558657.297 170371.532 558664.195 170375.946 558668.806 170377.917 558670.875</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bc0cb8ea3-b9e7-7a8b-d474-d8a24e69a49a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:20:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4755528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170378.442 558670.676 170379.933 558668.840</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9138ca35-b1a4-f44d-06b8-a94b810b94b2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:27:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4fd5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170382.321 558670.884 170380.842 558672.708</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b26ff286d-d356-9934-b870-34110a0c13b5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:34:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4dc5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170413.210 558711.991 170413.919 558711.171 170414.427 558710.583 170415.085 558709.821</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be8db9111-90be-46e3-f0c1-d9350d0ce08a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93c1b997d213255802c2cc00320d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170507.727 558187.613 170499.547 558186.622 170493.474 558185.788 170446.807 558179.372 170429.103 558172.752 170417.808 558167.960</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3b30eb60-00e4-75c6-f692-f92eac3b3573">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:47.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.71c5cd511fc64ecd98a22309cf1aa123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170272.293 558600.020 170267.934 558596.310</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfd4dc592-6795-8681-b108-ff8094ccf085">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:20:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4935528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170333.513 558637.034 170331.288 558639.611</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bec6a6d90-63fd-2c08-3853-4aa070d5ced9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:26:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf62d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170328.912 558637.686 170331.091 558635.031</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be5b9217d-70e3-9827-ba4b-b31b7b14004b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:34:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf60c5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170321.020 558635.242 170321.579 558634.574 170321.954 558634.126 170322.383 558633.613 170322.951 558632.934</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba71fae42-67b9-8908-b927-28135ddf3fa1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:23:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf58d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170318.365 558624.220 170320.490 558628.501 170321.163 558630.037 170322.365 558631.418</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b71b17b30-a3d8-30f3-ae96-46ac98658521">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-04-04</creationDate>
            <imgeo:LV-publicatiedatum>2022-05-30T14:08:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-04-04T10:30:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.db819a5858cb5a3fe0530b29a8c0ec8b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170352.138 558678.343 170352.942 558682.320 170353.402 558685.609</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bff26e1c2-e2a5-0981-cbe8-d7f1d97af01b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:30:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4fc5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170358.922 558662.738 170360.432 558660.963</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba801546d-2ddc-ffc1-dea4-62745c95b372">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:27:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf58e5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170362.835 558662.983 170361.295 558664.811</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd3ae5f32-3b9d-3d4b-a8c4-fd7cf9546ec9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-30</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-05-30T13:32:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.38c3ad9270f549738fb8ef148b9ee123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170364.846 558667.124 170364.513 558667.461</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b796a389f-311f-9271-270f-5df4cf285612">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-30</terminationDate>
            <imgeo:LV-publicatiedatum>2022-05-30T14:08:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-05-30T13:32:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.38c3ad9270f549738fb8ef148b9ee123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170364.846 558667.124 170364.513 558667.461</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b793520ae-55b7-2ba9-cdd0-118ae2ba5c9b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4745528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170352.138 558678.343 170344.514 558672.534 170335.754 558675.143 170332.563 558675.088</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b85b2f243-7060-05de-9e11-6578d142e821">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93c4bb40e34b255802c21a002c2a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170945.560 558211.030 170947.340 558206.109 170947.428 558205.054 170950.861 558191.862 170956.630 558165.929 170959.093 558155.214 170961.772 558144.660 170963.572 558135.550 170964.598 558129.226 170965.289 558122.609 170966.126 558117.144 170967.738 558112.264 170971.096 558105.677 170974.781 558097.971 170978.716 558089.511 170981.781 558082.442 170984.293 558076.621 170988.098 558067.312 170991.594 558057.601 170994.231 558049.665 170999.160 558035.263 171002.345 558026.739 171003.452 558027.213 171005.509 558022.389 171004.354 558022.012 171008.879 558012.626 171009.410 558011.469</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be17e6989-962e-cbb5-3723-f87d7027c825">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93c49dd947d9255802c2fe003485</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171010.422 558008.532 171011.038 558007.379 171024.795 557978.741 171033.227 557961.207 171039.967 557946.925 171050.790 557924.100 171066.800 557891.650 171075.802 557874.479 171078.209 557870.500 171082.103 557867.359 171088.738 557864.805 171095.908 557864.712</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4f935a90-12a6-530d-5572-74759ff83b06">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93c6702c9090255802c3bf003b85</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171125.590 558455.635 171129.448 558451.114 171131.619 558449.153 171134.842 558447.174 171138.213 558445.561 171141.107 558444.828 171143.928 558445.085 171148.177 558446.074 171156.017 558448.969 171160.569 558450.490 171167.053 558452.286 171172.036 558453.349 171190.985 558457.380 171207.653 558460.715 171211.390 558461.475 171215.969 558461.402 171217.775 558459.951 171219.342 558458.527 171219.545 558457.917 171219.585 558457.208 171219.530 558454.600 171219.480 558453.920 171219.415 558453.174 171219.373 558452.824 171219.176 558451.155 171218.862 558450.129 171218.443 558449.123 171213.590 558441.160 171213.140 558439.860 171211.970 558435.790 171211.450 558433.010 171211.230 558431.580 171211.220 558429.330 171211.882 558426.304 171216.242 558408.798 171217.762 558401.620 171218.727 558399.552 171220.570 558397.730 171225.235 558395.636 171228.145 558394.694 171232.080 558394.463 171236.749 558394.819 171239.889 558395.385 171246.860 558396.830 171251.800 558398.023 171260.509 558400.306 171267.480 558402.296 171274.765 558404.641 171281.108 558406.400 171287.765 558408.253 171298.462 558411.436 171305.998 558413.907 171309.452 558415.080 171312.069 558415.373 171314.309 558415.415 171316.235 558414.661 171318.391 558413.551 171319.396 558411.730 171320.170 558409.154 171318.039 558398.249 171316.490 558389.200 171316.370 558387.840 171315.385 558384.367 171312.210 558372.174 171310.694 558364.839 171310.133 558354.965 171312.327 558348.726 171314.232 558348.600 171314.808 558348.711 171317.497 558349.229 171319.067 558351.009 171319.804 558354.050 171320.317 558364.494 171320.793 558369.918 171322.442 558376.111 171324.164 558383.038 171325.849 558390.037 171326.508 558393.555 171326.508 558398.393 171326.655 558410.230 171326.728 558416.020 171326.240 558417.610 171325.602 558418.076</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b54f877d2-90ac-b1bf-fb6a-e3fdb299e2cb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93c56f2934c7255802c1fd002b66</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171539.252 557861.221 171540.711 557864.551 171542.011 557867.947 171543.150 557871.400 171544.201 557875.211 171545.054 557879.072 171545.708 557882.971 171546.125 557889.622 171546.144 557889.918 171546.160 557890.173 171546.121 557892.169 171546.040 557896.284 171546.029 557896.862 171546.019 557897.389 171545.794 557899.589 171545.507 557902.925 171545.426 557903.199 171545.437 557903.473 171545.415 557903.637 171545.342 557904.019 171545.286 557904.568 171541.891 557925.348 171540.938 557931.184 171539.988 557937.592 171538.480 557949.440 171536.134 557963.761 171535.749 557966.106 171535.611 557966.952 171532.082 557988.487 171530.196 558000.000 171528.020 558013.280 171525.357 558029.337 171522.054 558049.249 171521.800 558050.780 171521.180 558055.922 171519.572 558065.284 171515.097 558068.118</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b08359aea-bb9e-002b-373f-7a92306beeac">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f5a840ad9a448b99048623c3f81350b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171994.181 559897.278 171993.715 559896.631 171997.479 559894.092 172001.587 559891.241 172005.711 559888.415 172009.826 559885.575 172013.949 559882.745 172018.069 559879.913 172022.186 559877.076 172026.307 559874.243 172030.426 559871.410 172034.542 559868.571 172038.657 559865.732 172042.765 559862.879 172046.887 559860.050 172050.999 559857.206 172055.122 559854.376 172059.235 559851.534 172063.349 559848.692 172067.462 559845.849 172071.587 559843.022 172075.707 559840.190 172076.106 559840.786 172073.041 559842.891 172068.659 559845.919 172064.527 559848.726 172061.251 559851.021 172057.972 559853.313 172054.683 559855.589 172051.386 559857.854 172049.983 559858.808 172036.768 559867.898 172036.550 559868.048 172034.077 559869.677 172031.538 559871.349 172028.268 559873.653 172024.982 559875.934 172021.731 559878.266 172018.438 559880.537 172013.520 559883.974 172011.240 559885.516 172010.206 559886.215 172006.924 559888.502 172003.648 559890.795 172001.230 559892.501 172000.379 559893.101 172000.244 559893.192 171997.062 559895.337 171994.181 559897.278</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b14c6ef11-d988-865b-7f96-2f733af92eb8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f5a840ad9a448b99048623c3f81350b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171994.181 559897.278 171993.715 559896.631 171997.479 559894.092 172001.587 559891.241 172005.711 559888.415 172009.826 559885.575 172013.949 559882.745 172018.069 559879.913 172022.186 559877.076 172026.307 559874.243 172030.426 559871.410 172034.542 559868.571 172038.657 559865.732 172042.765 559862.879 172046.887 559860.050 172050.999 559857.206 172055.122 559854.376 172059.235 559851.534 172063.349 559848.692 172067.462 559845.849 172071.587 559843.022 172075.707 559840.190 172076.106 559840.786 172073.041 559842.891 172068.659 559845.919 172064.527 559848.726 172061.251 559851.021 172057.972 559853.313 172054.683 559855.589 172051.386 559857.854 172049.983 559858.808 172036.768 559867.898 172036.550 559868.048 172034.077 559869.677 172031.538 559871.349 172028.268 559873.653 172024.982 559875.934 172021.731 559878.266 172018.438 559880.537 172013.520 559883.974 172011.240 559885.516 172010.206 559886.215 172006.924 559888.502 172003.648 559890.795 172001.230 559892.501 172000.379 559893.101 172000.244 559893.192 171997.062 559895.337 171994.181 559897.278</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf38b2d7c-fe6a-5a9c-1ca2-5e7c0efd9fad">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f5a840ad9a448b99048623c3f81350b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172034.077 559869.677 172031.538 559871.349 172028.268 559873.653 172024.982 559875.934 172021.731 559878.266 172018.438 559880.537 172013.520 559883.974 172011.240 559885.516 172010.206 559886.215 172006.924 559888.502 172003.648 559890.795 172001.230 559892.501 172000.379 559893.101 172000.244 559893.192 171997.062 559895.337 171994.181 559897.278 171993.715 559896.631 171997.479 559894.092 172001.587 559891.241 172005.711 559888.415 172009.826 559885.575 172013.949 559882.745 172018.069 559879.913 172022.186 559877.076 172026.307 559874.243 172026.509 559874.104 172030.426 559871.410 172034.542 559868.571 172038.657 559865.732 172042.765 559862.879 172046.887 559860.050 172050.999 559857.206 172055.122 559854.376 172059.235 559851.534 172063.349 559848.692 172067.462 559845.849 172071.587 559843.022 172075.707 559840.190 172076.106 559840.786 172073.041 559842.891 172068.659 559845.919 172064.527 559848.726 172061.251 559851.021 172057.972 559853.313 172054.683 559855.589 172051.386 559857.854 172049.983 559858.808 172036.768 559867.898 172036.550 559868.048 172034.077 559869.677</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b68887646-69c9-d1d5-1c37-bdcf5292b75e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf6585528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170778.981 558994.237 170773.164 558989.341</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0c283431-c0fd-3fc3-8399-a1ecad5f11e6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf54d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170778.981 558994.237 170783.391 558997.749 170794.033 559006.760 170797.940 559010.395 170808.497 559019.089 170816.971 559025.832 170821.511 559028.614 170828.098 559034.360 170838.179 559042.980 170846.747 559050.186 170857.896 559058.896 170865.477 559065.103 170883.714 559079.902 170893.893 559088.658 170899.044 559093.600 170902.659 559095.809 170928.217 559116.699 170947.416 559132.526 170960.538 559143.823 170980.186 559159.942 171013.540 559187.879</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8c52f987-e051-4689-7fa0-1ac80b2f6530">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-31T10:49:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.31aa09e04bc44d26827e377d90b1e6de</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171044.979 559233.385 171045.857 559234.129</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7101cce6-b288-0fe2-2f67-f8dc78eabfcf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:35:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf60d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171045.298 559254.578 171048.784 559257.660 171049.280 559260.506</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b21ea560d-abed-e2dd-3c27-c2a82f287957">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:35:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf60d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171045.298 559254.578 171048.784 559257.660 171049.280 559260.506</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7dd42236-eca6-5fcc-8d93-3854178c79cb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-31T10:49:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.5cf33a648ba04b33a81da672d19ab896</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171050.307 559237.912 171049.455 559237.155</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5af93272-948b-fe60-cc44-883f7cd8574b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-31T10:49:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.a26a4a8c98b846deb3420271f9848ef3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171038.593 559251.306 171037.814 559250.405</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b153939a9-e737-d5ba-b397-05a7d2035589">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-31T10:49:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.0adab05397694647a05fcf44f40408d5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171035.840 559244.294 171036.809 559245.073</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5ca4ff6c-c036-7ee7-117e-e5986eefb083">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:27:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4965528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171032.819 559256.704 171034.374 559257.720 171037.786 559260.200</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bb1848eae-68a4-9819-f602-8472919dad8c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:27:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4965528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171032.819 559256.704 171034.374 559257.720 171037.786 559260.200</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1dd824be-c076-c6d9-9476-cf60fb5b47d4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:25:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5505528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171086.927 559249.853 171095.403 559257.047 171104.162 559264.537 171106.634 559267.091 171112.498 559271.602 171124.974 559282.055 171131.086 559287.471 171149.090 559302.055 171164.804 559314.964 171171.201 559320.578 171184.368 559331.982 171196.063 559341.818 171211.881 559355.018 171221.867 559363.444 171229.618 559369.746 171233.706 559373.125 171246.702 559384.306 171250.702 559387.560 171260.766 559396.102 171268.617 559402.829 171276.485 559409.206 171280.490 559412.727 171290.393 559420.816 171300.712 559429.280 171307.009 559434.462 171312.528 559439.510 171318.767 559444.467 171330.565 559454.364 171342.028 559464.410 171350.186 559471.141 171381.526 559497.490 171387.317 559502.382 171396.937 559510.518 171404.964 559517.166 171412.889 559523.850 171418.845 559528.722 171426.645 559535.418 171430.117 559538.301 171434.727 559541.964 171444.625 559550.254 171452.085 559556.341 171454.313 559554.483</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0b9574d7-9a43-e9ee-86f2-136a3aa6e680">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:19:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5025528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171416.374 559583.926 171418.896 559585.930</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd8c97e77-434e-669f-58df-f7c59ec9cb3d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:28:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5515528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171417.927 559585.760 171418.749 559587.377 171419.993 559587.698</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3e6455e8-30e6-8528-ccb3-89b28c495a3b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5325528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171441.083 559567.163 171441.427 559567.418 171441.592 559567.573 171442.248 559568.192 171440.091 559571.278 171436.850 559574.969 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b63e54409-2be7-e7e0-ba31-aa558f43fffa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5325528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171441.083 559567.163 171441.427 559567.418 171441.592 559567.573 171442.248 559568.192 171440.091 559571.278 171436.850 559574.969 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b353c264f-42ef-6993-b938-ae0a268c358e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.35b036bef00e4cff8e0af3981669dc39</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171441.592 559567.573 171440.149 559570.021 171435.525 559575.439 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b450b56d5-b2c8-5b4c-930a-b092e4b2c22d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.35b036bef00e4cff8e0af3981669dc39</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171441.592 559567.573 171440.149 559570.021 171435.525 559575.439 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b769f6030-241a-5565-a6d5-586ab8654e25">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-16</creationDate>
            <imgeo:LV-publicatiedatum>2024-09-18T09:51:44</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-09-16T12:42:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.217498c79a093eb0e0630b29a8c05128</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171436.457 559573.965 171440.675 559577.464</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3eb352b5-2087-6b75-2f80-286dfaf15412">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:22:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5cf5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171436.510 559574.042 171440.710 559577.547</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf227c6f6-2e54-85e9-ac34-ab6f6570f03a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:22:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5cf5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171436.510 559574.042 171440.710 559577.547</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b33c5887e-4e5e-b42b-b4b0-d4bd40892ed4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4d38397500354f6eb70f05b5cfc52aa9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171437.874 559582.468 171436.733 559581.480</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be24c44da-ea7e-f083-fb82-be1d730252f1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4d38397500354f6eb70f05b5cfc52aa9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171437.874 559582.468 171436.733 559581.480</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b53f10e69-57ea-5f31-7455-92ff4fd02eb3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b32e8e3d79a84897a1634afa6f4dcd97</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171432.311 559577.716 171433.216 559578.555 171435.244 559576.798 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1dfb5ec5-ab62-3de8-9ac7-30dc58e4cd3d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b32e8e3d79a84897a1634afa6f4dcd97</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171432.311 559577.716 171433.216 559578.555 171435.244 559576.798 171436.038 559575.874</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6121db2d-b601-b75c-64e3-0a7afe8006c0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4e0154a661c74a07902edf61762179ee</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171445.637 559571.097 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be25d6a4f-1732-b83a-582a-1e76b19d356b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4e0154a661c74a07902edf61762179ee</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171445.637 559571.097 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd1348a47-c9a7-7e76-e32e-b550493d1ac6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b7aed21501314c7dbadc43038661fdb8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171446.056 559571.347 171446.746 559571.757</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba80194b9-9301-26c7-ead0-49845112e278">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b7aed21501314c7dbadc43038661fdb8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171446.056 559571.347 171446.746 559571.757</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bed57b0a9-9d20-2d67-bd8d-21fb59bd483a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9fb4f3ebea56460fbb44525817f52887</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171439.234 559578.587 171439.484 559578.799 171444.041 559573.246 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b43db8a3d-9f28-08a9-5e23-d31a97776fe7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9fb4f3ebea56460fbb44525817f52887</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171439.234 559578.587 171439.484 559578.799 171444.041 559573.246 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6cb2ebd3-7bad-1345-65d2-887402133877">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf60e5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171436.733 559581.480 171438.643 559579.271 171439.234 559578.587 171443.396 559573.083 171445.594 559570.955 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be5a3bd1e-83c0-5847-6458-bcc0f55c3106">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-11-09</terminationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:28:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf60e5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171436.733 559581.480 171438.643 559579.271 171439.234 559578.587 171443.396 559573.083 171445.594 559570.955 171446.056 559571.347</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b27e2d7bf-d782-1ab4-7bc1-b7987a7f4314">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:24:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b89449a2bf4d4a33b41868cc8cc88123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171755.697 559839.732 171751.361 559836.127</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b33ce38e4-53e9-3bcd-f92d-ae51433f6e98">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf58f5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171463.530 559566.594 171470.795 559572.368 171478.940 559579.452 171488.572 559587.509 171498.879 559596.223 171514.578 559608.447 171519.898 559612.742 171522.258 559615.713 171527.951 559620.525 171534.072 559626.142 171540.823 559631.419 171549.761 559638.878 171557.712 559645.406 171563.708 559650.122 171569.228 559655.390 171580.978 559665.383 171596.998 559678.271 171612.875 559691.492 171627.331 559703.728 171636.592 559711.557 171655.955 559727.530 171673.222 559742.149 171686.649 559753.773 171696.302 559761.151 171703.956 559767.662 171717.199 559779.234 171726.819 559787.050 171736.676 559794.918 171738.271 559796.684 171741.081 559799.375</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b41835868-c34e-7f51-2e7a-1c8ccca0696c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:00:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f968f6629534123ac605b5a0ca0b9f8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171993.115 559898.004 171983.875 559904.339 171978.944 559907.736 171972.332 559912.283 171965.691 559916.728 171960.746 559920.071 171957.064 559922.518 171956.623 559921.881 171960.283 559919.436 171964.450 559916.674 171968.098 559914.229 171968.593 559913.873 171972.743 559911.065 171976.862 559908.233 171980.995 559905.419 171985.113 559902.582 171989.235 559899.752 171992.543 559897.440 171993.115 559898.004</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8bca01ac-e684-3fdd-4aab-67ff2656e586">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T12:00:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f968f6629534123ac605b5a0ca0b9f8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171993.115 559898.004 171983.875 559904.339 171978.944 559907.736 171972.332 559912.283 171965.691 559916.728 171960.746 559920.071 171957.064 559922.518 171956.623 559921.881 171960.283 559919.436 171964.450 559916.674 171968.098 559914.229 171968.593 559913.873 171972.743 559911.065 171976.862 559908.233 171980.995 559905.419 171985.113 559902.582 171989.235 559899.752 171992.543 559897.440 171993.115 559898.004</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b787f7708-e175-31e1-79ac-2d3697a9f463">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.2f968f6629534123ac605b5a0ca0b9f8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171993.115 559898.004 171983.875 559904.339 171978.944 559907.736 171972.332 559912.283 171965.691 559916.728 171960.746 559920.071 171957.064 559922.518 171956.623 559921.881 171960.283 559919.436 171964.450 559916.674 171968.098 559914.229 171968.593 559913.873 171972.743 559911.065 171976.862 559908.233 171980.995 559905.419 171985.113 559902.582 171989.235 559899.752 171992.543 559897.440 171993.115 559898.004</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf85ee564-b39f-4345-0e3c-5d6c129ee539">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8ea78261714041dfbb3b7ad97661d529</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172007.162 559876.535 172004.870 559878.144 172000.818 559881.075 171996.751 559883.988 171992.696 559886.915 171988.596 559889.778 171987.395 559890.609 171986.568 559889.501 171989.874 559887.223 171994.038 559884.455 171998.219 559881.711 172002.394 559878.958 172006.577 559876.217 172006.865 559876.018 172007.162 559876.535</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd1a40475-4fcd-d0ee-ce95-1cf318ef081f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8ea78261714041dfbb3b7ad97661d529</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172007.162 559876.535 172004.870 559878.144 172000.818 559881.075 171996.751 559883.988 171992.696 559886.915 171988.596 559889.778 171987.395 559890.609 171986.568 559889.501 171989.874 559887.223 171994.038 559884.455 171998.219 559881.711 172002.394 559878.958 172006.577 559876.217 172006.865 559876.018 172007.162 559876.535</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b70bf2f9d-79db-b538-6530-0352b4fca88d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8ea78261714041dfbb3b7ad97661d529</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172007.162 559876.535 172004.870 559878.144 172000.818 559881.075 171996.751 559883.988 171992.696 559886.915 171988.596 559889.778 171987.395 559890.609 171986.568 559889.501 171989.874 559887.223 171994.038 559884.455 171998.219 559881.711 172002.394 559878.958 172006.577 559876.217 172006.865 559876.018 172007.162 559876.535</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9480bf34-7d25-4cb0-d647-782ae8ad901b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:18</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0b525569440c40e2b870452cedea4cfd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172067.136 559852.196 172065.247 559853.526 172062.777 559855.247 172059.483 559857.517 172057.832 559858.646 172051.253 559863.198 172047.138 559866.037 172043.027 559868.890 172038.089 559872.298 172030.692 559877.395 172024.107 559881.937 172015.848 559887.616 172010.920 559891.001 172007.631 559893.278 172003.504 559896.103 172001.851 559897.230 172000.196 559898.352 171997.719 559900.046 171997.058 559900.507 171996.285 559901.036</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfeecfc44-4bf4-838a-e376-a3106cc5638c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0b525569440c40e2b870452cedea4cfd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172067.136 559852.196 172065.247 559853.526 172062.777 559855.247 172059.483 559857.517 172057.832 559858.646 172051.253 559863.198 172047.138 559866.037 172043.027 559868.890 172038.089 559872.298 172030.692 559877.395 172024.107 559881.937 172015.848 559887.616 172010.920 559891.001 172007.631 559893.278 172003.504 559896.103 172001.851 559897.230 172000.196 559898.352 171997.719 559900.046 171997.058 559900.507 171996.285 559901.036</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="befcd3ecd-d3eb-3e72-2077-16c9d9122066">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T21:00:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f8c0a7ce317a4887bfcbd0cd36f66ec4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171970.909 559876.558 171971.225 559876.369 171972.390 559877.515 171978.372 559883.407 171978.703 559883.734 171978.933 559883.576 171981.262 559881.970 171988.432 559877.052 171997.849 559870.559 172006.692 559864.452 172017.642 559856.893 172027.360 559850.196 172036.199 559844.088 172045.270 559837.817 172053.383 559832.243 172053.595 559832.551 172049.928 559835.037 172049.864 559835.081 172045.800 559837.875 172045.750 559837.910 172041.686 559840.716 172041.635 559840.751 172037.558 559843.558 172037.526 559843.580 172033.442 559846.407 172029.311 559849.250 172025.187 559852.095 172021.102 559854.922 172021.067 559854.946 172016.975 559857.761 172016.957 559857.773 172012.850 559860.607 172008.732 559863.443 172004.645 559866.253 172004.581 559866.297 172000.507 559869.094 172000.472 559869.118 171996.372 559871.942 171992.280 559874.767 171992.234 559874.798 171988.143 559877.602 171988.123 559877.616 171984.042 559880.415 171983.977 559880.460 171979.939 559883.272 171979.875 559883.316 171978.976 559883.935 171979.181 559884.136 171979.860 559884.805 171982.348 559887.255 171984.806 559889.677 171985.426 559890.288 171986.430 559891.277 171987.027 559891.865 171989.500 559894.300 171991.959 559896.723 171992.521 559897.277 171992.627 559897.382 171993.199 559897.945 171993.417 559898.160 171994.399 559899.127 171995.400 559900.113 171996.243 559900.943 171996.527 559900.749 171999.402 559898.781 172005.148 559894.879 172015.895 559887.469 172027.803 559879.283 172037.759 559872.438 172038.590 559871.867 172038.970 559871.606 172051.340 559863.005 172055.327 559860.232 172060.417 559856.729 172063.146 559854.850 172067.135 559852.105 172067.296 559852.335 172054.794 559860.977 172040.169 559871.101 172030.953 559877.452 172017.794 559886.524 172004.213 559895.888 172001.118 559897.982 171997.541 559900.403 171996.411 559901.180 172003.069 559907.736 172003.424 559908.054 172003.903 559908.560 172003.674 559908.822 171970.909 559876.558</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6eb8208a-890a-2132-23d9-fe6208955a5e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-21T11:04:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T21:00:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f8c0a7ce317a4887bfcbd0cd36f66ec4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171970.909 559876.558 171971.225 559876.369 171972.390 559877.515 171978.372 559883.407 171978.703 559883.734 171978.933 559883.576 171981.262 559881.970 171988.432 559877.052 171997.849 559870.559 172006.692 559864.452 172017.642 559856.893 172027.360 559850.196 172036.199 559844.088 172045.270 559837.817 172053.383 559832.243 172053.595 559832.551 172049.928 559835.037 172049.864 559835.081 172045.800 559837.875 172045.750 559837.910 172041.686 559840.716 172041.635 559840.751 172037.558 559843.558 172037.526 559843.580 172033.442 559846.407 172029.311 559849.250 172025.187 559852.095 172021.102 559854.922 172021.067 559854.946 172016.975 559857.761 172016.957 559857.773 172012.850 559860.607 172008.732 559863.443 172004.645 559866.253 172004.581 559866.297 172000.507 559869.094 172000.472 559869.118 171996.372 559871.942 171992.280 559874.767 171992.234 559874.798 171988.143 559877.602 171988.123 559877.616 171984.042 559880.415 171983.977 559880.460 171979.939 559883.272 171979.875 559883.316 171978.976 559883.935 171979.181 559884.136 171979.860 559884.805 171982.348 559887.255 171984.806 559889.677 171985.426 559890.288 171986.430 559891.277 171987.027 559891.865 171989.500 559894.300 171991.959 559896.723 171992.521 559897.277 171992.627 559897.382 171993.199 559897.945 171993.417 559898.160 171994.399 559899.127 171995.400 559900.113 171996.243 559900.943 171996.527 559900.749 171999.402 559898.781 172005.148 559894.879 172015.895 559887.469 172027.803 559879.283 172037.759 559872.438 172038.590 559871.867 172038.970 559871.606 172051.340 559863.005 172055.327 559860.232 172060.417 559856.729 172063.146 559854.850 172067.135 559852.105 172067.296 559852.335 172054.794 559860.977 172040.169 559871.101 172030.953 559877.452 172017.794 559886.524 172004.213 559895.888 172001.118 559897.982 171997.541 559900.403 171996.411 559901.180 172003.069 559907.736 172003.424 559908.054 172003.903 559908.560 172003.674 559908.822 171970.909 559876.558</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b43f5cda7-3e58-f1a9-f63e-114bdfe5cab4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-21T11:09:33</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-03-10T12:09:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-21T11:04:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f8c0a7ce317a4887bfcbd0cd36f66ec4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171970.909 559876.558 171971.225 559876.369 171972.390 559877.515 171978.372 559883.407 171978.703 559883.734 171978.933 559883.576 171981.262 559881.970 171988.432 559877.052 171997.849 559870.559 172006.692 559864.452 172017.642 559856.893 172027.360 559850.196 172036.199 559844.088 172045.270 559837.817 172053.383 559832.243 172053.595 559832.551 172049.928 559835.037 172049.864 559835.081 172045.800 559837.875 172045.750 559837.910 172041.686 559840.716 172041.635 559840.751 172037.558 559843.558 172037.526 559843.580 172033.442 559846.407 172029.311 559849.250 172025.187 559852.095 172021.102 559854.922 172021.067 559854.946 172016.975 559857.761 172016.957 559857.773 172012.850 559860.607 172008.732 559863.443 172004.645 559866.253 172004.581 559866.297 172000.507 559869.094 172000.472 559869.118 171996.372 559871.942 171992.280 559874.767 171992.234 559874.798 171988.143 559877.602 171988.123 559877.616 171984.042 559880.415 171983.977 559880.460 171979.939 559883.272 171979.875 559883.316 171978.976 559883.935 171979.181 559884.136 171985.426 559890.288 171986.430 559891.277 171992.627 559897.382 171993.199 559897.945 171993.417 559898.160 171994.399 559899.127 171995.400 559900.113 171996.243 559900.943 171996.527 559900.749 171999.402 559898.781 172005.148 559894.879 172015.895 559887.469 172027.803 559879.283 172037.759 559872.438 172038.590 559871.867 172038.970 559871.606 172051.340 559863.005 172055.327 559860.232 172060.417 559856.729 172063.146 559854.850 172067.135 559852.105 172067.296 559852.335 172054.794 559860.977 172040.169 559871.101 172030.953 559877.452 172017.794 559886.524 172004.213 559895.888 172001.118 559897.982 171997.541 559900.403 171996.411 559901.180 172003.069 559907.736 172003.424 559908.054 172003.903 559908.560 172003.674 559908.822 171970.909 559876.558</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8cdc4123-3a2e-de60-45c9-40422bdda431">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2023-03-10T12:16:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2023-03-10T12:09:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f8c0a7ce317a4887bfcbd0cd36f66ec4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171979.181 559884.136 171979.860 559884.805 171982.348 559887.255 171984.806 559889.677 171985.426 559890.288 171986.430 559891.277 171987.027 559891.865 171989.500 559894.300 171991.959 559896.723 171992.521 559897.277 171992.627 559897.382 171993.199 559897.945 171993.417 559898.160 171994.399 559899.127 171995.400 559900.113 171996.243 559900.943 171996.527 559900.749 171999.402 559898.781 172005.148 559894.879 172015.895 559887.469 172027.803 559879.283 172037.759 559872.438 172038.590 559871.867 172038.970 559871.606 172051.340 559863.005 172055.327 559860.232 172060.417 559856.729 172063.146 559854.850 172067.135 559852.105 172067.296 559852.335 172054.794 559860.977 172040.169 559871.101 172030.953 559877.452 172017.794 559886.524 172004.213 559895.888 172001.118 559897.982 171997.541 559900.403 171996.411 559901.180 172003.069 559907.736 172003.424 559908.054 172003.903 559908.560 172003.674 559908.822 171970.909 559876.558 171971.225 559876.369 171972.390 559877.515 171978.372 559883.407 171978.703 559883.734 171978.933 559883.576 171981.262 559881.970 171988.432 559877.052 171997.849 559870.559 172006.692 559864.452 172017.642 559856.893 172027.360 559850.196 172036.199 559844.088 172045.270 559837.817 172053.383 559832.243 172053.595 559832.551 172049.928 559835.037 172049.864 559835.081 172045.800 559837.875 172045.750 559837.910 172041.686 559840.716 172041.635 559840.751 172037.558 559843.558 172037.526 559843.580 172033.442 559846.407 172029.311 559849.250 172025.187 559852.095 172021.102 559854.922 172021.067 559854.946 172016.975 559857.761 172016.957 559857.773 172012.850 559860.607 172008.732 559863.443 172004.645 559866.253 172004.581 559866.297 172000.507 559869.094 172000.472 559869.118 171996.372 559871.942 171992.280 559874.767 171992.234 559874.798 171988.143 559877.602 171988.123 559877.616 171984.042 559880.415 171983.977 559880.460 171979.939 559883.272 171979.875 559883.316 171978.976 559883.935 171979.181 559884.136</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5bf08c2f-7695-6fbb-3b2c-d0312182aa37">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f8c0a7ce317a4887bfcbd0cd36f66ec4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171987.027 559891.865 171989.500 559894.300 171991.959 559896.723 171992.521 559897.277 171992.627 559897.382 171993.199 559897.945 171993.417 559898.160 171994.399 559899.127 171995.400 559900.113 171996.243 559900.943 171996.527 559900.749 171999.402 559898.781 172005.148 559894.879 172015.895 559887.469 172027.803 559879.283 172037.759 559872.438 172038.590 559871.867 172038.970 559871.606 172051.340 559863.005 172055.327 559860.232 172060.417 559856.729 172063.146 559854.850 172067.135 559852.105 172067.296 559852.335 172054.794 559860.977 172040.169 559871.101 172030.953 559877.452 172017.794 559886.524 172004.213 559895.888 172001.118 559897.982 171997.541 559900.403 171996.411 559901.180 172003.069 559907.736 172003.424 559908.054 172003.903 559908.560 172003.674 559908.822 171970.909 559876.558 171971.225 559876.369 171972.390 559877.515 171978.372 559883.407 171978.703 559883.734 171978.933 559883.576 171981.262 559881.970 171988.432 559877.052 171997.849 559870.559 172006.692 559864.452 172017.642 559856.893 172027.360 559850.196 172036.199 559844.088 172045.270 559837.817 172053.383 559832.243 172053.521 559832.444 172053.595 559832.551 172049.928 559835.037 172049.864 559835.081 172045.800 559837.875 172045.750 559837.910 172041.686 559840.716 172041.635 559840.751 172037.558 559843.558 172037.526 559843.580 172033.442 559846.407 172029.311 559849.250 172025.187 559852.095 172021.102 559854.922 172021.067 559854.946 172016.975 559857.761 172016.957 559857.773 172012.850 559860.607 172008.732 559863.443 172004.645 559866.253 172004.581 559866.297 172000.507 559869.094 172000.472 559869.118 171996.372 559871.942 171992.280 559874.767 171992.234 559874.798 171988.143 559877.602 171988.123 559877.616 171984.042 559880.415 171983.977 559880.460 171979.939 559883.272 171979.875 559883.316 171978.976 559883.935 171979.181 559884.136 171979.860 559884.805 171982.348 559887.255 171984.806 559889.677 171985.426 559890.288 171986.430 559891.277 171987.027 559891.865</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfcb2d402-1c06-1522-cf6d-053abffe6e58">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.60fa3db9d4014e24b4ad04f1591c99d2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171978.901 559883.825 171979.913 559883.138 171980.766 559882.546 171983.233 559880.839 171986.533 559878.577 171989.008 559876.883 171991.477 559875.180 171992.296 559874.607 171996.414 559871.771 171999.711 559869.505 172005.512 559865.530 172011.248 559861.579 172017.005 559857.597 172025.257 559851.902 172034.313 559845.666 172041.718 559840.551 172046.655 559837.142 172052.412 559833.188 172053.499 559832.459</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfcbb93cc-33c0-55df-664f-074a053241c0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.60fa3db9d4014e24b4ad04f1591c99d2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171978.901 559883.825 171979.913 559883.138 171980.766 559882.546 171983.233 559880.839 171986.533 559878.577 171989.008 559876.883 171991.477 559875.180 171992.296 559874.607 171996.414 559871.771 171999.711 559869.505 172005.512 559865.530 172011.248 559861.579 172017.005 559857.597 172025.257 559851.902 172034.313 559845.666 172041.718 559840.551 172046.655 559837.142 172052.412 559833.188 172053.499 559832.459</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b17e698f2-5efa-4402-84a0-464eeb054c38">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:26:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a25528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171910.497 559961.266 171906.552 559957.976</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3278940c-81b7-56f7-1709-f50e5f9919ce">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:26:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a25528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171910.497 559961.266 171906.552 559957.976</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba0163b5a-1866-12aa-ac18-c25e76d1562e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02bf91a98edf465da8f7b55fc0484b55</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.403 559958.055 171909.125 559956.614 171915.521 559952.966</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b66708cea-f536-95d3-13f3-72b13acbdd65">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02bf91a98edf465da8f7b55fc0484b55</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.403 559958.055 171909.125 559956.614 171915.521 559952.966</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b46622264-df77-54b2-3bab-c79eb1f161d4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ad8bfd783afb4b7f8c24b64005739d5f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171907.058 559965.539 171908.164 559966.456</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba92176aa-166d-4da8-a279-b0612edeb555">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ad8bfd783afb4b7f8c24b64005739d5f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171907.058 559965.539 171908.164 559966.456</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3e93e617-8713-c970-cf50-0149ba359955">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a35528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.844 559965.582 171909.075 559967.883</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbbeec952-2fc8-9bb0-a926-68a056edded8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a35528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.844 559965.582 171909.075 559967.883</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b661fb598-015a-8b29-ff9d-379e091082d4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2a7fe27560e34d15bf97fdfc3667ee64</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.144 559958.720 171909.616 559962.454 171910.450 559961.449 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be50c1437-2247-0584-806b-238091ee48b6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2a7fe27560e34d15bf97fdfc3667ee64</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.144 559958.720 171909.616 559962.454 171910.450 559961.449 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b753f78ce-ee91-178e-a695-f56d36499ecd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4415066c8b8b43bda3af5aad228fa9fc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.144 559958.720 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b844a27a5-91fb-5adf-0a59-4050021e362d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4415066c8b8b43bda3af5aad228fa9fc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.144 559958.720 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b657327b1-666d-47e9-b627-b1f704e3e63d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ddcafb320d424cb49b433b1fc7e112ac</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171901.329 559960.739 171907.058 559965.539</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3a3c8938-6d1d-0bb0-b5d0-6729fd75a9a9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ddcafb320d424cb49b433b1fc7e112ac</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171901.329 559960.739 171907.058 559965.539</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8dfbd6aa-b6e8-b80e-c0cd-a99d51260aaa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-01T10:47:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2cd39e1862ce4447afb54cccc3da2123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171921.212 559958.386 171915.521 559952.966</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be5c51585-d56e-04c4-03ba-05f50d687eff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-01T10:47:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2cd39e1862ce4447afb54cccc3da2123</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171921.212 559958.386 171915.733 559953.168</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4ea05607-a2d6-475a-bc40-61e7e6603acb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3464be38e5174ad4a49839075dd915d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171891.692 559966.135 171886.576 559968.723 171882.860 559970.540 171881.980 559970.971 171879.812 559972.028 171879.501 559972.179 171877.917 559972.944 171877.696 559973.052 171877.674 559972.731 171877.786 559972.674 171879.681 559971.759 171881.848 559970.701 171886.442 559968.454 171891.557 559965.867 171896.513 559963.354 171899.475 559961.815 171900.038 559961.522 171906.588 559957.992 171906.733 559957.914 171910.426 559955.900 171911.076 559955.540 171915.488 559952.934 171924.551 559947.739 171933.353 559942.550 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171951.098 559926.784 171950.878 559926.567 171950.920 559926.537 171951.316 559926.285 171951.808 559926.290 171954.644 559929.088 171954.867 559929.308 171954.145 559929.716 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171911.221 559955.802 171910.570 559956.162 171906.876 559958.178 171906.837 559958.199 171900.179 559961.787 171899.725 559962.023 171896.724 559963.582 171896.650 559963.621 171891.692 559966.135</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd4c85d50-947f-6067-8df6-fd1941830e95">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3464be38e5174ad4a49839075dd915d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171886.442 559968.454 171891.557 559965.867 171896.513 559963.354 171899.475 559961.815 171900.038 559961.522 171906.588 559957.992 171906.733 559957.914 171910.426 559955.900 171911.076 559955.540 171915.488 559952.934 171924.551 559947.739 171933.353 559942.550 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171954.644 559929.088 171954.867 559929.308 171954.145 559929.716 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171911.221 559955.802 171910.570 559956.162 171906.876 559958.178 171906.837 559958.199 171900.179 559961.787 171899.725 559962.023 171896.724 559963.582 171896.650 559963.621 171891.692 559966.135 171886.576 559968.723 171882.860 559970.540 171881.980 559970.971 171879.812 559972.028 171879.501 559972.179 171877.917 559972.944 171877.696 559973.052 171877.674 559972.731 171877.786 559972.674 171879.681 559971.759 171881.848 559970.701 171886.442 559968.454</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b76470df8-5826-e4ef-e0be-a5c7fc880a4f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ce69fb1e05e6403cbc8ec87bf5d89565</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171960.489 560010.530 171955.135 560006.197 171953.567 560007.943 171946.560 560002.094 171935.970 559993.472 171925.485 559984.641 171924.187 559986.506 171896.460 559963.363</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6bbb74dc-db2b-2ec1-e011-3b0a4d5c9df9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.ce69fb1e05e6403cbc8ec87bf5d89565</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171960.260 560010.345 171955.278 560006.313 171954.627 560007.092 171953.794 560008.090 171952.442 560006.969 171946.560 560002.094 171935.970 559993.472 171925.485 559984.641 171924.876 559985.516 171924.187 559986.506 171920.899 559983.762 171896.724 559963.582</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7e1387e7-10cf-1ab9-7f8a-6e7f06d1543b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:31:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4dd5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171935.848 559978.797 171935.093 559979.745 171934.142 559978.915 171935.022 559977.887</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bea819c90-526f-8f2e-95ed-0ad7f8ab5925">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4dd5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171935.848 559978.797 171935.093 559979.745 171934.142 559978.915 171934.922 559978.004</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5477eea6-5024-04bf-9805-4d4947f968b9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2021-03-03T16:08:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3464be38e5174ad4a49839075dd915d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171933.353 559942.550 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171954.644 559929.088 171954.867 559929.308 171954.145 559929.716 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171915.521 559952.966 171915.488 559952.934 171924.551 559947.739 171933.353 559942.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1d2918f1-fc49-8277-4417-c10b272a6d08">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-08T08:24:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171949.607 559925.311 171947.149 559922.883 171944.657 559920.422 171944.212 559919.982 171944.077 559919.848 171943.057 559918.841 171936.930 559912.787 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bb5be5992-b401-6707-2dbd-32f72c3dd420">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-08T08:39:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-11-08T08:24:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171944.077 559919.848 171943.057 559918.841 171936.930 559912.787 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171949.607 559925.311 171947.149 559922.883 171944.657 559920.422 171944.212 559919.982 171944.203 559919.973 171944.077 559919.848</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b92f5b23e-c18e-9bb6-e385-cfb9109d4413">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-06T15:32:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171949.607 559925.311 171947.149 559922.883 171944.657 559920.422 171944.212 559919.982 171944.077 559919.848 171943.057 559918.841 171942.408 559918.199 171939.927 559915.748 171937.454 559913.305 171936.877 559912.735 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6036db0b-769a-dd10-cee1-0b2331a3974b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2019-07-08T13:11:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:52:10</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2019-06-06T15:32:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171949.607 559925.311 171947.149 559922.883 171944.657 559920.422 171944.212 559919.982 171944.077 559919.848 171943.057 559918.841 171942.408 559918.199 171939.927 559915.748 171937.454 559913.305 171936.877 559912.735 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3781adfd-8d93-8ac0-54a2-c50a5b3dee2b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-21T11:04:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:52:10.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171949.607 559925.311 171947.149 559922.883 171944.657 559920.422 171944.212 559919.982 171944.077 559919.848 171943.057 559918.841 171942.408 559918.199 171939.927 559915.748 171937.454 559913.305 171936.877 559912.735 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba059fb6f-ff9f-29cb-8767-656b70b3cb7e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-21T11:09:33</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-03-10T12:09:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-21T11:04:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171944.077 559919.848 171943.057 559918.841 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbb5aa363-4641-8e50-6148-004cd18ef9e0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2023-03-10T12:16:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2023-03-10T12:09:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.350b9c4c2134454c9d7cb6b1abeef929</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171914.096 559926.257 171913.891 559926.084 171914.871 559925.510 171917.084 559924.194 171917.281 559924.076 171918.095 559923.592 171919.506 559922.736 171920.441 559922.170 171921.870 559921.303 171923.267 559920.456 171923.552 559920.283 171924.273 559919.844 171925.646 559918.997 171927.680 559917.741 171929.540 559916.593 171931.507 559915.344 171934.616 559913.332 171936.024 559912.421 171936.382 559912.190 171936.755 559911.948 171949.504 559924.501 171951.316 559926.285 171950.920 559926.537 171950.878 559926.567 171950.315 559926.011 171944.077 559919.848 171943.057 559918.841 171936.930 559912.787 171936.777 559912.636 171936.569 559912.431 171934.243 559913.930 171930.048 559916.581 171929.990 559916.617 171925.817 559919.215 171925.734 559919.266 171921.574 559921.808 171921.453 559921.881 171917.231 559924.398 171917.207 559924.412 171914.096 559926.257</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcd281cb5-3f4e-23c2-e237-7134026c6a27">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T21:00:09</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.eeb60773571f443680a4f65cd21e7238</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171914.189 559926.080 171916.783 559924.547 171919.254 559923.087 171923.052 559920.778 171927.313 559918.162 171929.863 559916.582 171933.050 559914.573 171935.566 559912.941 171936.861 559912.105</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcb7b9fef-9d8b-a097-3382-ca1666082d27">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T21:00:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.eeb60773571f443680a4f65cd21e7238</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171914.189 559926.080 171916.783 559924.547 171919.254 559923.087 171923.052 559920.778 171927.313 559918.162 171929.863 559916.582 171933.050 559914.573 171935.566 559912.941 171936.861 559912.105</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b50508021-a3ff-f48b-d537-2f949ec65861">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:00:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.24a9b3fb0630410a9627c31385a1935b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171950.174 559915.875 171948.293 559917.115 171944.942 559919.295 171944.164 559919.793 171943.144 559918.785 171944.321 559918.024 171948.512 559915.301 171949.345 559914.751 171950.174 559915.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf1ba6fdc-8df6-5888-f0fa-9834b303fe38">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T12:00:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.24a9b3fb0630410a9627c31385a1935b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171950.174 559915.875 171948.293 559917.115 171944.942 559919.295 171944.164 559919.793 171943.144 559918.785 171944.321 559918.024 171948.512 559915.301 171949.345 559914.751 171950.174 559915.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b09412af2-a900-6905-2b5d-408b5bab63b4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:24</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.24a9b3fb0630410a9627c31385a1935b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171950.174 559915.875 171948.293 559917.115 171944.942 559919.295 171944.164 559919.793 171943.144 559918.785 171944.321 559918.024 171948.512 559915.301 171949.345 559914.751 171950.174 559915.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9ef9112d-4942-2a0f-3e87-03a76e9f6501">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:00:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.89f2dc76f4a9464fb4a32cf2afe5d3bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171986.346 559891.335 171984.484 559892.622 171980.359 559895.452 171976.231 559898.275 171972.113 559901.112 171967.979 559903.926 171965.747 559905.454 171963.269 559907.133 171959.954 559909.372 171955.794 559912.148 171952.466 559914.364 171950.174 559915.875 171949.345 559914.751 171952.684 559912.546 171956.848 559909.784 171961.002 559907.003 171965.143 559904.203 171969.273 559901.384 171973.402 559898.566 171977.524 559895.736 171981.642 559892.901 171985.342 559890.347 171986.346 559891.335</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b2c9e1a69-62ee-a790-3b7a-60f3c81d5a50">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-08T08:24:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-10-31T12:00:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.89f2dc76f4a9464fb4a32cf2afe5d3bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171986.346 559891.335 171984.484 559892.622 171980.359 559895.452 171976.231 559898.275 171972.113 559901.112 171967.979 559903.926 171965.747 559905.454 171963.269 559907.133 171959.954 559909.372 171955.794 559912.148 171952.466 559914.364 171950.174 559915.875 171949.345 559914.751 171952.684 559912.546 171956.848 559909.784 171961.002 559907.003 171965.143 559904.203 171969.273 559901.384 171973.402 559898.566 171977.524 559895.736 171981.642 559892.901 171985.342 559890.347 171986.346 559891.335</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b51838852-f9e8-91f7-e6b8-ebaed6e41167">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-08T08:39:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-11-08T08:24:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.89f2dc76f4a9464fb4a32cf2afe5d3bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171950.174 559915.875 171949.345 559914.751 171952.684 559912.546 171956.848 559909.784 171961.002 559907.003 171965.143 559904.203 171969.273 559901.384 171973.402 559898.566 171977.524 559895.736 171981.642 559892.901 171985.342 559890.347 171986.346 559891.335 171984.484 559892.622 171980.359 559895.452 171976.231 559898.275 171972.113 559901.112 171967.979 559903.926 171966.668 559904.823 171965.747 559905.454 171963.269 559907.133 171959.954 559909.372 171955.794 559912.148 171952.466 559914.364 171950.174 559915.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="badabc721-3902-91a5-aedb-c4d1c3049794">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.89f2dc76f4a9464fb4a32cf2afe5d3bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171986.346 559891.335 171984.484 559892.622 171980.359 559895.452 171976.231 559898.275 171972.113 559901.112 171967.979 559903.926 171965.747 559905.454 171963.269 559907.133 171959.954 559909.372 171955.794 559912.148 171952.466 559914.364 171950.174 559915.875 171949.345 559914.751 171952.684 559912.546 171956.848 559909.784 171961.002 559907.003 171965.143 559904.203 171969.273 559901.384 171973.402 559898.566 171977.524 559895.736 171981.642 559892.901 171985.342 559890.347 171986.346 559891.335</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b270730a9-6f18-1441-1af1-91f22d229584">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:00:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.285b8f17ddb14d26a4f7a0112ec73e6b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171957.064 559922.518 171954.114 559924.479 171950.965 559926.512 171950.401 559925.954 171951.375 559925.311 171951.935 559924.941 171956.125 559922.213 171956.623 559921.881 171957.064 559922.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b242f2b1f-0776-b7e1-2b24-24f63404b5b5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T12:00:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.285b8f17ddb14d26a4f7a0112ec73e6b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171957.064 559922.518 171954.114 559924.479 171950.965 559926.512 171950.401 559925.954 171951.375 559925.311 171951.935 559924.941 171956.125 559922.213 171956.623 559921.881 171957.064 559922.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbc0ae2e8-8905-338b-1f94-67eda6c6b657">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:34</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.285b8f17ddb14d26a4f7a0112ec73e6b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171957.064 559922.518 171954.114 559924.479 171950.965 559926.512 171950.401 559925.954 171951.375 559925.311 171951.935 559924.941 171956.125 559922.213 171956.623 559921.881 171957.064 559922.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b84ad3084-6e73-f328-3018-438ec1e63507">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:25:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5065528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171959.876 559995.536 171960.155 559997.080</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b00a9f32b-fcc0-4ee8-887c-9e2a31c09163">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:25:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5065528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171959.876 559995.536 171960.155 559997.080</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbaf9a7fa-a2b8-d1cd-1e72-4fd53ef1cb82">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2014-07-11T16:40:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b5a666421f454dd8a095b303f8572fb7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171951.370 559996.735 171942.040 559988.799</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b97d01956-0d0a-cb7a-d036-0df6b447d4d6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b8720f1981444e5b8661b8809deb8a2b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171963.662 560006.837 171958.675 560002.703 171958.698 560002.675 171959.575 560001.584 171961.854 559998.748 171960.676 559997.520 171960.122 559996.943 171960.013 559995.646</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9d4482b6-8088-35c9-72ed-5c5c314b8cd5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-09T23:27:03</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b8720f1981444e5b8661b8809deb8a2b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171963.953 560007.131 171958.532 560002.583 171961.812 559998.704 171959.007 559995.955</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b267196e6-5cd0-40c6-9ebc-fdc64b0a3fc0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:27:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b8720f1981444e5b8661b8809deb8a2b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171963.953 560007.131 171958.532 560002.583 171961.812 559998.704 171960.155 559997.080</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4ca79499-2724-7473-9faa-0e1e99b5eaff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-16</creationDate>
            <imgeo:LV-publicatiedatum>2024-09-18T09:51:44</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-09-16T12:41:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.217498c79a283eb0e0630b29a8c05128</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.717 559967.004 171875.890 559942.116</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfdfe853e-14fa-83b2-87c0-b8aec0230c8e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.8c9359b2e9ce44948727fb7abdd693d7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.929 559942.000 171876.342 559941.504 171876.691 559941.086 171906.642 559966.042 171906.255 559966.507 171905.881 559966.956 171905.785 559967.072 171903.608 559965.258 171899.725 559962.023 171899.475 559961.815 171879.510 559945.179 171879.179 559944.903 171877.730 559943.696 171875.833 559942.115 171875.929 559942.000</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcb782083-56b2-1356-9399-0183e08f2c8a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4495528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171877.088 559940.492 171901.329 559960.739</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba67a4a1f-c2f0-1160-9a85-5fe9bb106809">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4495528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171877.088 559940.492 171901.329 559960.739</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b744d24fc-4eb0-28ee-1e9d-dc5ab7666b28">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ed7cba60131a4f4197861d20438b4029</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171888.738 559940.049 171888.733 559940.045 171891.117 559938.770 171896.425 559935.921 171897.007 559935.603 171898.894 559934.572 171903.372 559932.113 171904.966 559931.238 171905.185 559931.423 171904.320 559931.919 171904.208 559931.983 171899.935 559934.363 171899.859 559934.405 171895.561 559936.763 171895.472 559936.811 171891.141 559939.131 171891.084 559939.161 171886.739 559941.453 171882.233 559943.782 171879.510 559945.179 171879.179 559944.903 171882.050 559943.426 171886.447 559941.210 171888.738 559940.049</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfcddf2cb-fb21-ee36-f0b1-e65ad655308f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:31:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5695528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.145 559958.721 171879.684 559937.365</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b68e801c4-8e73-195d-a8f3-dda237d7876f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:31:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5695528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.145 559958.721 171879.684 559937.365</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6938a717-50d4-fc19-9048-3380c2a46f4b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:23:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5525528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.552 559957.976 171902.792 559954.839 171880.715 559936.446</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9ef25b93-6813-ca8f-9398-7f603540cbcf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:23:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5525528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171906.552 559957.976 171902.792 559954.839 171880.715 559936.446</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b98f12a4b-5844-74b8-9c40-012ae962527e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:35:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5685528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171880.569 559936.299 171886.456 559941.205 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfe1bf0e2-4694-874e-d50e-ee9201dbb432">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:35:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5685528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171880.569 559936.299 171886.456 559941.205 171906.403 559958.055</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4f363b0f-55c1-c4ee-e6ec-8e49eb34fde1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.276602fd1cbd42b0b961f06843a96575</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171880.532 559936.476 171880.628 559936.361 171882.698 559938.086 171886.447 559941.210 171886.739 559941.453 171906.588 559957.992 171906.837 559958.199 171908.811 559959.844 171910.579 559961.317 171910.483 559961.433 171909.683 559962.393 171879.732 559937.437 171880.186 559936.892 171880.532 559936.476</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba6063282-c565-5215-7097-641dce045ccf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-09-16</creationDate>
            <imgeo:LV-publicatiedatum>2024-09-18T09:51:44</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-09-16T12:45:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.217498c79a0a3eb0e0630b29a8c05128</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171880.671 559936.415 171910.506 559961.286</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b994a9b46-bb91-17fe-62d3-b58e8ed71de6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:58:33</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c85919ccbd5649949a6f99b6d318509c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171886.690 559941.348 171889.169 559940.030 171892.494 559938.247 171896.015 559936.350 171903.669 559932.168 171904.979 559931.410</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b2f1c9130-ef70-0877-1ad2-1e5ad20d41b4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:58:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c85919ccbd5649949a6f99b6d318509c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171886.690 559941.348 171889.169 559940.030 171892.494 559938.247 171896.015 559936.350 171903.669 559932.168 171904.979 559931.410</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfb8277cb-a6ad-ab84-5389-6d29c9299907">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T21:00:07</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ed7cba60131a4f4197861d20438b4029</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171886.727 559941.459 171886.456 559941.205 171888.738 559940.049 171888.733 559940.045 171891.117 559938.770 171896.425 559935.921 171897.007 559935.603 171898.894 559934.572 171903.372 559932.113 171904.966 559931.238 171905.185 559931.423 171904.320 559931.919 171904.208 559931.983 171899.935 559934.363 171899.859 559934.405 171895.561 559936.763 171895.472 559936.811 171891.141 559939.131 171891.084 559939.161 171886.727 559941.459</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b28884a3b-f21d-0aa4-c061-259aa93a667c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T21:00:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ed7cba60131a4f4197861d20438b4029</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171886.727 559941.459 171886.456 559941.205 171888.738 559940.049 171888.733 559940.045 171891.117 559938.770 171896.425 559935.921 171897.007 559935.603 171898.894 559934.572 171903.372 559932.113 171904.966 559931.238 171905.185 559931.423 171904.320 559931.919 171904.208 559931.983 171899.935 559934.363 171899.859 559934.405 171895.561 559936.763 171895.472 559936.811 171891.141 559939.131 171891.084 559939.161 171886.727 559941.459</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7fde127a-9dd8-4fda-ac0c-b7f9dc825da4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:56:05</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:09:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.9275545cd24e44b4987d34b428ee3e74</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171843.523 559983.252 171843.255 559982.582 171843.740 559982.375 171845.585 559981.602 171847.421 559980.809 171849.261 559980.025 171851.102 559979.244 171852.943 559978.463 171854.780 559977.670 171856.624 559976.897 171858.450 559976.081 171860.287 559975.289 171862.099 559974.439 171863.924 559973.620 171865.739 559972.778 171867.554 559971.936 171869.374 559971.105 171871.179 559970.237 171872.991 559969.387 171874.795 559968.518 171876.590 559967.673 171878.388 559966.794 171880.183 559965.913 171881.988 559965.050 171883.785 559964.171 171885.581 559963.290 171887.357 559962.371 171889.148 559961.479 171890.922 559960.556 171892.701 559959.641 171894.479 559958.727 171896.237 559957.771 171898.010 559956.845 171899.771 559955.897 171901.542 559954.970 171903.286 559953.990 171905.045 559953.038 171906.811 559952.097 171908.558 559951.124 171910.316 559950.169 171912.061 559949.191 171913.802 559948.207 171915.549 559947.234 171917.282 559946.235 171919.015 559945.237 171920.740 559944.224 171922.475 559943.229 171924.202 559942.220 171925.924 559941.203 171927.630 559940.157 171929.350 559939.129 171931.078 559938.118 171932.793 559937.089 171934.483 559936.018 171936.201 559934.993 171937.884 559933.911 171939.593 559932.872 171941.280 559931.798 171942.970 559930.727 171944.666 559929.666 171946.339 559928.571 171948.015 559927.480 171949.707 559926.413 171950.315 559926.011 171950.878 559926.567 171947.390 559928.818 171942.372 559932.051 171937.443 559935.113 171937.290 559935.208 171935.236 559936.484 171930.511 559939.418 171929.952 559939.746 171929.138 559940.223 171925.304 559942.473 171924.924 559942.696 171920.214 559945.459 171916.755 559947.434 171914.242 559948.868 171913.286 559949.414 171906.341 559953.304 171902.975 559955.051 171899.278 559956.970 171898.259 559957.500 171890.432 559961.566 171883.306 559965.124 171876.176 559968.691 171875.840 559968.850 171874.085 559969.682 171867.178 559972.955 171865.780 559973.585 171860.564 559975.936 171859.583 559976.378 171857.784 559977.188 171850.270 559980.400 171848.377 559981.200 171843.523 559983.252</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4c93da56-bcf2-fa9f-dffe-e55a0cb14b7e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-24</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5466b90d5ec440829b57902e7e068274</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171860.564 559975.936 171859.583 559976.378 171857.784 559977.188 171850.270 559980.400 171848.377 559981.200 171843.523 559983.252 171843.255 559982.582 171843.740 559982.375 171845.585 559981.602 171847.421 559980.809 171849.261 559980.025 171851.102 559979.244 171852.943 559978.463 171854.780 559977.670 171856.624 559976.897 171858.450 559976.081 171860.287 559975.289 171862.099 559974.439 171863.924 559973.620 171865.739 559972.778 171867.554 559971.936 171869.374 559971.105 171871.179 559970.237 171872.991 559969.387 171874.795 559968.518 171876.590 559967.673 171878.388 559966.794 171880.183 559965.913 171881.988 559965.050 171883.785 559964.171 171885.581 559963.290 171886.642 559962.741 171887.357 559962.371 171889.148 559961.479 171890.922 559960.556 171892.701 559959.641 171894.479 559958.727 171896.237 559957.771 171898.010 559956.845 171899.771 559955.897 171901.542 559954.970 171903.286 559953.990 171905.045 559953.038 171906.811 559952.097 171908.558 559951.124 171910.316 559950.169 171912.061 559949.191 171913.802 559948.207 171915.549 559947.234 171917.282 559946.235 171919.015 559945.237 171920.740 559944.224 171922.475 559943.229 171924.202 559942.220 171925.924 559941.203 171927.630 559940.157 171929.350 559939.129 171931.078 559938.118 171932.793 559937.089 171934.483 559936.018 171936.201 559934.993 171937.884 559933.911 171939.593 559932.872 171941.280 559931.798 171942.970 559930.727 171944.666 559929.666 171946.339 559928.571 171948.015 559927.480 171949.707 559926.413 171950.315 559926.011 171950.878 559926.567 171947.390 559928.818 171942.372 559932.051 171937.443 559935.113 171937.290 559935.208 171935.236 559936.484 171930.511 559939.418 171929.952 559939.746 171929.138 559940.223 171925.304 559942.473 171924.924 559942.696 171920.214 559945.459 171916.755 559947.434 171914.242 559948.868 171913.286 559949.414 171906.341 559953.304 171902.975 559955.051 171899.278 559956.970 171898.259 559957.500 171890.432 559961.566 171883.306 559965.124 171876.176 559968.691 171875.840 559968.850 171874.085 559969.682 171867.178 559972.955 171865.780 559973.585 171860.564 559975.936</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9bd755da-11ae-041a-b643-938b1fc6e23c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:56:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.9275545cd24e44b4987d34b428ee3e74</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171843.523 559983.252 171843.255 559982.582 171843.740 559982.375 171845.585 559981.602 171847.421 559980.809 171849.261 559980.025 171851.102 559979.244 171852.943 559978.463 171854.780 559977.670 171856.624 559976.897 171858.450 559976.081 171860.287 559975.289 171862.099 559974.439 171863.924 559973.620 171865.739 559972.778 171867.554 559971.936 171869.374 559971.105 171871.179 559970.237 171872.991 559969.387 171874.795 559968.518 171876.590 559967.673 171878.388 559966.794 171880.183 559965.913 171881.988 559965.050 171883.785 559964.171 171885.581 559963.290 171887.357 559962.371 171889.148 559961.479 171890.922 559960.556 171892.701 559959.641 171894.479 559958.727 171896.237 559957.771 171898.010 559956.845 171899.771 559955.897 171901.542 559954.970 171903.286 559953.990 171905.045 559953.038 171906.811 559952.097 171908.558 559951.124 171910.316 559950.169 171912.061 559949.191 171913.802 559948.207 171915.549 559947.234 171917.282 559946.235 171919.015 559945.237 171920.740 559944.224 171922.475 559943.229 171924.202 559942.220 171925.924 559941.203 171927.630 559940.157 171929.350 559939.129 171931.078 559938.118 171932.793 559937.089 171934.483 559936.018 171936.201 559934.993 171937.884 559933.911 171939.593 559932.872 171941.280 559931.798 171942.970 559930.727 171944.666 559929.666 171946.339 559928.571 171948.015 559927.480 171949.707 559926.413 171950.315 559926.011 171950.878 559926.567 171947.390 559928.818 171942.372 559932.051 171937.443 559935.113 171937.290 559935.208 171935.236 559936.484 171930.511 559939.418 171929.952 559939.746 171929.138 559940.223 171925.304 559942.473 171924.924 559942.696 171920.214 559945.459 171916.755 559947.434 171914.242 559948.868 171913.286 559949.414 171906.341 559953.304 171902.975 559955.051 171899.278 559956.970 171898.259 559957.500 171890.432 559961.566 171883.306 559965.124 171876.176 559968.691 171875.840 559968.850 171874.085 559969.682 171867.178 559972.955 171865.780 559973.585 171860.564 559975.936 171859.583 559976.378 171857.784 559977.188 171850.270 559980.400 171848.377 559981.200 171843.523 559983.252</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5c9fcfd9-9268-85d2-c3b7-d0d56c869631">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:56:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.9275545cd24e44b4987d34b428ee3e74</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171843.523 559983.252 171843.255 559982.582 171843.740 559982.375 171845.585 559981.602 171847.421 559980.809 171849.261 559980.025 171851.102 559979.244 171852.943 559978.463 171854.780 559977.670 171856.624 559976.897 171858.450 559976.081 171860.287 559975.289 171862.099 559974.439 171863.924 559973.620 171865.739 559972.778 171867.554 559971.936 171869.374 559971.105 171871.179 559970.237 171872.991 559969.387 171874.795 559968.518 171876.590 559967.673 171878.388 559966.794 171880.183 559965.913 171881.988 559965.050 171883.785 559964.171 171885.581 559963.290 171887.357 559962.371 171889.148 559961.479 171890.922 559960.556 171892.701 559959.641 171894.479 559958.727 171896.237 559957.771 171898.010 559956.845 171899.771 559955.897 171901.542 559954.970 171903.286 559953.990 171905.045 559953.038 171906.811 559952.097 171908.558 559951.124 171910.316 559950.169 171912.061 559949.191 171913.802 559948.207 171915.549 559947.234 171917.282 559946.235 171919.015 559945.237 171920.740 559944.224 171922.475 559943.229 171924.202 559942.220 171925.924 559941.203 171927.630 559940.157 171929.350 559939.129 171931.078 559938.118 171932.793 559937.089 171934.483 559936.018 171936.201 559934.993 171937.884 559933.911 171939.593 559932.872 171941.280 559931.798 171942.970 559930.727 171944.666 559929.666 171946.339 559928.571 171948.015 559927.480 171949.707 559926.413 171950.315 559926.011 171950.878 559926.567 171947.390 559928.818 171942.372 559932.051 171937.443 559935.113 171937.290 559935.208 171935.236 559936.484 171930.511 559939.418 171929.952 559939.746 171929.138 559940.223 171925.304 559942.473 171924.924 559942.696 171920.214 559945.459 171916.755 559947.434 171914.242 559948.868 171913.286 559949.414 171906.341 559953.304 171902.975 559955.051 171899.278 559956.970 171898.259 559957.500 171890.432 559961.566 171883.306 559965.124 171876.176 559968.691 171875.840 559968.850 171874.085 559969.682 171867.178 559972.955 171865.780 559973.585 171860.564 559975.936 171859.583 559976.378 171857.784 559977.188 171850.270 559980.400 171848.377 559981.200 171843.523 559983.252</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8fddfe0e-d4d6-0808-9ba4-c02fc44307ed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-11T16:27:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9e13ef1ffc07418ca3e82c4ba42d17f6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171896.463 559963.365 171899.318 559961.802</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bebbeeb60-22b4-ab96-05f3-248ab5a301f8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-11T16:27:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9e13ef1ffc07418ca3e82c4ba42d17f6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171896.463 559963.365 171899.318 559961.802</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b453ef93f-3d85-bbbd-0f9c-571cbac035fc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2f26081c5c3c47ae83a26598fb9048b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171901.329 559960.739</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7a20d952-af00-fc4c-04e4-f9e694b672ff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2f26081c5c3c47ae83a26598fb9048b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171901.329 559960.739</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b505ff06b-5c70-b09b-96f7-754755be4080">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:25:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf40a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.384 559961.767 171905.713 559967.074</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3093ffcf-97db-3142-64c7-1a6125cac9fa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:25:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf40a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.384 559961.767 171905.713 559967.074</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bb801fe6c-190b-ee5b-01ca-45f500b0669a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.54b5e290b11e4b879cdaaa5ec429f399</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171905.736 559967.132 171907.058 559965.539</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5a81c777-63a4-d25b-e237-e5828e815483">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.54b5e290b11e4b879cdaaa5ec429f399</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171905.736 559967.132 171907.058 559965.539</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7113435f-12d8-1739-ccdf-c778705e462a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4d89c6efb8fb4ec0a64470c2db21b6a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171901.329 559960.739 171905.144 559958.720</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1f1eb0a3-3f59-665a-58a6-b639d9134202">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:36:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.4d89c6efb8fb4ec0a64470c2db21b6a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171901.329 559960.739 171905.144 559958.720</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcb43d46d-7096-244b-4341-e3c477affbf3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:07</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.4cfcb3cb17c64046b3b6fb834126d29b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171944.077 559919.848 171942.417 559920.910 171939.025 559923.029 171935.573 559925.051 171932.129 559927.079 171928.682 559929.108 171924.379 559931.654 171920.936 559933.694 171917.488 559935.723 171912.300 559938.725 171908.825 559940.705 171905.333 559942.656 171900.955 559945.063 171897.433 559946.959 171892.138 559949.776 171886.812 559952.542 171881.472 559955.262 171876.991 559957.482 171872.790 559959.525 171868.578 559961.533 171864.348 559963.518 171860.951 559965.076 171856.700 559967.015 171856.477 559966.464 171856.883 559966.286 171861.439 559964.226 171865.978 559962.129 171870.495 559959.986 171874.998 559957.813 171879.487 559955.612 171883.960 559953.379 171888.408 559951.093 171892.839 559948.775 171897.259 559946.439 171901.659 559944.063 171906.037 559941.647 171910.393 559939.191 171914.726 559936.695 171919.047 559934.177 171923.350 559931.630 171927.613 559929.018 171931.786 559926.259 171935.949 559923.490 171940.124 559920.737 171943.057 559918.841 171944.077 559919.848</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfab05d34-1387-5e8e-8d02-5cab87e64276">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.4cfcb3cb17c64046b3b6fb834126d29b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171944.077 559919.848 171942.417 559920.910 171939.025 559923.029 171935.573 559925.051 171932.129 559927.079 171928.682 559929.108 171924.379 559931.654 171920.936 559933.694 171917.488 559935.723 171912.300 559938.725 171908.825 559940.705 171905.333 559942.656 171900.955 559945.063 171897.433 559946.959 171892.138 559949.776 171886.812 559952.542 171881.472 559955.262 171876.991 559957.482 171872.790 559959.525 171868.578 559961.533 171864.348 559963.518 171860.951 559965.076 171856.700 559967.015 171856.477 559966.464 171856.883 559966.286 171861.439 559964.226 171865.978 559962.129 171870.495 559959.986 171874.998 559957.813 171879.487 559955.612 171883.960 559953.379 171888.408 559951.093 171892.839 559948.775 171897.259 559946.439 171901.659 559944.063 171906.037 559941.647 171910.393 559939.191 171914.726 559936.695 171919.047 559934.177 171923.350 559931.630 171927.613 559929.018 171931.786 559926.259 171935.949 559923.490 171940.124 559920.737 171943.057 559918.841 171944.077 559919.848</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b97681427-a9d0-4803-ff57-801234fd2e82">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-04-04</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-04-04T10:31:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.db819a5858c65a3fe0530b29a8c0ec8b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171890.561 559930.814 171893.060 559933.027 171896.199 559935.852</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bc8aeb260-c495-71f8-6b6e-1efd171fe262">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:21:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf49d5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171890.569 559930.921 171896.420 559936.044</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4b54841e-8e98-f4f3-f93e-b4db5cb538fe">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf49a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171874.381 559939.007 171877.066 559940.718</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd377a199-129c-b7d0-23f9-96b981bb7d16">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:29:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf49a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171874.381 559939.007 171877.066 559940.718</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b139cb46e-5ec9-a853-26e9-c488a932926e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:57:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b770217f2b0448d697d42e40f1a8668f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171867.482 559951.063 171867.359 559950.802 171867.556 559950.706 171867.568 559950.700 171868.690 559950.145 171872.359 559948.412 171872.399 559948.393 171873.707 559947.715 171876.241 559946.401 171876.290 559946.376 171876.271 559946.346 171876.300 559946.371 171879.049 559944.970 171879.185 559944.900 171879.515 559945.176 171877.866 559946.022 171877.742 559946.085 171873.351 559948.260 171873.301 559948.285 171868.886 559950.442 171868.786 559950.491 171867.500 559951.102 171867.482 559951.063</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5c33b71f-2c46-80e8-a5f6-088c0bc6e75a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b770217f2b0448d697d42e40f1a8668f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171867.482 559951.063 171867.359 559950.802 171867.556 559950.706 171867.568 559950.700 171868.690 559950.145 171872.359 559948.412 171872.399 559948.393 171873.707 559947.715 171876.241 559946.401 171876.290 559946.376 171876.271 559946.346 171876.300 559946.371 171879.049 559944.970 171879.185 559944.900 171879.515 559945.176 171877.866 559946.022 171877.742 559946.085 171873.351 559948.260 171873.301 559948.285 171868.886 559950.442 171868.786 559950.491 171867.500 559951.102 171867.482 559951.063</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0d09fed3-d0ec-8096-a36c-03513cc89198">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b770217f2b0448d697d42e40f1a8668f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.866 559946.022 171877.742 559946.085 171873.351 559948.260 171873.301 559948.285 171868.886 559950.442 171868.786 559950.491 171867.500 559951.102 171867.482 559951.063 171867.359 559950.802 171867.556 559950.706 171867.568 559950.700 171868.690 559950.145 171872.359 559948.412 171872.399 559948.393 171873.707 559947.715 171876.241 559946.401 171876.290 559946.376 171876.271 559946.346 171876.300 559946.371 171879.049 559944.970 171879.179 559944.903 171879.510 559945.179 171877.866 559946.022</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf246c527-0d86-43d1-e83f-469f52c618a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.86f3d2f20d214d81962e50f91c9dd878</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171867.533 559951.038 171868.903 559950.368 171871.353 559949.179 171872.430 559948.650 171874.131 559947.820 171878.238 559945.764 171879.411 559945.173</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0b96cacd-3b3e-56d8-d8e4-c1995aee0459">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.86f3d2f20d214d81962e50f91c9dd878</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171867.533 559951.038 171868.903 559950.368 171871.353 559949.179 171872.430 559948.650 171874.131 559947.820 171878.238 559945.764 171879.411 559945.173</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b315f2158-84f0-0663-d640-8f648087f047">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2bb93ad14411474ba31c2d3b32bf6c7a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171876.140 559941.405 171875.595 559942.103 171879.049 559944.970</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5b626b37-d7e0-229a-8e86-cf7999df5e95">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2bb93ad14411474ba31c2d3b32bf6c7a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171876.140 559941.405 171875.595 559942.103 171879.049 559944.970</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bde960240-f9b1-5f80-2cfc-20e470322e68">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:30:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf44a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171877.088 559940.492 171875.784 559942.062</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3540c00f-a828-a2f1-5011-53a059bf3f52">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:30:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf44a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171877.088 559940.492 171875.784 559942.062</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b54c2f494-9562-f1c7-6312-236779ea090b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.bdbcb468c0d94f638e48a04f43dcb7b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171875.814 559939.442 171877.088 559940.492</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b50661f05-1bec-57eb-76cf-fd43c2a1da97">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.bdbcb468c0d94f638e48a04f43dcb7b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171875.814 559939.442 171877.088 559940.492</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbe8be3ef-f9a0-f800-02e1-f8b2815e21cb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf56a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171879.684 559937.365 171880.569 559936.299</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0e68ebef-d46b-d974-8e6f-c91a4c2d25a6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf56a5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171879.684 559937.365 171880.569 559936.299</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b000a5f22-fe18-2695-567a-b2042110f614">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5f85528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b5822423a-6281-98ee-08a4-de6f68aaaaac">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:33:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf5f85528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171899.318 559961.802 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7de9691f-6974-f262-cc77-d0fd4df2ef1e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:22:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf47b5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171875.893 559942.188 171884.712 559949.465 171899.384 559961.767</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf723b5a5-af0d-e80a-aabd-3c6367d695d0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:22:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf47b5528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171875.893 559942.188 171884.712 559949.465 171899.384 559961.767</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bb969cc64-c588-6999-b901-7c515736513e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-08-27T15:06:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f8a51e072d0a4a1f9e2d35ff94454517</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.674 559972.731 171877.696 559973.052 171877.324 559973.224 171872.384 559975.515 171871.139 559976.087 171869.154 559976.992 171865.221 559978.781 171858.728 559981.717 171858.605 559981.443 171862.015 559979.913 171865.400 559978.369 171870.631 559975.991 171872.247 559975.251 171877.674 559972.731</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b35b53ec2-e9ed-60bd-485a-0877dad50fa8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-08-12T13:25:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.c8ddab883646418a95f4f8db2ab6712c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171876.300 559946.371 171872.796 559943.289 171866.513 559937.791</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b63a88062-a70c-fd89-3a9a-84585423e74f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:28:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a45528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171866.513 559937.791 171860.538 559933.730 171858.305 559932.249 171849.091 559928.619 171833.706 559932.271</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf486f234-6fff-da65-c067-a8e048b4eb2f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-01-30T11:50:21</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b2551b8b7e9941ada57c9e49cff8c9f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171846.470 559960.793 171846.364 559960.532 171848.054 559959.752 171852.538 559957.689 171853.530 559957.229 171855.469 559956.331 171856.988 559955.636 171860.404 559954.072 171861.588 559953.528 171861.857 559953.412 171861.988 559953.687 171861.995 559953.702 171859.817 559954.722 171859.778 559954.740 171855.325 559956.814 171855.202 559956.870 171850.718 559958.886 171850.692 559958.898 171846.470 559960.793</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf45e1893-df8f-8a51-7fad-ae2170223716">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-07T12:36:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:57:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2019-01-30T11:50:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b2551b8b7e9941ada57c9e49cff8c9f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171846.470 559960.793 171846.364 559960.532 171848.054 559959.752 171852.538 559957.689 171853.530 559957.229 171855.469 559956.331 171856.988 559955.636 171860.390 559954.079 171860.404 559954.072 171861.588 559953.528 171861.857 559953.412 171861.988 559953.687 171861.995 559953.702 171859.817 559954.722 171859.778 559954.740 171855.325 559956.814 171855.202 559956.870 171850.718 559958.886 171850.692 559958.898 171846.470 559960.793</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b797c730b-dadb-30c4-9a69-bf39a10aa4c8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b2551b8b7e9941ada57c9e49cff8c9f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171846.470 559960.793 171846.364 559960.532 171848.054 559959.752 171852.538 559957.689 171853.530 559957.229 171855.469 559956.331 171856.988 559955.636 171860.390 559954.079 171860.404 559954.072 171861.588 559953.528 171861.857 559953.412 171861.988 559953.687 171861.995 559953.702 171859.817 559954.722 171859.778 559954.740 171855.325 559956.814 171855.202 559956.870 171850.718 559958.886 171850.692 559958.898 171846.470 559960.793</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b23a0d941-1f0c-de08-8436-502f28c5b832">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-25</terminationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:39.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b2551b8b7e9941ada57c9e49cff8c9f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171846.470 559960.793 171846.364 559960.532 171848.054 559959.752 171852.538 559957.689 171853.530 559957.229 171855.469 559956.331 171856.988 559955.636 171860.390 559954.079 171860.404 559954.072 171861.588 559953.528 171861.857 559953.412 171861.988 559953.687 171861.995 559953.702 171859.817 559954.722 171859.778 559954.740 171855.325 559956.814 171855.202 559956.870 171850.718 559958.886 171850.692 559958.898 171846.470 559960.793</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b54c21fd2-730d-dd1c-e386-3b4bc4ddd108">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-13</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e67e08e5e7c14be597b0a8b6c2945795</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171850.718 559958.886 171850.692 559958.898 171846.470 559960.793 171846.461 559960.771 171846.364 559960.532 171848.054 559959.752 171852.538 559957.689 171853.530 559957.229 171855.469 559956.331 171856.988 559955.636 171860.390 559954.079 171860.404 559954.072 171861.588 559953.528 171861.857 559953.412 171861.988 559953.687 171861.995 559953.702 171859.817 559954.722 171859.778 559954.740 171855.325 559956.814 171855.202 559956.870 171850.718 559958.886</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9d16d4cc-4506-e7cb-2381-40d9f9b764d6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5f30820f52f84b79bfe7e14093d5b55f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171861.959 559953.701 171860.975 559954.158 171860.379 559954.434 171858.905 559955.120 171857.591 559955.726 171855.990 559956.462 171855.111 559956.871 171854.170 559957.301 171852.160 559958.210 171850.413 559958.999 171849.149 559959.570 171848.053 559960.065 171847.820 559960.171 171846.461 559960.771</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bac3965b6-1a57-16b1-379b-732ea3cb64e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5f30820f52f84b79bfe7e14093d5b55f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171861.959 559953.701 171860.975 559954.158 171860.379 559954.434 171858.905 559955.120 171857.591 559955.726 171855.990 559956.462 171855.111 559956.871 171854.170 559957.301 171852.160 559958.210 171850.413 559958.999 171849.149 559959.570 171848.053 559960.065 171847.820 559960.171 171846.487 559960.760</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bdff52934-358b-c061-b8d5-aac48064f90f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5f30820f52f84b79bfe7e14093d5b55f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171861.959 559953.701 171860.975 559954.158 171860.379 559954.434 171858.905 559955.120 171857.591 559955.726 171855.990 559956.462 171855.111 559956.871 171854.170 559957.301 171852.160 559958.210 171850.413 559958.999 171849.149 559959.570 171848.053 559960.065 171847.820 559960.171 171846.487 559960.760</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9e732912-b332-b77b-b99d-f00487439478">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e9d050392d454015a27d6cd304bc8508</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171844.838 559982.292 171843.461 559982.825</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbeebe6e5-3e47-d2b6-c4dc-193e35b2262c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e9d050392d454015a27d6cd304bc8508</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171844.838 559982.292 171843.461 559982.825</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b40c5a002-ebd1-3297-4685-c7312ef2f769">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:20:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf4a55528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171755.722 559811.927 171757.559 559814.321 171773.786 559826.675 171785.405 559836.692 171793.285 559843.039 171814.611 559862.048 171832.580 559876.810 171845.709 559888.326 171849.816 559892.050</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b40671c04-1772-b0b2-b735-50017e79ad35">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d8fabab99b255802c1b5002882</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172008.350 559717.069 172000.000 559709.187 171996.643 559706.018 171985.334 559695.515 171984.655 559694.914 171983.210 559693.634 171982.615 559693.106 171981.521 559692.080 171911.778 559626.291 171871.206 559587.950 171865.400 559582.464 171856.449 559574.005 171855.182 559572.859 171853.959 559571.666 171852.780 559570.430 171851.337 559568.780 171849.974 559567.064 171848.693 559565.285 171838.149 559548.526 171835.950 559544.809 171828.938 559526.549 171819.300 559500.000 171818.039 559496.528 171816.603 559492.976 171814.330 559486.250 171812.620 559481.510 171810.630 559476.130 171809.900 559474.540 171808.529 559470.881 171806.986 559466.675 171806.704 559465.907 171804.506 559460.567 171801.805 559454.892 171799.293 559450.495 171797.995 559448.307 171795.330 559443.820 171784.089 559426.611 171772.557 559410.207 171775.921 559410.038</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b648f0304-d055-485a-7970-84833963a725">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-17</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-17T11:20:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.32b59f2d1c604a63ad6253c6df048369</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171906.962 559965.658 171907.122 559965.466 171908.275 559966.426 171908.115 559966.618 171906.962 559965.658</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbf8943ab-2278-eead-c5af-9ccc6dd2d33d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-19T15:41:05</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.40144c96d339409a8e4b793739a646c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.075 559940.625 171877.011 559940.702 171875.897 559939.774 171876.057 559939.582 171877.171 559940.510 171907.122 559965.466 171908.275 559966.426 171908.115 559966.618 171906.962 559965.658 171907.026 559965.581 171877.075 559940.625</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b50fcc2ae-0dc3-ad33-f3d7-691d15e72225">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-19T15:41:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.40144c96d339409a8e4b793739a646c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.075 559940.625 171877.171 559940.510 171907.122 559965.466 171907.026 559965.581 171877.075 559940.625</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd44a95bb-8f8b-a8da-5faf-41d61793253c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-17</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-17T11:20:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.6d58449e2ec0419bbc07586a2387f03b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.171 559940.510 171877.011 559940.702 171875.897 559939.774 171876.057 559939.582 171877.171 559940.510</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bc10bc26d-1c04-5f20-6441-0b59d8fd3d76">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af968a5791141a255802d088014395</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173848.688 559788.946 173847.242 559791.788 173838.510 559807.010</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b719a9b94-ae9a-3fc6-4d7b-eee0de7b0e47">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:47:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af9682c0c28023255802c0e6002160</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173664.402 558654.030 173665.350 558654.136 173668.828 558654.773 173671.889 558654.969 173678.016 558654.969 173680.651 558654.819 173684.598 558654.315 173688.250 558653.559 173691.805 558652.649 173695.388 558651.613 173698.845 558650.717 173702.400 558649.862 173708.634 558648.679 173713.606 558648.287 173718.676 558648.115 173724.653 558648.385 173728.816 558648.409 173734.548 558647.919 173738.662 558647.380 173744.222 558646.351 173750.051 558644.881 173752.746 558644.146</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf6615abe-2727-cd9e-a819-049c76d089d8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d7d8e54c37255802cff0013699</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173345.528 558751.367 173331.319 558751.641 173320.372 558751.864 173309.380 558757.465</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="ba647d32a-d18e-d330-830a-a5e6e6a315a8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d7dd63cb20255802cffb01372a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173420.653 558733.112 173417.874 558734.016 173412.469 558735.940 173409.426 558737.023 173406.565 558738.210 173402.555 558739.669 173400.417 558740.586 173398.186 558741.352 173397.577 558741.561 173395.662 558742.365 173395.352 558742.505</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0f1d84a6-2f58-5c8e-a58b-6e945841f3f5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d7cb56c7e6255802cfe6013561</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173266.230 558766.909 173258.238 558766.397 173257.107 558767.901 173256.446 558768.711 173255.879 558769.198 173257.629 558775.650 173246.308 558778.371 173244.762 558771.816 173244.031 558772.204 173243.969 558772.088 173240.061 558774.070 173239.882 558773.820 173239.025 558774.155</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b04f48496-0059-394f-5ffe-99d7891e283d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d79f8395b9255802cfdb013408</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173187.237 558788.906 173182.667 558789.400 173181.822 558789.478 173183.537 558796.105 173172.378 558798.993 173170.587 558791.360 173169.768 558791.771 173162.016 558795.887 173159.261 558797.317 173159.350 558797.556 173159.261 558797.606</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7a7b2757-c530-2544-6864-c6159cce6d15">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93d7b043947d255802cfd001338e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173116.940 558811.506 173116.758 558811.537 173107.448 558815.653 173098.204 558818.225 173097.466 558818.580 173087.594 558821.365 173079.971 558819.112</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bef9fead6-30ff-2d4f-0b50-5b432a09ccdd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-15</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-16T11:48:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a164c79327ed4f808547e58efbf81994</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173248.736 559557.403 173248.971 559557.792 173248.615 559558.035 173248.397 559557.669 173247.781 559556.715 173247.131 559555.783 173246.450 559554.875 173245.736 559553.991 173245.136 559553.293 173244.368 559552.456 173243.570 559551.647 173242.745 559550.867 173241.893 559550.116 173241.015 559549.395 173240.113 559548.706 173239.186 559548.049 173238.237 559547.426 173237.267 559546.835 173236.324 559546.306 173235.417 559545.839 173234.491 559545.407 173233.550 559545.012 173232.593 559544.654 173231.624 559544.334 173230.642 559544.052 173229.651 559543.808 173228.650 559543.604 173228.134 559543.515 173226.986 559543.348 173225.833 559543.220 173224.676 559543.133 173223.517 559543.085 173222.357 559543.078 173221.198 559543.110 173220.715 559543.135 173196.805 559545.252 173176.800 559547.012 173152.893 559549.124 173132.971 559550.878 173109.085 559552.969 173089.165 559554.732 173077.206 559555.814 173075.629 559555.961 173074.055 559556.147 173072.487 559556.373 173070.925 559556.639 173069.429 559556.931 173067.882 559557.274 173066.344 559557.655 173064.816 559558.075 173063.300 559558.534 173061.796 559559.031 173060.304 559559.565 173058.827 559560.137 173058.088 559560.440 173056.828 559560.986 173055.584 559561.569 173054.358 559562.189 173053.151 559562.843 173051.963 559563.532 173050.795 559564.256 173049.650 559565.013 173048.526 559565.804 173047.764 559566.369 173046.548 559567.314 173045.356 559568.291 173044.191 559569.299 173043.051 559570.336 173041.940 559571.403 173040.856 559572.498 173039.801 559573.621 173039.057 559574.449 173038.137 559575.524 173037.247 559576.624 173036.389 559577.749 173035.563 559578.898 173034.769 559580.069 173034.009 559581.263 173033.283 559582.477 173032.592 559583.712 173032.292 559584.274 173031.598 559585.788 173030.870 559587.153 173030.214 559588.619 173029.594 559590.100 173029.011 559591.596 173028.465 559593.106 173027.958 559594.630 173027.751 559595.288 173027.374 559596.583 173027.035 559597.888 173026.735 559599.203 173026.474 559600.526 173026.252 559601.857 173026.082 559603.100 173025.886 559604.850 173025.731 559606.605 173025.615 559608.362 173025.539 559610.121 173025.517 559610.947 173025.901 559618.793 173026.205 559623.090 173026.228 559623.528 173026.212 559623.951 173026.211 559623.966 173026.154 559624.400 173026.058 559624.828 173025.923 559625.245 173025.751 559625.648 173025.543 559626.033 173025.301 559626.398 173025.250 559626.466 173024.969 559626.802 173024.659 559627.112 173024.322 559627.392 173023.961 559627.640 173023.579 559627.854 173023.178 559628.032 173022.764 559628.174 173022.338 559628.276 173021.904 559628.340 173021.462 559628.372 173021.436 559628.005 173021.467 559628.001 173022.105 559627.881 173022.514 559627.796 173022.633 559627.759 173022.914 559627.673 173023.300 559627.512 173023.576 559627.364 173024.017 559627.083 173024.341 559626.820 173024.639 559626.526 173024.908 559626.206 173025.108 559625.919 173025.316 559625.557 173025.357 559625.466 173025.489 559625.176 173025.625 559624.781 173025.722 559624.374 173025.780 559623.960 173025.798 559623.542 173025.776 559623.125 173025.471 559618.817 173025.087 559610.952 173025.097 559610.520 173025.164 559608.756 173025.271 559606.993 173025.303 559606.562 173025.459 559604.803 173025.655 559603.047 173025.836 559601.733 173026.061 559600.397 173026.324 559599.068 173026.620 559597.774 173026.961 559596.463 173027.340 559595.162 173027.695 559594.045 173028.215 559592.520 173028.774 559591.009 173029.369 559589.512 173029.826 559588.433 173030.485 559586.963 173031.180 559585.510 173031.911 559584.074 173032.073 559583.769 173032.760 559582.525 173033.482 559581.301 173034.237 559580.097 173035.027 559578.916 173035.224 559578.631 173036.054 559577.478 173036.916 559576.349 173037.810 559575.244 173038.735 559574.165 173039.641 559573.160 173040.704 559572.037 173041.796 559570.942 173042.916 559569.875 173043.918 559568.966 173045.088 559567.955 173046.284 559566.975 173047.505 559566.026 173047.908 559565.724 173049.029 559564.919 173050.172 559564.147 173051.338 559563.409 173052.524 559562.704 173052.962 559562.456 173054.176 559561.799 173055.407 559561.177 173056.657 559560.592 173057.922 559560.043 173058.702 559559.724 173060.185 559559.151 173061.681 559558.615 173063.191 559558.118 173064.279 559557.789 173064.713 559557.658 173066.246 559557.237 173067.789 559556.854 173069.341 559556.510 173070.867 559556.212 173072.434 559555.946 173074.008 559555.720 173075.587 559555.533 173077.170 559555.386 173089.129 559554.303 173109.043 559552.541 173132.973 559550.446 173152.857 559548.696 173176.727 559546.587 173176.917 559546.570 173196.776 559544.822 173220.683 559542.706 173220.953 559542.691 173222.120 559542.651 173223.287 559542.650 173224.454 559542.690 173224.724 559542.705 173224.734 559542.706 173225.888 559542.793 173227.048 559542.922 173228.203 559543.090 173228.499 559543.140 173229.510 559543.337 173230.512 559543.573 173231.504 559543.848 173232.485 559544.161 173232.768 559544.260 173233.732 559544.622 173234.681 559545.021 173235.614 559545.456 173236.529 559545.928 173236.546 559545.937 173237.542 559546.499 173238.518 559547.095 173239.472 559547.724 173240.404 559548.387 173241.312 559549.082 173242.195 559549.808 173243.052 559550.565 173243.882 559551.351 173244.320 559551.796 173244.684 559552.166 173245.457 559553.008 173246.100 559553.756 173246.817 559554.647 173247.502 559555.562 173247.620 559555.731 173248.155 559556.501 173248.228 559556.615 173248.736 559557.403</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b883496d5-e385-e58b-c888-623f5bf7d959">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:52:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.48024f8646784818a67b75585e1620fa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173025.866 559545.375 173025.671 559545.175 173029.109 559541.991 173032.605 559539.510 173040.813 559535.306 173048.321 559532.404 173054.252 559531.784 173064.337 559531.048 173078.751 559530.425 173091.313 559529.698 173101.873 559529.027 173112.045 559527.703 173122.746 559526.139 173135.856 559524.229 173148.672 559523.523 173163.053 559522.665 173172.198 559522.086 173172.196 559522.187 173164.382 559522.654 173164.378 559522.693 173153.103 559523.374 173141.867 559524.019 173136.732 559524.347 173130.956 559525.208 173117.823 559527.218 173106.064 559529.037 173094.729 559529.924 173092.640 559530.003 173079.322 559530.728 173065.558 559531.330 173054.718 559532.020 173048.416 559532.730 173040.916 559535.539 173032.708 559539.747 173029.326 559542.180 173025.866 559545.375</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b61fe388d-fe34-9a97-697d-c597fdefc681">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:52:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.48024f8646784818a67b75585e1620fa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173025.866 559545.375 173025.671 559545.175 173029.109 559541.991 173032.605 559539.510 173040.813 559535.306 173048.321 559532.404 173054.252 559531.784 173064.337 559531.048 173078.751 559530.425 173091.313 559529.698 173101.873 559529.027 173112.045 559527.703 173122.746 559526.139 173135.856 559524.229 173148.672 559523.523 173163.053 559522.665 173172.198 559522.086 173172.196 559522.187 173164.382 559522.654 173164.378 559522.693 173153.103 559523.374 173141.867 559524.019 173136.732 559524.347 173130.956 559525.208 173117.823 559527.218 173106.064 559529.037 173094.729 559529.924 173092.640 559530.003 173079.322 559530.728 173065.558 559531.330 173054.718 559532.020 173048.416 559532.730 173040.916 559535.539 173032.708 559539.747 173029.326 559542.180 173025.866 559545.375</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcab7f13e-42cd-29bc-6ba8-4e09170d9130">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.cb34b519da20426fa09b81cb1c36d706</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173023.281 559497.230 173028.718 559497.296 173034.845 559496.947 173041.084 559496.577 173047.321 559496.149 173054.813 559495.807 173061.054 559495.470 173067.295 559495.137 173073.539 559494.856 173078.538 559494.716 173081.039 559494.658 173084.783 559494.449 173087.526 559494.272 173088.774 559494.220 173097.516 559493.832 173105.008 559493.476 173111.249 559493.149 173117.492 559492.858 173121.240 559492.724 173124.983 559492.492 173128.731 559492.358 173134.972 559492.026 173138.722 559491.929 173143.717 559491.697 173147.461 559491.495 173153.706 559491.238 173161.204 559491.015 173161.205 559491.037 173157.459 559491.203 173152.464 559491.446 173148.720 559491.641 173143.726 559491.897 173137.484 559492.216 173133.739 559492.413 173129.991 559492.535 173123.752 559492.904 173118.754 559493.078 173115.009 559493.254 173111.263 559493.442 173107.519 559493.651 173102.526 559493.917 173097.536 559494.241 173092.540 559494.464 173087.544 559494.664 173083.516 559494.762 173068.531 559495.459 173053.548 559496.154 173028.587 559497.561 173023.590 559497.763 173023.197 559497.782 173023.281 559497.230</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bfd48a31d-c932-2278-44e4-2bdc4ed4e0d6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:58:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.cb34b519da20426fa09b81cb1c36d706</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173023.281 559497.230 173028.718 559497.296 173034.845 559496.947 173041.084 559496.577 173047.321 559496.149 173054.813 559495.807 173061.054 559495.470 173067.295 559495.137 173073.539 559494.856 173078.538 559494.716 173081.039 559494.658 173084.783 559494.449 173087.526 559494.272 173088.774 559494.220 173097.516 559493.832 173105.008 559493.476 173111.249 559493.149 173117.492 559492.858 173121.240 559492.724 173124.983 559492.492 173128.731 559492.358 173134.972 559492.026 173138.722 559491.929 173143.717 559491.697 173147.461 559491.495 173153.706 559491.238 173161.204 559491.015 173161.205 559491.037 173157.459 559491.203 173152.464 559491.446 173148.720 559491.641 173143.726 559491.897 173137.484 559492.216 173133.739 559492.413 173129.991 559492.535 173123.752 559492.904 173118.754 559493.078 173115.009 559493.254 173111.263 559493.442 173107.519 559493.651 173102.526 559493.917 173097.536 559494.241 173092.540 559494.464 173087.544 559494.664 173083.516 559494.762 173068.531 559495.459 173053.548 559496.154 173028.587 559497.561 173023.590 559497.763 173023.197 559497.782 173023.281 559497.230</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b921b794a-844c-ff96-6dab-0449ddc971b8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8e000a53ee0d463fa802f4af6ac836ad</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173024.319 559520.555 173025.704 559520.465 173037.960 559519.944 173042.954 559519.709 173088.502 559517.107 173092.249 559516.959 173097.246 559516.753 173103.488 559516.443 173107.235 559516.286 173112.229 559516.046 173117.225 559515.834 173120.976 559515.766 173124.717 559515.491 173127.215 559515.382 173129.711 559515.254 173133.456 559515.065 173135.958 559515.043 173140.952 559514.776 173145.941 559514.442 173150.941 559514.320 173154.688 559514.149 173157.184 559514.011 173159.678 559513.849 173163.426 559513.706 173167.172 559513.530 173170.916 559513.321 173175.911 559513.084 173180.903 559512.802 173182.153 559512.761 173179.653 559513.000 173175.906 559513.166 173169.666 559513.512 173162.174 559513.903 173158.430 559514.048 173155.930 559514.133 173153.433 559514.269 173148.436 559514.499 173143.446 559514.703 173137.203 559515.020 173128.468 559515.501 173122.233 559515.856 173114.738 559516.226 173109.742 559516.393 173104.745 559516.611 173099.750 559516.796 173093.508 559517.149 173088.513 559517.390 173086.945 559517.456 173083.200 559517.656 173078.211 559517.982 173071.968 559518.297 173068.226 559518.542 173064.483 559518.779 173058.241 559519.076 173053.248 559519.356 173045.756 559519.702 173042.008 559519.836 173037.016 559520.116 173032.020 559520.334 173024.405 559521.127 173024.319 559520.555</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7d4a9d2c-ea1c-c7b3-12ac-e6d891c5a58e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8e000a53ee0d463fa802f4af6ac836ad</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173024.319 559520.555 173025.704 559520.465 173037.960 559519.944 173042.954 559519.709 173088.502 559517.107 173092.249 559516.959 173097.246 559516.753 173103.488 559516.443 173107.235 559516.286 173112.229 559516.046 173117.225 559515.834 173120.976 559515.766 173124.717 559515.491 173127.215 559515.382 173129.711 559515.254 173133.456 559515.065 173135.958 559515.043 173140.952 559514.776 173145.941 559514.442 173150.941 559514.320 173154.688 559514.149 173157.184 559514.011 173159.678 559513.849 173163.426 559513.706 173167.172 559513.530 173170.916 559513.321 173175.911 559513.084 173180.903 559512.802 173182.153 559512.761 173179.653 559513.000 173175.906 559513.166 173169.666 559513.512 173162.174 559513.903 173158.430 559514.048 173155.930 559514.133 173153.433 559514.269 173148.436 559514.499 173143.446 559514.703 173137.203 559515.020 173128.468 559515.501 173122.233 559515.856 173114.738 559516.226 173109.742 559516.393 173104.745 559516.611 173099.750 559516.796 173093.508 559517.149 173088.513 559517.390 173086.945 559517.456 173083.200 559517.656 173078.211 559517.982 173071.968 559518.297 173068.226 559518.542 173064.483 559518.779 173058.241 559519.076 173053.248 559519.356 173045.756 559519.702 173042.008 559519.836 173037.016 559520.116 173032.020 559520.334 173024.405 559521.127 173024.319 559520.555</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="befc4fae0-a2cc-15fe-cd30-577f18f7db3f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:56:26</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.9af2908f6c394c60a4cf136ae903a106</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173034.679 559483.406 173034.672 559483.274 173041.043 559483.992 173046.780 559483.874 173060.323 559483.175 173066.239 559482.870 173082.982 559481.966 173096.135 559481.271 173110.885 559480.728 173126.617 559479.857 173126.612 559480.123 173119.499 559480.455 173106.252 559481.132 173097.038 559481.651 173084.920 559482.305 173084.923 559482.310 173074.839 559482.806 173065.157 559483.230 173055.116 559483.765 173046.566 559484.070 173041.016 559484.156 173041.012 559484.139 173034.679 559483.406</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8bcb272d-d8d4-711b-7889-bc30adea71de">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:56:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.9af2908f6c394c60a4cf136ae903a106</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173034.679 559483.406 173034.672 559483.274 173041.043 559483.992 173046.780 559483.874 173060.323 559483.175 173066.239 559482.870 173082.982 559481.966 173096.135 559481.271 173110.885 559480.728 173126.617 559479.857 173126.612 559480.123 173119.499 559480.455 173106.252 559481.132 173097.038 559481.651 173084.920 559482.305 173084.923 559482.310 173074.839 559482.806 173065.157 559483.230 173055.116 559483.765 173046.566 559484.070 173041.016 559484.156 173041.012 559484.139 173034.679 559483.406</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcc092cc7-1520-5943-8cac-6f8489b9217b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:56:19</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.98d55d3fca9149bdb5b7a83b49b7f346</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173532.448 559525.175 173532.650 559524.857 173534.661 559525.177 173543.400 559526.014 173543.360 559526.243 173541.136 559526.014 173532.448 559525.175</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b12322886-e72c-d939-a831-a5d7371af904">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:56:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.98d55d3fca9149bdb5b7a83b49b7f346</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173532.448 559525.175 173532.650 559524.857 173534.661 559525.177 173543.400 559526.014 173543.360 559526.243 173541.136 559526.014 173532.448 559525.175</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b79e2c7c7-fea3-9942-9bfc-1e22b5dd741a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.212eba4aca254e5b9030bb8ae65fb0e1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173519.792 559515.866 173520.646 559515.398 173525.150 559519.379 173525.884 559520.027 173525.433 559520.739 173525.428 559520.736 173524.256 559519.812 173519.792 559515.866</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8924cda0-412f-caca-d172-41e73d72fc51">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.212eba4aca254e5b9030bb8ae65fb0e1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173519.792 559515.866 173520.646 559515.398 173525.150 559519.379 173525.884 559520.027 173525.433 559520.739 173525.428 559520.736 173524.256 559519.812 173519.792 559515.866</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd88c260b-3114-3ee4-3d45-71df51f26964">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-11</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-08-11T15:04:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2075d501b38745e4bce04743af90cf17</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172618.002 559219.632 172617.790 559219.977 172613.088 559218.025 172601.179 559219.038 172592.190 559219.814 172586.189 559220.294 172566.367 559221.898 172556.302 559222.792 172556.168 559222.804 172556.148 559222.805 172556.114 559222.422 172561.388 559221.944 172576.929 559220.642 172600.195 559218.721 172613.151 559217.618 172618.002 559219.632</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd3643a05-fd18-e0d3-abba-a025106f3a07">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e29f34e30ecd40fcbee444f4fb206990</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172925.747 559525.464 172923.432 559525.604 172918.434 559525.778 172913.444 559526.110 172908.449 559526.330 172903.459 559526.652 172898.464 559526.873 172893.464 559526.997 172888.476 559527.364 172883.618 559527.486 172878.625 559527.750 172873.633 559528.045 172871.134 559528.136 172868.637 559528.260 172866.140 559528.387 172861.146 559528.637 172858.650 559528.773 172853.652 559528.929 172851.152 559528.988 172846.158 559529.224 172844.734 559529.169 172848.649 559528.944 172851.146 559528.842 172853.644 559528.721 172858.638 559528.481 172863.637 559528.363 172868.631 559528.101 172873.626 559527.884 172878.618 559527.585 172883.614 559527.380 172886.112 559527.287 172888.466 559527.148 172895.953 559526.696 172900.946 559526.432 172905.946 559526.314 172908.441 559526.148 172913.435 559525.903 172918.426 559525.596 172923.423 559525.416 172925.739 559525.284 172925.747 559525.464</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bb0ee6fff-c358-79d5-7205-92396f83d06e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e29f34e30ecd40fcbee444f4fb206990</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172925.747 559525.464 172923.432 559525.604 172918.434 559525.778 172913.444 559526.110 172908.449 559526.330 172903.459 559526.652 172898.464 559526.873 172893.464 559526.997 172888.476 559527.364 172883.618 559527.486 172878.625 559527.750 172873.633 559528.045 172871.134 559528.136 172868.637 559528.260 172866.140 559528.387 172861.146 559528.637 172858.650 559528.773 172853.652 559528.929 172851.152 559528.988 172846.158 559529.224 172844.734 559529.169 172848.649 559528.944 172851.146 559528.842 172853.644 559528.721 172858.638 559528.481 172863.637 559528.363 172868.631 559528.101 172873.626 559527.884 172878.618 559527.585 172883.614 559527.380 172886.112 559527.287 172888.466 559527.148 172895.953 559526.696 172900.946 559526.432 172905.946 559526.314 172908.441 559526.148 172913.435 559525.903 172918.426 559525.596 172923.423 559525.416 172925.739 559525.284 172925.747 559525.464</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b90321610-1d9f-18f4-9996-1812fa2d99a4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:52:23</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.3b1bd4e6118a479f97b9fe8ce982380e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172926.257 559538.444 172921.720 559538.671 172914.227 559539.049 172904.242 559539.569 172896.750 559539.907 172889.259 559540.161 172886.084 559540.269 172876.667 559540.651 172866.060 559541.100 172854.261 559541.550 172843.468 559541.872 172832.787 559542.135 172825.057 559542.390 172825.052 559541.983 172832.775 559541.809 172843.440 559541.618 172854.224 559541.323 172866.036 559540.889 172876.646 559540.382 172886.121 559539.950 172889.282 559539.791 172895.839 559539.446 172908.523 559538.790 172923.063 559538.098 172926.237 559537.947 172926.257 559538.444</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1b643efc-c332-206b-ec06-098ebe24b5aa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:52:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.3b1bd4e6118a479f97b9fe8ce982380e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172926.257 559538.444 172921.720 559538.671 172914.227 559539.049 172904.242 559539.569 172896.750 559539.907 172889.259 559540.161 172886.084 559540.269 172876.667 559540.651 172866.060 559541.100 172854.261 559541.550 172843.468 559541.872 172832.787 559542.135 172825.057 559542.390 172825.052 559541.983 172832.775 559541.809 172843.440 559541.618 172854.224 559541.323 172866.036 559540.889 172876.646 559540.382 172886.121 559539.950 172889.282 559539.791 172895.839 559539.446 172908.523 559538.790 172923.063 559538.098 172926.237 559537.947 172926.257 559538.444</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b0adc5179-a47b-a1f3-baea-76b55007141b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5cc20347bf894c15983e59acd4615335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172924.851 559502.680 172918.839 559502.997 172913.844 559503.240 172906.354 559503.616 172901.356 559503.794 172896.362 559504.027 172893.866 559504.170 172888.875 559504.472 172884.453 559504.636 172881.956 559504.753 172876.961 559504.989 172871.966 559505.206 172866.973 559505.485 172864.476 559505.605 172856.986 559505.989 172851.993 559506.246 172846.998 559506.482 172842.002 559506.684 172837.006 559506.892 172834.507 559506.984 172832.012 559507.150 172827.025 559507.520 172819.532 559507.857 172814.543 559508.195 172807.051 559508.539 172812.039 559508.184 172817.031 559507.893 172819.527 559507.754 172822.022 559507.601 172827.019 559507.402 172832.006 559507.038 172837.002 559506.818 172842.000 559506.638 172844.493 559506.452 172849.490 559506.261 172854.480 559505.937 172859.470 559505.626 172864.463 559505.348 172869.457 559505.111 172874.450 559504.851 172879.446 559504.637 172884.440 559504.393 172888.859 559504.147 172893.850 559503.853 172898.843 559503.580 172906.337 559503.278 172911.331 559503.036 172916.329 559502.873 172921.326 559502.676 172924.845 559502.524 172924.851 559502.680</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bc9a5b34d-0471-1036-3715-4706e7a3599b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5cc20347bf894c15983e59acd4615335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172924.851 559502.680 172918.839 559502.997 172913.844 559503.240 172906.354 559503.616 172901.356 559503.794 172896.362 559504.027 172893.866 559504.170 172888.875 559504.472 172884.453 559504.636 172881.956 559504.753 172876.961 559504.989 172871.966 559505.206 172866.973 559505.485 172864.476 559505.605 172856.986 559505.989 172851.993 559506.246 172846.998 559506.482 172842.002 559506.684 172837.006 559506.892 172834.507 559506.984 172832.012 559507.150 172827.025 559507.520 172819.532 559507.857 172814.543 559508.195 172807.051 559508.539 172812.039 559508.184 172817.031 559507.893 172819.527 559507.754 172822.022 559507.601 172827.019 559507.402 172832.006 559507.038 172837.002 559506.818 172842.000 559506.638 172844.493 559506.452 172849.490 559506.261 172854.480 559505.937 172859.470 559505.626 172864.463 559505.348 172869.457 559505.111 172874.450 559504.851 172879.446 559504.637 172884.440 559504.393 172888.859 559504.147 172893.850 559503.853 172898.843 559503.580 172906.337 559503.278 172911.331 559503.036 172916.329 559502.873 172921.326 559502.676 172924.845 559502.524 172924.851 559502.680</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bee59af43-f10c-28fd-925d-b303c8b9a7f0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-20T15:33:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.40e481c40b0f427c86f7f80ccc712eba</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173010.259 559650.205 173010.259 559649.843 173015.101 559649.843 173017.939 559649.843 173018.597 559649.909 173018.626 559650.229 173012.213 559650.205 173010.259 559650.205</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b29f03c59-25fd-3478-f3af-13637f908981">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-20T15:33:38.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.511dc6145e274876842036d3219a34d9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173027.772 559650.218 173025.304 559650.264 173019.912 559650.100 173019.901 559649.843 173022.396 559649.843 173027.772 559649.843 173027.772 559650.218</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bc1909a9c-0210-eb92-2891-038bda0b0731">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.d7fe094c4aca4e888a369b3ff7b7d0f6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173029.883 559481.768 173034.679 559483.406 173034.630 559483.400 173029.893 559481.906 173025.311 559480.033 173028.100 559481.041 173029.883 559481.768</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b4aa07504-b744-19a3-434c-731099399758">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.d7fe094c4aca4e888a369b3ff7b7d0f6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173029.883 559481.768 173034.679 559483.406 173034.630 559483.400 173029.893 559481.906 173025.311 559480.033 173028.100 559481.041 173029.883 559481.768</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b67f61406-e138-f047-6558-5ea17649e7bf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.14bd7586ebee4c10982234b5c936e0e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173021.427 559477.755 173025.311 559480.033 173021.386 559477.835 173021.427 559477.755</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b51ff35b0-f1c4-972c-2720-6c1adffb624e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.14bd7586ebee4c10982234b5c936e0e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173021.427 559477.755 173025.311 559480.033 173021.386 559477.835 173021.427 559477.755</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b37ba9e1e-3bb2-ad3b-ffb5-ebe7e4ebbc6b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:49:50</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0402ad9e432d4aa590008e539efc2d8f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173012.124 559498.331 173006.111 559498.620 172998.620 559498.968 172986.135 559499.587 172980.014 559499.876 172979.945 559499.291 172980.953 559499.243 172982.787 559499.155 172984.869 559499.055 172986.451 559498.978 172987.883 559498.910 172990.425 559498.787 172991.591 559498.731 172993.314 559498.648 172995.236 559498.556 172996.732 559498.484 172997.680 559498.438 172999.357 559498.358 173000.419 559498.307 173002.166 559498.223 173004.242 559498.123 173005.998 559498.038 173007.377 559497.972 173009.145 559497.887 173010.799 559497.807 173012.093 559497.745 173012.124 559498.331</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6427d15c-bdc5-0c2e-3227-3528c1e9615d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:49:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0402ad9e432d4aa590008e539efc2d8f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173012.124 559498.331 173006.111 559498.620 172998.620 559498.968 172986.135 559499.587 172980.014 559499.876 172979.945 559499.291 172980.953 559499.243 172982.787 559499.155 172984.869 559499.055 172986.451 559498.978 172987.883 559498.910 172990.425 559498.787 172991.591 559498.731 172993.314 559498.648 172995.236 559498.556 172996.732 559498.484 172997.680 559498.438 172999.357 559498.358 173000.419 559498.307 173002.166 559498.223 173004.242 559498.123 173005.998 559498.038 173007.377 559497.972 173009.145 559497.887 173010.799 559497.807 173012.093 559497.745 173012.124 559498.331</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b99ccaf26-f38b-74ad-06c7-b638d85a9465">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:51:35</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.286acb6e873643cfb9fff4578bf4e2f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173013.673 559521.656 173012.222 559521.728 173010.572 559521.810 173008.741 559521.900 173006.707 559522.001 173004.684 559522.102 173003.304 559522.170 173001.765 559522.246 173000.150 559522.326 172998.873 559522.390 172997.227 559522.471 172996.063 559522.529 172995.188 559522.573 172994.019 559522.631 172993.025 559522.680 172992.010 559522.730 172990.797 559522.790 172989.900 559522.835 172988.492 559522.905 172987.285 559522.965 172985.950 559523.031 172984.704 559523.093 172983.340 559523.160 172982.186 559523.218 172981.589 559523.247 172981.084 559523.272 172980.598 559523.292 172980.627 559522.692 172985.520 559522.459 172993.011 559522.106 173000.503 559521.742 173007.993 559521.367 173013.658 559521.104 173013.673 559521.656</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3d6ba6c8-7d1d-7669-af23-dd1bba90e2e0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:51:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.286acb6e873643cfb9fff4578bf4e2f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173013.673 559521.656 173012.222 559521.728 173010.572 559521.810 173008.741 559521.900 173006.707 559522.001 173004.684 559522.102 173003.304 559522.170 173001.765 559522.246 173000.150 559522.326 172998.873 559522.390 172997.227 559522.471 172996.063 559522.529 172995.188 559522.573 172994.019 559522.631 172993.025 559522.680 172992.010 559522.730 172990.797 559522.790 172989.900 559522.835 172988.492 559522.905 172987.285 559522.965 172985.950 559523.031 172984.704 559523.093 172983.340 559523.160 172982.186 559523.218 172981.589 559523.247 172981.084 559523.272 172980.598 559523.292 172980.627 559522.692 172985.520 559522.459 172993.011 559522.106 173000.503 559521.742 173007.993 559521.367 173013.658 559521.104 173013.673 559521.656</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b57c4f0e1-e0d6-c0c4-e9f0-81278b336bd0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ea6bbd4b99cf4ce685a84c5bec1cd545</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172968.790 559500.431 172958.321 559501.032 172958.303 559500.777 172958.962 559500.722 172968.739 559499.909 172968.790 559500.431</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b83b3898a-6440-61aa-081a-e4c303754554">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ea6bbd4b99cf4ce685a84c5bec1cd545</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172968.790 559500.431 172958.321 559501.032 172958.303 559500.777 172958.962 559500.722 172968.739 559499.909 172968.790 559500.431</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6c6c3538-70f7-f03e-5fa2-03fe1a62cd94">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:58:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c147e83d24e149a495461b0c1c701d25</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172969.864 559523.187 172969.837 559523.822 172968.381 559523.467 172963.386 559523.679 172960.821 559523.771 172960.169 559523.794 172960.155 559523.592 172969.864 559523.187</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b56b21828-292e-a25c-fd5b-b095011f01c5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:58:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c147e83d24e149a495461b0c1c701d25</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172969.864 559523.187 172969.837 559523.822 172968.381 559523.467 172963.386 559523.679 172960.821 559523.771 172960.169 559523.794 172960.155 559523.592 172969.864 559523.187</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b26e63e5b-a39a-f01c-70e6-dc0fa05e5e28">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.dfaac675950040b8acf2e704d0f0cba4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172968.747 559540.825 172968.815 559541.718 172969.785 559555.417 172968.976 559555.474 172968.001 559541.389 172961.273 559538.665 172961.224 559538.094 172961.877 559538.028 172968.747 559540.825</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="be48480ca-2884-e26a-db38-f83baa832be8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:25</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8278018e14554f8f9bad2bb5df692352</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172950.791 559524.240 172943.407 559524.616 172938.412 559524.838 172933.418 559525.078 172928.423 559525.303 172925.747 559525.464 172925.739 559525.284 172928.416 559525.131 172933.409 559524.871 172938.397 559524.504 172943.393 559524.309 172948.389 559524.089 172951.431 559523.956 172951.450 559524.223 172950.791 559524.240</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b16280d1e-b396-033d-10c5-761669ebb675">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.8278018e14554f8f9bad2bb5df692352</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172950.791 559524.240 172943.407 559524.616 172938.412 559524.838 172933.418 559525.078 172928.423 559525.303 172925.747 559525.464 172925.739 559525.284 172928.416 559525.131 172933.409 559524.871 172938.397 559524.504 172943.393 559524.309 172948.389 559524.089 172951.431 559523.956 172951.450 559524.223 172950.791 559524.240</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bdaa3f4bc-4eac-adb8-4fba-83fe7edaaba2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:58:18</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c23ee993e9094065ab8e41ec034d1093</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172952.362 559536.764 172952.385 559537.220 172946.694 559537.470 172941.700 559537.690 172931.706 559538.180 172926.713 559538.421 172926.257 559538.444 172926.237 559537.947 172935.298 559537.515 172946.611 559537.035 172951.699 559536.784 172952.362 559536.764</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b9a141830-0e97-574c-61e2-394a7da98a0f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:58:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c23ee993e9094065ab8e41ec034d1093</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172952.362 559536.764 172952.385 559537.220 172946.694 559537.470 172941.700 559537.690 172931.706 559538.180 172926.713 559538.421 172926.257 559538.444 172926.237 559537.947 172935.298 559537.515 172946.611 559537.035 172951.699 559536.784 172952.362 559536.764</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b16dc8a8e-0765-604f-16e9-7151a419e1f3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T12:28:09</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af96899e4d5105255802d1390152e7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">174053.814 559498.778 174050.623 559502.793 174047.180 559510.197 174039.489 559526.737 174035.594 559536.281 174029.423 559545.739 174028.490 559547.056 174012.282 559569.952 174012.053 559570.308 174011.733 559570.948 174011.784 559571.661 174011.971 559572.137 174013.494 559573.668 174021.246 559580.561 174027.290 559585.936 174027.795 559588.551 174026.577 559589.889 174026.174 559589.982 174024.364 559592.237 174017.160 559601.212 174014.709 559604.571 174013.209 559606.369 174010.402 559609.252 174009.166 559610.890 174005.094 559616.006 174004.525 559616.675 174004.090 559617.093 174003.674 559617.483 174003.055 559618.188 174001.866 559619.522 174000.074 559621.566 173997.638 559624.806 173991.096 559632.517 173985.776 559638.651 173978.733 559647.122 173973.888 559652.581 173970.762 559656.255 173969.922 559657.207 173953.862 559675.679 173948.860 559672.221 173941.544 559665.758</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b701fb435-bfb9-c656-1faa-2f756af2e0a1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T12:28:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af96899e4d5105255802d1390152e7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">174053.814 559498.778 174050.623 559502.793 174047.180 559510.197 174039.489 559526.737 174035.594 559536.281 174029.423 559545.739 174028.490 559547.056 174012.282 559569.952 174012.053 559570.308 174011.733 559570.948 174011.784 559571.661 174011.971 559572.137 174013.494 559573.668 174021.246 559580.561 174027.290 559585.936 174027.685 559587.980 174026.499 559589.551 174026.174 559589.982 174024.335 559592.217 174017.020 559601.106 174014.458 559604.220 174012.874 559606.145 174010.320 559609.249 174009.050 559610.792 174004.867 559615.875 174002.990 559618.156 174001.866 559619.522 174000.074 559621.566 173997.363 559624.741 173990.802 559632.424 173985.547 559638.577 173978.421 559646.921 173973.680 559652.473 173970.537 559656.153 173969.585 559657.268 173953.862 559675.679</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd6d4e49a-44a7-2ee1-c0f6-68702c298aee">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-07-02T10:58:19</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af9689ac36fd1a255802d10a014e90</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173936.533 559644.293 173928.577 559653.758 173924.267 559659.252 173924.088 559659.443 173916.397 559671.121 173914.330 559673.989 173907.825 559683.014 173902.460 559690.463 173902.375 559690.405 173900.241 559693.535 173899.885 559694.038 173895.553 559700.601 173889.991 559709.495 173890.699 559709.972 173887.794 559715.107 173875.986 559733.310 173875.213 559734.504 173872.990 559737.930 173865.145 559752.372 173861.818 559759.760 173859.197 559767.734 173858.852 559769.221 173857.915 559773.259 173856.870 559777.760 173854.001 559783.527 173852.753 559786.037</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bd8af4f05-8392-3738-b4d4-36180304f7a8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2025-07-11T11:46:48</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-07-02T10:58:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af9689ac36fd1a255802d10a014e90</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173936.533 559644.293 173928.577 559653.758 173924.267 559659.252 173924.088 559659.443 173916.397 559671.121 173914.330 559673.989 173907.926 559682.731 173905.040 559686.862 173902.460 559690.463 173902.375 559690.405 173900.241 559693.535 173899.885 559694.038 173895.553 559700.601 173889.991 559709.495 173890.699 559709.972 173887.794 559715.107 173875.986 559733.310 173875.213 559734.504 173872.990 559737.930 173865.145 559752.372 173861.818 559759.760 173859.197 559767.734 173858.852 559769.221 173857.915 559773.259 173856.870 559777.760 173854.001 559783.527 173852.753 559786.037</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b106c2128-e6dc-af90-dbdd-12ad80f17107">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:23</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0d6a08280af84772afd8de49ff4415e6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172948.453 559501.239 172948.464 559501.630 172946.310 559501.758 172943.814 559501.896 172941.317 559502.007 172938.815 559502.039 172933.822 559502.297 172931.325 559502.415 172926.328 559502.602 172924.851 559502.680 172924.845 559502.524 172926.321 559502.460 172931.313 559502.168 172936.306 559501.911 172943.795 559501.495 172947.782 559501.276 172948.453 559501.239</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b798628c7-6c0d-c4ef-ee1b-fd6f7db858b9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0d6a08280af84772afd8de49ff4415e6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172948.453 559501.239 172948.464 559501.630 172946.310 559501.758 172943.814 559501.896 172941.317 559502.007 172938.815 559502.039 172933.822 559502.297 172931.325 559502.415 172926.328 559502.602 172924.851 559502.680 172924.845 559502.524 172926.321 559502.460 172931.313 559502.168 172936.306 559501.911 172943.795 559501.495 172947.782 559501.276 172948.453 559501.239</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bf6500bbe-4bcd-a5b9-9978-19393cf42e4d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-02-06T15:03:09</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.10af83b23e2d4a75b360ebd5605b26f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172959.997 559539.210 172954.092 559539.581 172953.023 559528.126 172959.166 559527.721 172959.997 559539.210</gml:posList></gml:LinearRing></gml:exterior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172958.947 559527.977 172955.199 559528.222 172953.349 559528.343 172954.305 559539.397 172956.027 559539.295 172959.800 559539.070 172959.553 559535.863 172958.947 559527.977</gml:posList></gml:LinearRing></gml:interior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b71cefbcb-6508-3d41-bc1d-15431406c92c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-02-09T14:07:22</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-02-06T15:03:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.10af83b23e2d4a75b360ebd5605b26f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172959.923 559538.186 172959.997 559539.210 172954.092 559539.581 172953.023 559528.126 172959.166 559527.721 172959.923 559538.186</gml:posList></gml:LinearRing></gml:exterior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172955.199 559528.222 172953.349 559528.343 172954.305 559539.397 172956.027 559539.295 172959.800 559539.070 172959.727 559538.116 172959.553 559535.863 172958.947 559527.977 172955.199 559528.222</gml:posList></gml:LinearRing></gml:interior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b37360642-aa4b-63f6-c540-df2f4780e4d0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-02-06T15:03:08</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.565f116c9aed481bb7841133c486eb73</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172960.127 559538.104 172960.230 559539.445 172953.940 559539.826 172953.732 559537.416 172953.164 559530.854 172952.915 559527.970 172959.315 559527.552 172960.127 559538.104</gml:posList></gml:LinearRing></gml:exterior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172959.166 559527.721 172953.023 559528.126 172954.092 559539.581 172959.997 559539.210 172959.166 559527.721</gml:posList></gml:LinearRing></gml:interior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b8a90f2b7-1ca8-7b43-cf59-5d3dd83d14e9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-02-09T14:07:22</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-02-06T15:03:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.565f116c9aed481bb7841133c486eb73</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172960.139 559538.262 172960.230 559539.445 172953.940 559539.826 172953.732 559537.416 172953.164 559530.854 172952.915 559527.970 172959.315 559527.552 172960.127 559538.104 172960.139 559538.262</gml:posList></gml:LinearRing></gml:exterior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172959.923 559538.186 172959.166 559527.721 172953.023 559528.126 172954.092 559539.581 172959.997 559539.210 172959.923 559538.186</gml:posList></gml:LinearRing></gml:interior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b3a96ec2a-48c2-1de4-5ca1-a91851f6ee82">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-04-21</creationDate>
            <imgeo:LV-publicatiedatum>2022-05-11T12:01:47</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-11T10:58:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.c29512bbf14c4c4699c3a8548b57bde3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172902.431 558471.741 172902.610 558475.133 172904.249 558475.388 172904.687 558475.456</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b153eac1d-3800-afd1-5a6a-92a30a9cfb6c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-04-21</creationDate>
            <imgeo:LV-publicatiedatum>2022-05-11T12:01:47</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-05-11T10:58:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.2ce6b540905a47109d9d805db977d3b6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172901.224 558480.946 172897.018 558476.649 172894.314 558446.320 172891.669 558417.586 172898.768 558404.120</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b1a0b5aa5-4cc2-d397-b0c1-bcbe1fc1be34">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.ab547d7cecdb47aca534bfe7062645e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172871.093 558294.873 172868.607 558305.724 172868.398 558305.690 172868.519 558305.087 172870.987 558294.367 172874.617 558278.600 172874.685 558278.245 172874.889 558278.297 172871.093 558294.873</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b772c80dc-eec2-a208-e514-f7d8e922436f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.8c38956bf16549f58f827e3c73b5b6ed</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172864.492 558304.082 172864.380 558304.555 172864.217 558304.508 172868.875 558284.231 172870.468 558277.298 172870.639 558277.346 172870.599 558277.535 172868.962 558284.649 172864.492 558304.082</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bbb329487-882d-b2e1-19cb-1b4bfa2c6cae">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:49:35</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.abf92252c2ed420ca0da11458b0c1308</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172075.827 559840.459 172074.107 559841.705</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="bcc7e240a-505b-5fba-e3e3-902e44c3b5d3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:49:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.abf92252c2ed420ca0da11458b0c1308</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172075.827 559840.459 172074.107 559841.705</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b7781fd04-eb73-e716-87e7-6574a950c523">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93db0ec6d401255802ccd300ef49</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172177.456 559875.510 172173.444 559871.598 172172.224 559863.998 172171.902 559861.899 172171.759 559860.966 172169.513 559845.785 172224.222 559791.299</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="b6601a1b0-67b3-9635-9e91-6f8e7f16ffe5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-11</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-08-11T15:03:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.20dc14fef01647f18e10adc4fc1465b5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172506.793 559226.786 172500.387 559231.369 172482.836 559243.924 172479.705 559241.635 172479.742 559241.588 172479.957 559241.320 172480.123 559241.444 172482.838 559243.431 172506.648 559226.398 172546.586 559223.107 172546.613 559223.506 172546.610 559223.506 172536.810 559224.230 172535.131 559224.354 172511.129 559226.379 172509.627 559226.520 172506.793 559226.786</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Scheiding gml:id="befb1b44e-ce56-1fac-66c3-87b4b0561da3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-28T17:48:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02af93db0ed9a160255802cfa3012f24</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172188.827 559886.375 172190.807 559887.627 172193.079 559889.772 172212.240 559908.310 172232.520 559927.730 172251.050 559946.480 172271.150 559966.220 172280.140 559975.000 172285.530 559980.330 172293.730 559988.420 172297.140 559991.630 172305.550 560000.000 172313.630 560008.000 172321.290 560015.520 172322.631 560016.827 172323.127 560017.310 172332.260 560026.210 172346.240 560039.900 172356.990 560050.460 172365.240 560058.730 172366.130 560059.570 172366.700 560060.130 172367.240 560060.640 172367.810 560061.050 172368.274 560061.359 172369.044 560062.112 172371.204 560063.388 172379.905 560068.523 172380.942 560069.337 172405.491 560090.821 172408.840 560093.970 172413.235 560097.849 172418.584 560102.965 172435.662 560120.280 172440.680 560125.368 172440.890 560125.590 172441.587 560126.287 172442.465 560127.177 172456.495 560138.645 172476.162 560151.044</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Scheiding>
    </cityObjectMember>
</CityModel>