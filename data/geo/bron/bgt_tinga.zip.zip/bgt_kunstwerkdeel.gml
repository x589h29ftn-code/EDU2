<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7a296cfd-a81e-4715-89fa-2607b00efb99">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-11-02T14:33:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T13:54:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.91ca01bf6b554d6d992b0b8089079563</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170692.971 559371.337 170694.538 559374.691</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b661a68a4-d0f3-0f53-1a28-37a06cea251c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-23</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-11-02T14:33:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-23T16:16:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.68e16f5b79e644e295856823f8f68204</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170628.445 559390.182 170630.864 559393.702</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bca398344-6c90-9d07-4176-20292ceae8f8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-23</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-02T14:33:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.68e16f5b79e644e295856823f8f68204</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170628.445 559390.182 170629.011 559391.006 170630.296 559392.876 170630.864 559393.702</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bad189c14-0038-47fb-65ae-96b051f321d2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-11-02T14:33:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T13:52:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.074e94f8f9ce48cc986e642c0e3ebed1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170550.869 559290.068 170552.443 559293.498</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bea020a4f-b87f-8e7e-7ccd-b2764a23a82d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2019-01-18T13:42:03</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-02T14:33:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.074e94f8f9ce48cc986e642c0e3ebed1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170550.869 559290.068 170551.286 559290.977 170552.026 559292.589 170552.443 559293.498</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba94e35b2-2246-caac-c64d-0bd13e801def">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-16T12:36:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.7542f1ee3fee45fe8a8c59725de67650</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170321.020 558635.242 170321.579 558634.574 170321.954 558634.126 170322.383 558633.613 170322.951 558632.934 170328.626 558637.685 170331.280 558639.907 170358.684 558662.847 170361.198 558664.948 170364.513 558667.461 170366.826 558665.122 170374.338 558671.437 170374.761 558671.792 170378.849 558675.081 170378.956 558675.167 170376.776 558677.800 170415.085 558709.821 170414.480 558710.521 170414.427 558710.583 170413.919 558711.171 170413.210 558711.991 170342.309 558653.048 170321.020 558635.242</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">perron</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b097b5ab8-56e1-b00d-a224-dbab7d33fe7e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-22T15:28:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.34cb27d5b1dc46f09bf7f0ad526cfe4a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170439.874 558675.333 170435.275 558679.130</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bde0eb01c-b6b9-ff21-5644-ebca7939f139">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.690e0285696c4aa2b96e2ef71bddc55a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170403.348 558244.137 170403.474 558243.514 170396.917 558242.190 170397.167 558240.954 170403.723 558242.278 170405.052 558242.546 170404.676 558244.407 170403.348 558244.137</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b66c7e987-0560-d21f-5995-9e61b09e710b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-10-27</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-10-27T13:53:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.f8b078da9a054c868bce63d921b38dbe</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170379.341 558134.243 170381.163 558134.622 170380.806 558136.390 170378.929 558136.025 170379.341 558134.243</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba95c1c92-a7c1-eb04-3725-5f940e66d8b8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-06-15</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-27T23:36:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-06-15T11:43:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.facab9447c8b456e883fb7e7a9a470b7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170357.277 558184.017 170357.288 558185.637 170347.630 558187.536 170347.283 558186.027 170357.277 558184.017</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf5830861-8b58-9338-1823-73fbae404108">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-06-15</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-27T23:36:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-06-15T11:43:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1c3e33dedf6c402588ed1145d8cb62e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170357.404 558177.206 170357.554 558178.092 170345.972 558180.345 170344.964 558175.975 170346.572 558173.153 170345.503 558172.589 170339.392 558169.427 170329.825 558164.429 170320.172 558159.245 170320.783 558158.084 170321.214 558157.266 170321.533 558157.434 170321.905 558158.601 170357.404 558177.206</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b606e7b5c-19e5-3a2d-cfa8-6f831cf6ab0c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-06-15T11:43:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.29b203a2cbb64a6da3225a6ffb633664</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170323.380 558159.539 170333.573 558164.904 170343.096 558170.030 170353.643 558175.493 170357.259 558177.125 170357.359 558177.986 170346.068 558180.321 170347.225 558186.039 170357.277 558184.017 170357.288 558185.637 170346.168 558187.823 170343.712 558175.795 170345.467 558172.708 170339.392 558169.427 170329.825 558164.429 170322.689 558160.820 170323.380 558159.539</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2c828d58-0dcf-538f-eb50-dcfebdf0294a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-27T23:36:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-06-15T11:43:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.29b203a2cbb64a6da3225a6ffb633664</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170347.630 558187.536 170346.168 558187.823 170343.712 558175.795 170345.503 558172.589 170346.572 558173.153 170344.964 558175.975 170347.630 558187.536</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b24417ddb-f365-22c0-5539-1735815da811">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8552b9a239324a8e98000d8fb3c8db75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170332.694 558235.205 170331.964 558231.498 170339.472 558230.844 170339.678 558234.658 170332.694 558235.205</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b10ccd1da-ba83-1a6a-7809-2ceed4c647ff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.467219cd08104d68807c591b7ff5bba3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170279.873 558186.053 170280.224 558183.131 170279.664 558179.956 170279.209 558177.283 170279.619 558177.216 170280.110 558180.376 170280.629 558183.071 170281.856 558185.826 170279.901 558186.174 170279.873 558186.053</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4f20e300-3775-077c-5692-34b5cc19b8a0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.af679676b99246d7bb5431b6d0ef4616</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170288.163 558173.404 170288.941 558173.233 170291.051 558184.975 170290.147 558185.123 170281.929 558186.465 170281.859 558185.833 170290.056 558184.464 170288.163 558173.404</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b889dae5b-89c6-9b4b-30d1-dd77d8691ca7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.052bf914e1d8421ea320047ad41f30d8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170279.901 558186.174 170280.026 558186.715 170270.105 558188.403 170269.993 558187.881 170279.901 558186.174</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8daa2384-587c-e64e-8908-642ff0da49c6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.15369a1db4f7455fbd58fcc3bcae62ec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170267.999 558188.079 170269.118 558184.722 170269.804 558179.710 170270.136 558179.774 170269.494 558184.962 170269.943 558187.646 170269.993 558187.881 170268.011 558188.176 170267.999 558188.079</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b999d0b67-afc1-ab7e-9faf-3632326711c7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.01929c744cb342a2a2fb4eeeb76f81aa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170252.461 558184.039 170253.372 558185.755 170256.645 558188.358 170260.392 558189.439 170268.011 558188.176 170268.076 558188.707 170260.348 558190.172 170259.918 558190.103 170256.305 558188.910 170255.995 558188.711 170252.923 558186.239 170252.669 558185.902 170251.871 558184.355 170252.461 558184.039</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8849ced4-11e2-9dc7-95b1-012697ca9182">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ea6145b66f9d4c5390fc966b3d0ebfc8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170249.842 558170.007 170250.738 558169.809 170251.279 558177.837 170251.616 558182.296 170251.461 558182.331 170250.875 558182.630 170249.842 558170.007</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b17cb953c-2b51-d48d-554a-4e483f55be17">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9434951970994a09be009d87c94c00b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170254.397 558181.663 170259.183 558179.241 170259.358 558179.554 170254.505 558182.036 170252.524 558183.996 170252.461 558184.039 170251.461 558182.331 170251.616 558182.296 170254.397 558181.663</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b200712a7-5662-a54f-3ec5-c2d3f769f43a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-06-08T14:19:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T13:47:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.2a6c512742544d7faf8c212e0f6f2d2c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170325.047 558740.621 170327.707 558744.493</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6a5c62a5-f0ae-b8c8-9b97-bb139bc1b4be">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-27T23:36:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-06-08T14:19:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.2a6c512742544d7faf8c212e0f6f2d2c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170325.047 558740.621 170325.614 558741.447 170326.894 558743.309 170327.140 558743.668 170327.707 558744.493</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba18bbf1f-71c9-87af-cc86-988c5bd21bff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ef0e2933c60c4054b8cc1d944b8ee922</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170136.702 558130.080 170130.152 558128.685 170142.777 558113.173 170141.998 558115.785 170134.036 558125.568 170137.833 558128.714 170136.702 558130.080</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf492dad4-0a49-eb3a-87f4-b27bef8965b3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.749ede0fdb6c4816891ed2c87710060d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170160.174 558091.782 170178.017 558095.962 170183.745 558097.431 170183.552 558098.280 170160.475 558092.635 170151.251 558104.325 170152.143 558113.067 170137.525 558130.810 170136.702 558130.080 170137.833 558128.714 170150.996 558112.823 170150.111 558104.288 170160.174 558091.782</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbc1aeb4a-2b17-309b-35c0-95acdead1ee4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.39dba2bb741f4a2ebfe592b1fc2c80bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170200.183 558114.094 170201.337 558111.947 170201.578 558112.007 170201.836 558114.413 170200.183 558114.094</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1fc2b8a8-3442-82bc-61ec-177ade4eeaed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e9106dee1ca34ce79491639a2ef65c39</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170198.676 558109.223 170197.896 558113.652 170200.183 558114.094 170201.836 558114.413 170204.155 558114.861 170205.245 558115.182 170210.396 558116.228 170211.542 558116.436 170211.332 558117.482 170196.520 558114.703 170197.465 558109.010 170198.676 558109.223</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc86b9e30-76ea-b77d-ea44-5cc83b57de16">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.74094634e90445d2beb57d878e9f4985</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170204.155 558114.861 170206.361 558103.106 170207.410 558103.357 170205.245 558115.182 170204.155 558114.861</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b40e6b90d-312e-d852-b804-7ce7c23b1960">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f90e6baf6cdc4750a7c1582ce7ba69a6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170210.396 558116.228 170212.503 558104.805 170213.816 558105.093 170211.542 558116.436 170210.396 558116.228</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba2d66821-6e27-2863-ee53-a30f4c5cf22d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-23</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-23T16:10:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.e0ac97e852994c47bdbf151cedf37aa3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170458.921 558012.727 170458.921 558018.535</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b243fb7a0-be7a-e467-b535-08323dc8ba05">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ccb23cd43a144387a28a4a121a0d046e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170507.727 558187.613 170515.033 558188.824 170514.852 558189.928 170507.622 558188.423 170507.727 558187.613</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd7bf27ad-c346-f029-7a07-8a765bff10bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-11-14</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-11-14T08:44:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.473dea8144c9444bb624b98ff8f9b0ee</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170822.813 558174.356 170813.842 558178.331 170803.781 558182.793 170788.781 558189.499 170768.186 558199.865 170764.410 558201.765 170758.806 558206.071 170756.092 558202.622 170761.987 558198.200 170763.558 558200.154 170779.899 558191.856 170803.160 558181.154 170822.129 558172.759 170822.813 558174.356</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba4125a16-06cc-8528-01e8-7bdd442f5be0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-03-01T14:36:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.1961313f6c67439c8cd1a71eaf2af5b7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170773.763 559060.435 170774.414 559061.196 170775.762 559062.773 170776.648 559063.810 170777.298 559064.570</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1daeffae-8d01-97b9-b9ba-f24ac2aec3d5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-03</creationDate>
            <imgeo:LV-publicatiedatum>2024-07-09T15:13:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-07-03T16:24:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.679ecb0235ad4d2ea601c5be0dbb5748</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170994.059 558456.570 171000.639 558464.241 170998.606 558465.992 170983.828 558448.955 170985.900 558447.060 170992.423 558454.664 170997.903 558449.922 170996.685 558447.664 170997.015 558447.367 170999.070 558448.911 171003.958 558444.682 171002.760 558442.450 171003.083 558442.179 171005.090 558443.703 171009.975 558439.475 171008.802 558437.160 171009.099 558436.912 171011.165 558438.445 171016.035 558434.231 171014.832 558431.987 171015.162 558431.723 171017.177 558433.243 171023.120 558428.100 171023.400 558428.410 171024.809 558430.074 171018.886 558435.177 171020.038 558437.349 171019.703 558437.617 171017.784 558436.127 171012.811 558440.412 171014.030 558442.614 171013.657 558442.882 171011.685 558441.382 171006.762 558445.625 171007.909 558447.813 171007.579 558448.061 171005.603 558446.623 171000.703 558450.845 171001.883 558453.011 171001.544 558453.324 170999.588 558451.806 170994.059 558456.570</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b743d567a-fe77-9d05-9114-108f55dedc98">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-07-09T15:13:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-07-03T16:24:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.29baef5659a04722ae00dbf3d9f864a3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171005.490 558407.730 171000.000 558412.490 170979.150 558430.560 170980.955 558432.748 170979.726 558433.775 170980.349 558434.470 170979.127 558435.552 170975.513 558431.675 171000.000 558410.610 171004.520 558406.700 171005.490 558407.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b86aa5cc0-c647-899b-5010-43a7255e24ac">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-07-03T16:24:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.29baef5659a04722ae00dbf3d9f864a3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171005.490 558407.730 171000.000 558412.490 170979.150 558430.560 170983.840 558436.170 170984.330 558436.570 170988.970 558442.210 170994.570 558437.210 170995.570 558438.150 170988.890 558444.240 170977.180 558430.400 171000.000 558410.610 171004.520 558406.700 171005.490 558407.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba9b7c877-9ad3-919a-dfcb-56a965b377e2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.57511c5a2f8a4410b162fca813828803</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170962.867 558410.530 170964.259 558409.279 170965.020 558410.169 170963.535 558411.510 170962.867 558410.530</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc6846db1-e84e-058c-6f50-517fb76962df">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.69e1f86914a448f49e4c2e65d67089b3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170963.535 558411.510 170948.410 558425.169 170962.639 558441.929 170961.669 558442.749 170945.270 558423.519 170946.229 558422.710 170947.580 558424.270 170962.867 558410.530 170963.535 558411.510</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b93da99ca-4c77-87e6-f454-ea3ade26be72">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.31130a69e31c42ef80de890c74688ac1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170912.270 558384.610 170902.470 558363.040 170910.145 558355.342 170911.088 558356.192 170905.300 558362.000 170903.971 558363.334 170904.600 558364.730 170908.817 558374.082 170913.240 558383.890 170913.417 558384.093 170912.270 558384.610</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bad692f8c-fbfc-f120-572c-f872c53c12ca">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cf1c176523d5401689a010b4e9926c09</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170942.940 558420.560 170912.270 558384.610 170913.417 558384.093 170914.080 558384.850 170917.853 558389.286 170922.338 558394.560 170931.849 558405.744 170943.820 558419.820 170942.940 558420.560</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdb99880c-bc0d-b925-4f95-33a13385879a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.908db65fac7c43fc85cf2d417d00bae6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170935.264 558304.076 170935.800 558303.588 170935.637 558303.447 170937.605 558301.150 170929.886 558294.341 170930.305 558291.164 170930.729 558291.223 170930.511 558293.363 170930.433 558294.128 170931.850 558295.385 170938.264 558301.076 170935.571 558304.345 170935.264 558304.076</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be0d55be1-ad12-199a-3ed4-777de51cc437">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.edb4651a1a8a4c2a8098bb38fd890ee5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170942.840 558266.990 170922.560 558263.980 170922.720 558262.830 170942.930 558265.830 170958.120 558268.110 170957.970 558269.260 170942.840 558266.990</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0814438a-c77a-e7d1-b326-6a5df085cf6a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1b05963781d8433d8f8f8179559142c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170927.785 558216.966 170928.174 558215.800 170928.870 558213.710 170932.354 558214.871 170932.833 558215.031 170927.785 558216.966</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8fe7aa54-1d05-d070-c593-3430c97e55e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.83ebae6d57bc4d0bbe8783b3c685d5f4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170916.283 558306.179 170913.210 558303.518 170913.590 558303.099 170917.331 558306.252 170919.138 558304.085 170915.370 558300.868 170915.736 558300.411 170920.687 558304.625 170922.488 558302.569 170922.453 558302.319 170918.589 558298.917 170918.978 558298.460 170922.851 558301.851 170923.088 558301.872 170924.229 558302.869 170925.941 558300.763 170921.210 558296.738 170921.601 558296.293 170927.211 558301.049 170929.635 558298.199 170935.637 558303.447 170935.800 558303.588 170935.330 558304.133 170935.264 558304.076 170931.166 558300.543 170928.999 558303.057 170927.861 558302.076 170925.491 558304.826 170924.432 558303.913 170922.266 558306.469 170921.084 558305.467 170918.726 558308.249 170918.421 558307.991 170916.283 558306.179</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8724df8a-d962-920c-d6e2-60f2851a6f2e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f874f9c7a61947239de20568c844e404</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170930.462 558289.826 170930.305 558291.164 170923.095 558290.160 170915.910 558289.096 170916.100 558287.810 170923.260 558288.870 170930.462 558289.826</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd14bcf95-e8e5-cc16-a6e2-3004a6010f65">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9347a5e2aa8a4c37abcfa918b024b8d3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171262.788 558773.320 171267.598 558771.395 171268.069 558772.572 171263.461 558774.416 171262.788 558773.320</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbd29633c-ff37-b87f-af63-edc69ccbc6a3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.23d0e17a53104d1cbecf8bbe7710fb86</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171263.461 558774.416 171257.961 558776.616 171257.032 558776.988 171257.820 558778.956 171254.823 558828.598 171253.482 558828.582 171256.444 558779.512 171238.093 558733.648 171239.470 558733.097 171256.561 558775.811 171262.788 558773.320 171263.461 558774.416</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b213b8a8a-d700-aef5-3d58-22025a718662">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-10-27</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-22</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-03-22T12:13:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-10-27T13:44:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.a552ef3873124c5f89ce2c514eaab83b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171239.883 558668.909 171242.553 558668.038 171243.259 558670.201 171240.568 558671.009 171239.883 558668.909</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b934cdd64-5e12-3513-f004-c2c98f5e033b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-10-27</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-03-22</terminationDate>
            <imgeo:LV-publicatiedatum>2018-06-14T14:27:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-03-22T12:13:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-10-27T13:44:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.a552ef3873124c5f89ce2c514eaab83b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171239.883 558668.909 171242.553 558668.038 171243.259 558670.201 171240.568 558671.009 171239.883 558668.909</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf7f75238-0fe5-db6b-e2d1-9098c3875e2a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-06-08T13:15:21</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T15:38:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.0148ebb896194086932da8ae853fac30</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171143.999 558567.738 171146.547 558566.732</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b99ac52f8-c5cb-71e8-993d-ff169306fc6d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-27T23:36:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-06-08T13:15:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.0148ebb896194086932da8ae853fac30</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171143.999 558567.738 171144.929 558567.371 171145.618 558567.099 171146.547 558566.732</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b128951a2-45bd-fce2-22ed-b16e49819043">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.01a190ff05c54cd49e78a942f32114a5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171094.125 558527.299 171094.736 558511.679 171097.274 558511.778 171097.022 558518.209 171102.635 558518.429 171102.583 558519.759 171096.970 558519.540 171096.662 558527.398 171094.125 558527.299</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b893054c0-f971-dd63-0c60-b95c57d24c7d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-10T14:14:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.4de7d627479f420eadc8d33e1e01b6d5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171131.780 558438.736 171132.207 558439.354 171133.184 558440.769 171133.612 558441.389</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2b13b764-3ef6-f059-4717-953069560ecc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-07-03T16:24:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.af3da2fc49f74bf48f0fd67575d1b6c0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171012.870 558416.340 171004.795 558423.359 171003.710 558422.111 171011.794 558415.085 171012.870 558416.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba41c8dda-2ddc-f5bb-d53b-95df53d47d74">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-03</terminationDate>
            <imgeo:LV-publicatiedatum>2024-07-09T15:13:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-07-03T16:24:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.af3da2fc49f74bf48f0fd67575d1b6c0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171012.870 558416.340 171004.795 558423.359 171003.710 558422.111 171011.794 558415.085 171012.870 558416.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b00904d1f-1dc4-72d5-4046-ba0991b0ec46">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-03</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-07-03T16:24:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.26c8dc6b54ec4b4c850f84734bb72bdf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171034.543 558441.275 171033.014 558442.596 171006.870 558464.840 171000.000 558456.990 170995.786 558452.169 170996.780 558451.300 171000.000 558454.950 171001.680 558456.860 171002.120 558457.230 171006.910 558462.840 171033.430 558440.040 171034.543 558441.275</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4102445e-7fb5-7f13-9278-0586975945dc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-07-03</terminationDate>
            <imgeo:LV-publicatiedatum>2024-07-09T15:13:13</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-07-03T16:24:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.26c8dc6b54ec4b4c850f84734bb72bdf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171034.543 558441.275 171033.014 558442.596 171006.870 558464.840 171000.000 558456.990 170995.786 558452.169 170996.780 558451.300 171000.000 558454.950 171001.680 558456.860 171002.120 558457.230 171006.910 558462.840 171033.430 558440.040 171034.543 558441.275</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd4563348-2cef-04ec-b069-336d8c186d84">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-08-28T08:55:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-09T12:08:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ceb2cba8029e40aa9aa8b141601816a8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171014.336 558415.973 171034.576 558439.300 171045.719 558429.761 171049.049 558426.910 171043.059 558419.590 171049.860 558413.520 171051.330 558412.310 171058.110 558406.360 171059.149 558407.551 171045.146 558419.765 171051.140 558426.941 171042.207 558434.657 171034.543 558441.275 171033.430 558440.040 171029.398 558435.446 171028.586 558434.520 171028.270 558434.160 171023.400 558428.410 171023.030 558428.000 171018.350 558422.570 171017.980 558422.210 171013.180 558416.680 171012.870 558416.340 171011.794 558415.085 171005.490 558407.730 171004.520 558406.700 171003.372 558405.389 171004.330 558404.440 171014.336 558415.973</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b317654e8-00d6-8085-3142-7c6316a3c064">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2018-08-28</terminationDate>
            <imgeo:LV-publicatiedatum>2019-02-22T10:03:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2018-08-28T08:55:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-09T12:08:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ceb2cba8029e40aa9aa8b141601816a8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171014.336 558415.973 171034.576 558439.300 171045.719 558429.761 171049.049 558426.910 171043.059 558419.590 171049.860 558413.520 171051.330 558412.310 171058.110 558406.360 171059.149 558407.551 171045.146 558419.765 171051.140 558426.941 171042.207 558434.657 171034.543 558441.275 171033.430 558440.040 171029.398 558435.446 171028.586 558434.520 171028.270 558434.160 171023.400 558428.410 171023.030 558428.000 171018.350 558422.570 171017.980 558422.210 171013.180 558416.680 171012.870 558416.340 171011.794 558415.085 171005.490 558407.730 171004.520 558406.700 171003.372 558405.389 171004.330 558404.440 171014.336 558415.973</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b30739963-473f-2940-8761-efd89bb48668">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-09</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-09T13:12:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5210d246df6b4d269b0f3bb5391d538f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171046.925 558628.256 171047.843 558630.188 171045.852 558631.346 171043.172 558632.905 171041.766 558633.486 171040.399 558634.050 171041.398 558636.861 171043.734 558643.436 171045.357 558648.003 171014.937 558685.514 171013.371 558684.179 171018.546 558677.454 171042.813 558647.419 171036.488 558629.176 171035.957 558627.284 171037.706 558626.175 171039.696 558631.899 171042.388 558630.954 171046.925 558628.256</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4adbcb4f-1e5f-1645-8cb7-1dde44704e8c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cd7afac8728c45b88243a35fdfb4c31c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171036.488 558629.176 171035.339 558629.084 171016.383 558641.071 171014.816 558646.404 171013.691 558646.163 171015.237 558640.254 171019.793 558637.138 171031.291 558630.242 171035.957 558627.284 171036.488 558629.176</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b88051819-75e5-4377-ecb6-db22452e1a6b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-10-27T13:48:47.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.f4fd513932ad4755a47cedd93679ba26</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171059.763 558707.925 171058.555 558706.323 171060.144 558705.114 171061.350 558706.722 171059.763 558707.925</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b36a2bbf1-645d-d8a3-b866-b326f6a051f4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.aa555cf9ba294562b6bc55cbd320f7c6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171046.925 558628.256 171048.235 558627.476 171049.360 558629.306 171047.843 558630.188 171046.925 558628.256</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b835dc774-81f3-b6b1-cf50-c71930ae3727">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-03-01T14:18:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.02b900e97eff4885b942e8a01007e830</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171214.515 559433.098 171217.386 559436.890 171217.947 559437.632 171218.552 559438.431</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b796508ed-a581-4cc7-3f35-ee9e1cfb3d88">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T12:59:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.9d837d05926b4e53b5a0e1c399370d6c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171279.451 559769.145 171281.346 559762.581</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b86e626a0-2ddd-58f1-a35e-8e9e88097c6a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-10-27</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-10-27T14:12:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.86af6b7ff48d43fc9b1fdfa905478c64</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171706.319 559117.889 171707.978 559115.538 171709.568 559116.990 171707.978 559119.064 171706.319 559117.889</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0c81465a-8c8a-1f10-84f3-7d421ec7cc18">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T13:44:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.7079185f62c14f73b1ccd241f6aca7b5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171536.482 559988.719 171533.719 559991.618</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1bf36de3-bb9c-bbbc-0668-8d18bcb3c4f6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:12:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.a6965d2e76fe4d93980e3ad4934e128c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171533.719 559991.618 171536.482 559988.719</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba0087ee8-0e25-d48e-f21a-046e7ba08a36">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-06-14T11:08:00</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:12:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.a6965d2e76fe4d93980e3ad4934e128c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171533.719 559991.618 171536.482 559988.719</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b47bb463a-c3d0-d4bb-43c1-92d8d3e3c9d8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T13:39:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.addec5474acf4f45a25b20d02142aea0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171580.260 559939.547 171582.780 559942.015</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1490d3b5-16c6-3e9e-a6cd-f7221d2bd13e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T09:14:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.d1cb35ac1dce458f9c784331ede7fe47</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171568.583 559990.633 171568.574 559984.798</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be312ec3b-220b-e330-2290-ec7137fbe934">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-10T13:41:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.1d47b7c27de544f0a144ab8fb77b3c4f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171568.583 559990.633 171568.574 559984.798</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b279a5f27-4095-c6f7-b7de-f2614ef335fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-06-14T11:08:00</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-10T13:41:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.1d47b7c27de544f0a144ab8fb77b3c4f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171568.583 559990.633 171568.574 559984.798</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="baa02d268-69e5-660e-8dd9-0c4176da263c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T13:43:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.b55f965c53ca442a95231e0da05d4c88</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171557.981 559968.556 171554.476 559965.655</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b109a8006-b4e2-3af3-445b-41c6d5d29df6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.42536af5a60a4adb8e9575b6fcec7d5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171984.042 559696.899 171983.798 559696.681 171984.655 559694.914 171985.334 559695.515 171984.042 559696.899</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4155ebe0-8a1d-0da4-b5d0-04502d77b602">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7f80cd4ebc814ba4a47f91f8a7ccdad2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171981.371 559694.515 171982.615 559693.106 171983.210 559693.634 171981.580 559694.701 171981.371 559694.515</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfdca0910-b317-2485-e449-8d5104342692">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.71d3436a54dc48f58131c26f110f7210</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171984.963 559698.638 171984.649 559698.961 171979.457 559694.075 171979.792 559693.724 171984.963 559698.638</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4f328a1b-4288-2247-110c-d7d3dfb516dd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5480a441242046ada4fd50ef74d2cd5e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171838.317 559740.599 171839.328 559742.002 171822.543 559759.048 171820.331 559761.294 171819.116 559760.098 171821.525 559757.652 171838.317 559740.599</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8407a982-c82e-12e4-df12-17a4d03bf015">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5275d68aba5d4b97a34999b328929539</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171840.800 559738.078 171832.892 559727.090 171834.347 559726.042 171843.086 559738.186 171839.328 559742.002 171838.317 559740.599 171840.800 559738.078</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfbfad64b-24cf-c72c-c118-710f4fc77153">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-10-27</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-10-27T13:40:40.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.8d85577c25dd4277bb85c738d359a36a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171591.341 558031.813 171590.235 558031.488 171590.544 558030.457 171591.706 558030.789 171592.348 558030.973 171591.987 558032.004 171591.341 558031.813</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">gemaal</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b054a56e3-5b76-0559-889b-8ec852889b39">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-07-08</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-17T15:14:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-07-08T13:39:18</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-11-02T14:33:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.91ca01bf6b554d6d992b0b8089079563</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170692.971 559371.337 170693.406 559372.268 170694.078 559373.706 170694.538 559374.691</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4c104114-8bc1-d62d-d194-e28e723f22cc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-07-08</terminationDate>
            <imgeo:LV-publicatiedatum>2026-07-15T09:06:46</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-07-08T13:39:18</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-11-02T14:33:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.91ca01bf6b554d6d992b0b8089079563</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170692.971 559371.337 170693.406 559372.268 170694.078 559373.706 170694.538 559374.691</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b57ae7dd1-9039-6a46-e9f0-0a5035832e99">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-06-11T02:09:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-22T15:58:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.34ced3c71a8f42b98dab2d10c2939b75</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172270.928 558266.235 172277.477 558267.083</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b47c38c3f-aab5-e527-5bd8-454e30098163">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0011334d1430483f88f029f7978fb799</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173151.836 558789.187 173157.824 558781.271 173158.613 558781.870 173152.643 558789.745 173151.836 558789.187</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bddf43aa6-ac28-7276-cf38-f457337b6084">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.026ef508ed374552a77cde6a52b6c541</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173034.049 558825.123 173031.153 558824.963 173033.608 558818.756 173035.755 558819.767 173037.511 558820.493 173035.582 558825.160 173034.049 558825.123</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b60d16ed0-5aac-50dc-9bb6-a36f5f58bbec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2c329ec79ab940e7ad8b98392d9ffc21</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173067.428 558808.096 173067.857 558806.624 173068.720 558803.680 173074.403 558808.078 173073.041 558809.988 173072.596 558809.648 173071.443 558811.159 173067.428 558808.096</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4c30ee77-968b-3739-6e7c-8b058b7bd015">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.330eb017446841b68e5e2968ad920cdd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173116.617 558807.891 173106.764 558807.502 173106.797 558806.715 173116.494 558807.014 173116.617 558807.891</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6096c0cd-6f6a-f6f6-c54e-06ca582b8ca3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4dc65c192b7b477f9f302bf5ac271b8f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173042.702 558851.563 173039.327 558847.208 173037.833 558845.521 173039.421 558844.197 173039.815 558844.663 173041.266 558843.437 173044.525 558847.294 173043.801 558848.619 173044.187 558848.830 173042.878 558851.239 173042.702 558851.563</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0a8d5af3-a69d-4de9-9c7c-f35b08cffe0f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5824bf12c05546029104c96a12c4fb92</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173063.910 558802.667 173064.706 558800.437 173066.253 558801.223 173065.791 558803.269 173063.910 558802.667</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b89f6dc68-53a9-e00f-af37-c2ab7aaf0699">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8fd20b6f48c84f7eb834cebfc08fde2a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173346.598 558744.691 173340.496 558741.957 173340.804 558740.971 173347.403 558742.620 173346.598 558744.691</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6471e9b2-822c-573b-86a6-7c0622ca1aa9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-18</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:36:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.915505258ef54e98b6d25efc3609e527</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173256.103 559143.151 173255.574 559141.547 173256.517 559141.244 173257.123 559143.097 173256.103 559143.151</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0f599b0b-37ea-6f5e-e895-33bcc580f020">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bb38d4f0dfca4584b5456e30e0d93495</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173077.194 558809.017 173078.748 558807.191 173082.915 558813.593 173080.602 558814.948 173077.194 558809.017</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3f2b89ef-186a-f0df-a369-8a85381ae41c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c1350e5d5be64f8b87cb06679564cd40</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173357.087 558730.533 173354.070 558724.568 173355.004 558724.011 173359.017 558729.432 173357.087 558730.533</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf9afd830-963f-316f-67de-1ae2e4210fec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c9ceb66ba5c440d3b88ed01487331688</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173121.990 558793.108 173114.895 558786.245 173115.582 558785.527 173122.633 558792.382 173121.990 558793.108</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3c9cdf85-b714-2619-ad72-8aefc560a2b3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:53:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d4242b7a72d44be4b04565fdc72d211b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173004.592 558767.536 173008.003 558769.936 173007.465 558770.744 173003.542 558768.099 173001.473 558766.518 173002.250 558765.887 173004.592 558767.536</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdff79289-8f17-571e-7630-ed9312ffe415">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d55777a1cd2a4c5494ef74ec507260e2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173117.959 558800.266 173108.837 558796.296 173109.239 558795.400 173118.285 558799.312 173117.959 558800.266</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba0f25289-22b9-9439-1c32-46a36751064f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ded6b76b23104cbe809eae2bf72d0788</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173279.326 558745.577 173275.506 558736.230 173276.325 558735.905 173280.072 558745.137 173279.326 558745.577</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b329653fc-6ee2-6d56-a959-4eac85aad6da">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.edba82f95a364c59ae41e949b869c707</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173144.382 558785.810 173147.131 558776.370 173148.087 558776.643 173145.278 558786.103 173144.382 558785.810</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4e5dc3b9-dc6f-4495-ed9c-3d61b2d8513c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f23479395cd64caebd6cbdc479b26e41</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173128.340 558787.961 173124.178 558778.960 173125.072 558778.557 173129.263 558787.502 173128.340 558787.961</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcb2b4200-d196-4574-299d-b7773bbffe62">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f259654bfb3e48c3bbf1a0864e1ff3ab</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173037.971 558842.481 173035.724 558844.182 173033.906 558839.261 173031.759 558833.588 173031.828 558829.875 173031.884 558828.164 173033.971 558828.393 173035.870 558828.438 173035.751 558833.486 173034.323 558833.973 173035.378 558837.068 173037.176 558836.455 173038.805 558841.235 173037.704 558842.165 173037.846 558842.333 173037.971 558842.481</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdfb1530b-2ca0-8b14-7c61-dddbea9fff24">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fe7519281807478ca5842c9fad4b87d1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173287.260 558743.496 173287.162 558733.427 173288.062 558733.410 173288.150 558743.564 173287.260 558743.496</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2e29ab4a-4824-46bf-d9d9-96323e1941c6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.05d659a35b8c460485dc784cb2b916ce</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173033.906 558839.261 173031.218 558839.949 173030.087 558835.531 173027.338 558835.501 173027.200 558833.503 173031.759 558833.588 173033.906 558839.261</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b97e76e7f-fa7d-d44d-2a5f-fdf28a970bcd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.06ccbc622e15499582e7aa2cdf17d7f3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173037.004 558816.745 173035.988 558816.262 173040.129 558811.957 173040.533 558812.365 173041.914 558813.670 173038.446 558817.341 173037.004 558816.745</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2dc9d58e-94c9-3a71-1cb1-3d45a2f187b1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.101b5f5873a44858beeca98064c2b4b1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173074.249 558812.872 173075.196 558811.631 173075.059 558811.526 173077.194 558809.017 173080.602 558814.948 173078.523 558816.166 173076.907 558817.166 173074.249 558812.872</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6712a0e3-fbcc-b9b4-14cd-d68021082f2b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.15163f6996fe48229bb6d853fdc1c6d0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173543.661 559988.436 173549.658 559990.517 173551.117 559988.223 173551.360 559988.313 173551.117 559990.962 173556.519 559992.854 173557.957 559990.525 173558.222 559990.639 173558.076 559993.231 173563.493 559995.020 173564.754 559992.955 173564.993 559993.043 173564.847 559995.525 173571.168 559997.552 173573.896 559989.335 173575.031 559989.876 173569.169 560007.471 173567.980 560007.065 173570.581 559998.822 173564.546 559996.814 173563.172 559998.952 173562.923 559998.866 173563.267 559996.291 173557.540 559994.507 173556.406 559996.669 173555.892 559996.507 173556.216 559993.967 173550.679 559992.156 173549.316 559994.350 173549.037 559994.181 173549.307 559991.667 173543.257 559989.613 173543.661 559988.436</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b73371894-aeb7-4579-27c1-63cfb16c6a97">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1d3adb0f228c44bdb19a93a4bcc7f5bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173051.249 558807.072 173050.695 558805.871 173049.491 558802.983 173054.170 558802.746 173056.219 558802.616 173056.393 558804.813 173055.971 558804.842 173056.102 558806.738 173051.249 558807.072</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5d0f594b-8eb8-7a97-61c0-f4ec9042e65f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2ef40915ba1a4c72a60f811dbfd4239d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173031.828 558829.875 173026.144 558829.769 173026.161 558828.821 173029.431 558828.882 173030.912 558828.057 173031.884 558828.164 173031.828 558829.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcf4b5dee-8937-c81f-9c2f-55bb7da369c5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:08:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.300aec986805444f987a11d482b4742c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173098.448 558819.058 173097.676 558819.280 173097.466 558818.580 173097.341 558818.161 173088.195 558820.739 173087.772 558819.289 173106.948 558813.860 173107.393 558815.326 173098.122 558817.946 173098.204 558818.225 173098.448 558819.058</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5fff8ad8-5540-41c8-e9f5-b8cba3d4cb17">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.312757bc9c0045cb9d68b92e9d13dca4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173035.988 558816.262 173034.496 558815.552 173038.081 558812.007 173036.191 558810.096 173037.252 558809.047 173040.129 558811.957 173035.988 558816.262</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b9c183f98-f02b-c661-6017-e77de5a0661b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:36:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.31d03284952341ee8179b4fb56a68e79</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173257.360 559153.550 173256.964 559154.947 173256.028 559154.656 173256.384 559153.398 173257.360 559153.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc3d03815-9328-aaef-ccc6-b0e00f5ec778">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3acbbf33ac5b495c9efb0307a628dd73</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173136.165 558785.398 173135.463 558775.573 173136.399 558775.495 173137.142 558785.304 173136.165 558785.398</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5343d8ab-349d-56d7-493f-6b56878127d6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-18</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:02:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3ad1d2bb6a5f47e3a68e1969af535828</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173441.607 558740.448 173441.427 558741.148 173440.455 558740.715 173440.616 558740.187 173441.607 558740.448</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b105ca305-a5b4-f5a1-fc9f-6a6a7917017d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.41fd8f8d516a4ea78002b1c130671dc7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173295.461 558744.630 173299.246 558735.267 173300.040 558735.595 173296.257 558744.976 173295.461 558744.630</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc6a239df-cc03-8ba2-8f9e-750ff3ec7078">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.46416f0509ed4dda8ee02f772ae274a9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173059.337 558806.122 173059.234 558804.617 173059.234 558801.414 173063.910 558802.667 173065.791 558803.269 173065.208 558805.853 173064.717 558805.710 173064.186 558807.534 173059.337 558806.122</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b17823079-3dc2-f341-8c00-273813dc963f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4a1510ef701b43e38fde062f3047acaa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173031.153 558824.963 173030.612 558824.933 173028.228 558823.923 173030.251 558819.147 173030.706 558819.361 173031.466 558817.748 173033.608 558818.756 173031.153 558824.963</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba0dc41c7-7c2c-a3a0-9078-87fb88a432ef">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.57cd8ab4183d466c8999675bd8e97ff5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173268.069 558757.272 173258.841 558753.118 173259.184 558752.334 173268.412 558756.445 173268.069 558757.272</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd286771d-a0a0-41cc-93a8-305320cb29fb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6899c3989ae049dab8d6a0c571037ccf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173042.075 558809.254 173040.819 558807.942 173045.189 558806.000 173043.951 558803.617 173045.809 558802.652 173047.516 558806.739 173042.075 558809.254</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b59554e3f-6721-7688-5748-98723add7bd0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6a85c4a6908d42209620163b74bb40e0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173307.835 558754.386 173316.917 558749.993 173317.281 558750.781 173308.236 558755.190 173307.835 558754.386</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4289ddc9-4d32-5825-cdf7-3a20a9391f05">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.72cf14796a884033b00a9c500eb2466f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173068.720 558803.680 173069.467 558801.130 173075.971 558805.880 173074.403 558808.078 173068.720 558803.680</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc61ae755-2ed6-73ab-86ee-87075cc5d2ea">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:08:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.75b331cb29ab45c2b2a7b5a0f9f1c0a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173098.555 558822.395 173097.676 558819.280 173098.448 558819.058 173099.346 558822.127 173098.555 558822.395</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba6c6e561-f841-c27b-61eb-2221b0613239">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.80b21a3054e5408b9e3b0b62a2b505ba</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173374.204 558726.352 173375.855 558719.905 173376.866 558720.056 173376.388 558726.746 173374.204 558726.352</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf65b22c4-bf02-45d0-5326-4d964ce280cf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-11T14:58:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.98693c4c929d4663a7023ad5948a5d1d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172479.636 559241.721 172479.485 559241.910 172477.674 559244.171 172475.849 559242.709 172473.020 559246.241 172471.512 559245.029 172474.194 559241.538 172470.570 559238.790 172472.118 559236.704 172472.500 559236.190 172472.716 559236.123 172476.142 559238.706 172477.785 559240.021 172479.742 559241.588 172479.636 559241.721</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6f626d0f-fdad-87dc-597f-10c6932b730d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9da5bb3cd975430db0e4ae2e73448981</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173272.636 558750.436 173265.636 558743.143 173266.246 558742.513 173273.228 558749.788 173272.636 558750.436</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b73fdac89-0f1a-6cc6-62fe-5b86ad4a830b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a0b3fc5b97b34cd081359555fe57fd9e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173157.542 558794.723 173165.717 558789.361 173166.156 558789.997 173158.042 558795.377 173157.542 558794.723</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3894b4da-f15c-cff6-7a07-f76fdb27f583">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a2b9bf5817ea49879f680943119c790d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173042.778 558809.988 173042.075 558809.254 173047.516 558806.739 173047.726 558807.241 173048.521 558808.966 173043.936 558811.082 173042.778 558809.988</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcb0ab438-f4f7-83dd-dc06-aa08b3d97133">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b41c52cad0144fc29891111aeafb4a47</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173302.722 558748.443 173309.694 558741.164 173310.330 558741.763 173303.411 558749.057 173302.722 558748.443</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b9780f73c-9f21-acdd-562a-4ee7daca02e8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c724a70ed10c4f4c94da52db0a815397</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173039.327 558847.208 173037.125 558849.045 173035.682 558847.316 173037.833 558845.521 173039.327 558847.208</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3a344595-59c9-c2ac-000b-885bc5f29abd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cf2d4f178c5741bd892105197dcea4ee</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173054.170 558802.746 173054.021 558800.185 173056.014 558800.036 173056.219 558802.616 173054.170 558802.746</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b50bd03fe-ec42-52e7-9820-1d19f5df187a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:11:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d32bebc452c74785bf7af13085ab6257</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173100.920 558996.941 173101.451 558998.421 173098.216 558999.482 173102.325 559011.962 173100.921 559012.396 173096.815 559000.000 173092.035 558985.567 173093.785 558986.053 173097.759 558998.028 173100.920 558996.941</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4351d067-4f46-234f-ede1-5e38f121df12">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:36:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d68fba128d2246459e8e90ff3ca5265b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173256.103 559143.151 173257.123 559143.097 173257.472 559144.165 173258.052 559145.940 173258.418 559147.059 173258.910 559147.014 173259.090 559148.957 173258.636 559149.057 173257.628 559152.607 173257.360 559153.550 173256.384 559153.398 173256.567 559152.753 173257.588 559149.146 173257.144 559149.154 173256.970 559147.231 173257.422 559147.147 173256.491 559144.326 173256.103 559143.151</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd5b346c4-e05e-30c0-0bc5-03fb6b7813f0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d8d8914f9289408d9af3ca6494d64917</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173390.002 558734.214 173395.410 558730.342 173396.098 558731.129 173391.415 558735.948 173390.002 558734.214</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b78eebfde-c24d-a3f1-cc1d-45891b757c5b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:00:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.da3cf08d513d41e8957c6d1380f21248</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173441.607 558740.448 173440.616 558740.187 173441.597 558736.971 173441.909 558735.952 173432.329 558733.493 173432.704 558732.031 173452.474 558737.106 173452.456 558737.178 173452.558 558737.205 173452.173 558738.628 173452.088 558738.612 173442.706 558736.204 173442.434 558737.225 173441.607 558740.448</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc83659ec-86d3-b361-65b7-35e3419e97a7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T09:53:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e4499d5412414d43b808a8f127a519e3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173001.473 558766.518 173000.808 558766.038 173001.353 558765.256 173002.250 558765.887 173001.473 558766.518</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7ad513c0-a1be-1867-0c80-5b653fc7f608">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e77ab679b0cc492f9498126942fcd2cb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172476.142 559238.706 172477.458 559237.063 172479.100 559238.378 172477.785 559240.021 172476.142 559238.706</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc7521f18-2166-ab42-d6a5-5566e61fce05">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fa704ec99685420699d62e55e1d90451</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173266.296 558764.936 173256.197 558764.533 173256.234 558763.645 173266.335 558764.068 173266.296 558764.936</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba7624a19-ce47-75b1-dd97-75a07020e85e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T09:23:10.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.2f0c116816ca4b53a4783a513a0ffa6e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172293.348 558607.430 172294.556 558602.903</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5c4f90fc-bc25-a99f-8376-a873d154dda3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T15:46:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.7f4d8baaa9cf43e99b790be4bba4211c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172938.099 558768.701 172931.328 558769.376 172930.640 558769.443</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bae223700-3d28-3951-019f-8d931faaa32d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T11:29:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.87f3e68ef5be4b448d3e36427129f92e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172143.197 558725.904 172141.721 558731.806</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6e0d30ca-86fe-3e16-47c1-0d927d873a89">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T11:15:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.a04a68e95a15430aa7df75e2fd1772c0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172342.867 558406.652 172343.703 558402.534</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd3035c61-4b81-855b-9a6a-d764245d4445">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-10T11:18:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.bb1fb80ddc98468e9263006bd062e723</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172328.514 558486.378 172329.637 558480.988</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcbf80e76-f520-9b2e-1121-a66992912c33">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T09:20:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.fec70cbb28a04450b8cf16a92c02dc16</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172000.960 558938.725 172004.358 558934.792</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bee2c6a6d-7e61-477a-2a9c-e29142e036d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.02c1f6e3ca12476e9e89c10531b59f8d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173872.110 558782.000 173870.151 558781.544 173870.205 558781.114 173872.494 558772.419 173874.407 558772.923 173872.110 558782.000</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8e327e32-b67c-6c0f-b001-a274d517a0da">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.096c7384580d4718a299aa38022daa2f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173961.553 559389.947 173959.877 559388.808 173962.804 559386.463 173964.028 559387.191 173963.353 559390.919 173961.553 559389.947</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bebff0705-9b3f-e866-f29f-e7999a2c02f3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0dd6a6c865834a9bb2d3579a2b222c7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173942.202 558858.708 173944.735 558857.823 173944.848 558858.219 173942.333 558859.172 173942.202 558858.708</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b749e1ac6-9729-213e-aa0e-c713381a3c3c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0fba3651089441f8a5f001e69fd8c569</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173931.380 558650.861 173931.222 558658.311 173930.794 558658.306 173930.717 558650.868 173931.380 558650.861</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b12e30ce1-0f50-4e6f-d530-415ef1ae6fe0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.134a405832484671bc9abb9739585a81</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173974.158 558727.158 173976.351 558727.842 173974.652 558733.895 173974.494 558734.219 173972.228 558733.266 173974.158 558727.158</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b27828618-2d23-b7df-6202-a68cbdac721a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.14156cfb28d8485eb66b82d72f16d251</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173938.026 559350.133 173938.037 559348.136 173941.623 559349.225 173941.692 559350.666 173938.213 559352.128 173938.026 559350.133</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd5c4d839-7c76-1ce7-fe5f-2c5cf5799ae4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1bf07280a8c9409a911138cb8ba11b21</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173884.924 558897.779 173884.898 558897.801 173879.150 558902.682 173878.792 558902.224 173884.589 558897.417 173884.924 558897.779</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b99851735-331e-952f-d2cb-9fe8537ffc13">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1e32de08eec241c08347ea4573a2235a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173608.708 558703.982 173603.241 558700.784 173603.851 558699.505 173609.745 558701.902 173608.708 558703.982</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc02d1ede-6f3a-5f3a-4deb-7e68c239d62d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.21ac687b9e944185b4ff73ec006702a1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173836.492 558951.712 173842.658 558948.319 173842.880 558951.010 173842.882 558951.035 173836.492 558951.712</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be64b5036-8ee3-74da-c351-e53461ab8a09">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.229a87da0b0d4ad691cb645850398e59</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173877.661 558897.147 173875.848 558898.847 173875.586 558898.549 173873.162 558894.357 173873.242 558889.743 173877.661 558897.147</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf160f7a2-4df6-675e-1db2-bf4f026bf225">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.25231ff8d96d4b1eb6e7c21ca547c807</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173985.860 558955.410 173986.591 558952.811 173987.044 558952.947 173986.293 558955.552 173985.857 558955.419 173985.860 558955.410</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7cbea5a9-d603-5f1d-3c12-a59e6ac6a531">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T08:56:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.29794348c0ea44c1a1bbbc8e4080b3c4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173479.837 558713.679 173472.201 558716.084 173471.960 558715.423 173479.556 558713.030 173482.200 558712.198 173482.411 558712.868 173479.837 558713.679</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf93ba738-bc9a-ac44-51c6-1ad82a7c2c79">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2dec95e0b18a48cc8d72b7188b9945ef</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173613.899 558696.432 173607.845 558690.398 173608.218 558689.887 173612.048 558693.600 173614.493 558691.078 173616.899 558693.795 173613.899 558696.432</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4f8fda98-5a79-9dc0-4534-dab852c49184">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.366822cf6d72400d9711f2d02d658812</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173692.316 559982.978 173690.695 559984.940 173690.358 559984.722 173690.765 559982.268 173692.316 559982.978</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3b9e00cb-df32-c231-68d6-7fa33f04b017">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.36a107945048492396e40304ecef50d4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173713.841 559992.545 173712.271 559994.478 173712.007 559994.337 173712.351 559991.971 173713.841 559992.545</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7f743132-85e0-d8a1-d1e5-d53bb51f6da3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3b317915a64446bda09c214a0e86d5e5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173884.203 558742.665 173881.681 558741.964 173882.913 558737.811 173885.438 558738.560 173884.203 558742.665</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8c29751e-9a67-36b2-23e2-02e34e262182">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.44197d9da67346288d621adc3f888e03</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173862.680 558858.367 173860.202 558858.441 173860.194 558858.068 173862.663 558857.953 173862.680 558858.367</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba0d7409c-9ce9-a4b2-fb68-38a0e20ad89e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.442387b74f5e4ffcb101e6cb8c46550c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173663.659 559801.693 173662.021 559803.983 173658.003 559812.852 173657.610 559812.691 173661.568 559803.970 173662.114 559801.169 173663.659 559801.693</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b38c58d4c-9c39-cff7-cc80-2e114a6c3d55">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4772aea498ea49a5853c59a00690e33d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173637.093 559832.103 173637.217 559832.146 173638.947 559830.229 173643.716 559822.090 173644.287 559822.399 173641.756 559826.553 173643.547 559827.773 173650.739 559830.075 173650.523 559830.600 173650.215 559830.476 173643.253 559828.221 173640.907 559828.067 173639.317 559830.445 173638.673 559832.739 173637.093 559832.103</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bffde5609-8b98-1f31-31f5-af6bea2ab3d7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.49dbf0685b5e4bf69d9d46e599d40930</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173903.179 558660.862 173903.727 558660.519 173903.814 558660.658 173904.605 558661.919 173904.059 558662.265 173903.179 558660.862</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba919e842-1bdd-4dac-64a0-739a9d7a439a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4f9192a3fa6b4b7994a99b0c5fb2831d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173946.060 558794.795 173948.786 558795.560 173948.688 558795.978 173947.504 558801.072 173944.745 558800.454 173946.060 558794.795</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bb037772d-460d-7530-869d-738b63f3aaff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4fed60f68d8048c68857af67b07682d2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173867.876 558803.793 173865.807 558803.370 173865.421 558803.291 173865.478 558802.872 173865.904 558802.954 173867.795 558794.841 173869.814 558795.315 173867.876 558803.793</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b79b5de05-b990-ddf5-86ed-0d1f86aaf544">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.50742fb785784fdab518abd8e945cbaa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173875.680 558944.499 173875.427 558942.230 173875.962 558942.170 173876.215 558944.440 173875.680 558944.499</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1eb0cb91-75f8-b1af-c85e-0473d8f1baf0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.547b6218245f4affa86da26403ee7921</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173950.858 558778.958 173953.653 558779.757 173951.540 558785.519 173951.423 558785.923 173948.856 558785.168 173950.858 558778.958</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf151ab23-bafc-72f3-bf11-181adcad8f55">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5813cd30da88417cb0ce5ecd868a9ee8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173886.848 558692.938 173887.737 558693.157 173887.076 558695.840 173892.036 558696.489 173890.870 558705.392 173887.973 558705.013 173887.643 558708.241 173885.855 558708.154 173885.378 558708.130 173885.373 558707.957 173885.337 558706.768 173885.331 558706.316 173885.328 558706.064 173885.325 558705.842 173885.320 558705.406 173885.329 558704.043 173885.350 558703.643 173890.299 558704.244 173891.080 558697.387 173886.160 558696.842 173886.220 558696.446 173886.389 558695.270 173886.434 558695.021 173886.463 558694.860 173886.510 558694.597 173886.599 558694.100 173886.716 558693.553 173886.773 558693.287 173886.803 558693.148 173886.848 558692.938</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b696f1f4f-52f2-8e1c-bde8-41890b9ca92e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5daeee6817e94f05ac1ff511afad71e6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173939.375 559359.630 173938.997 559357.648 173942.758 559358.076 173943.121 559359.448 173939.958 559361.591 173939.375 559359.630</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b352a508c-74ac-90bc-10b7-29556e58c7e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5edfa195fe7d4705b62856c30f3e5061</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173819.615 558945.739 173819.221 558941.701 173819.880 558941.637 173820.074 558943.623 173826.678 558942.978 173826.662 558943.595 173823.610 558943.835 173823.702 558945.327 173819.615 558945.739</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6768248d-e984-134e-95fd-cebf280a7e09">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5f633c35d7ef43af83e048a54f522876</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173947.481 559377.021 173946.384 559375.351 173950.014 559374.263 173950.839 559375.423 173948.788 559378.644 173947.481 559377.021</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5206e66d-9bba-f744-5f09-cca67cae8dfc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6234b6651eaf4aa88e9c716fc9185e03</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173951.856 558664.583 173953.796 558658.869 173956.510 558659.790 173956.876 558658.711 173967.773 558664.692 173965.957 558666.293 173957.180 558661.490 173955.196 558666.680 173954.278 558666.330 173954.629 558665.412 173951.856 558664.583</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd05d8f17-8dec-6f57-5102-78aa5795a453">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.62d07173c1614a4ba20d87b4e4dfa6cd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173943.125 558861.054 173942.431 558859.538 173945.079 558858.581 173946.311 558861.087 173944.787 558862.965 173943.125 558861.054</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8886a4b8-6ed0-e3e1-7f85-c20f45da033c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-21T14:22:21</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.64fd38b065c243b1b13cdf54e423827d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173663.077 559968.269 173668.587 559970.694 173670.232 559967.149 173671.660 559967.785 173670.063 559971.325 173681.701 559976.527 173692.219 559981.287 173693.896 559977.687 173693.912 559977.694 173695.184 559978.261 173693.611 559981.950 173708.838 559988.663 173710.503 559985.083 173711.943 559985.724 173710.340 559989.375 173720.219 559993.743 173720.953 559994.102 173720.301 559995.441 173715.956 559993.493 173715.322 559993.209 173714.864 559993.004 173713.841 559992.545 173712.351 559991.971 173709.206 559990.571 173708.631 559990.314 173707.977 559990.023 173706.803 559989.500 173705.136 559988.695 173703.298 559987.882 173702.480 559987.520 173702.035 559987.323 173699.571 559986.233 173697.895 559985.438 173696.593 559984.864 173695.957 559984.584 173695.423 559984.348 173692.316 559982.978 173690.765 559982.268 173689.829 559981.852 173689.343 559981.636 173688.532 559981.276 173685.131 559979.766 173683.647 559979.037 173683.396 559978.914 173682.120 559978.354 173677.907 559976.507 173676.395 559975.766 173675.653 559975.441 173670.097 559973.001 173665.162 559983.264 173658.009 559997.998 173657.970 559998.190 173656.498 560001.111 173654.899 560000.278 173656.765 559997.017 173658.015 559994.515 173661.872 559986.619 173657.158 559984.318 173657.520 559983.320 173662.130 559985.620 173662.234 559985.675 173668.710 559972.350 173662.620 559969.762 173663.077 559968.269</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdb9de307-904f-d790-6a8a-b070f1a84026">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.67c0d16eb4724c05ac527b211a7bff08</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173823.993 558917.056 173826.728 558920.969 173826.605 558921.388 173822.951 558920.576 173823.993 558917.056</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b826f3612-b7f8-4f81-036c-0fb56c1a2ec5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6834c00c889f41af8528ddf2ff808f05</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173998.676 559395.686 173996.704 559396.061 173997.119 559392.298 173998.507 559391.983 174000.000 559394.168 174000.640 559395.105 173998.676 559395.686</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf7997b79-a2da-5ca7-7434-d05821c4163c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.68a153da74344b8ba1d3afe35d80cb35</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173720.219 559993.743 173721.883 559990.151 173723.088 559990.687 173723.315 559990.851 173721.076 559995.314 173717.032 560003.793 173716.492 560003.387 173720.301 559995.441 173720.953 559994.102 173720.219 559993.743</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b68fea05f-f691-7d37-5c9b-69227b3e889f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6e07783787c64521b814841d900e3212</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173871.496 558787.528 173868.994 558786.894 173869.078 558786.460 173871.627 558787.097 173871.496 558787.528</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b10b24d02-7c47-40fd-1162-41b9de8eace6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.734a1f130f2b49d59fe37e6db7621645</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173706.803 559989.500 173705.127 559991.457 173704.872 559991.307 173705.136 559988.695 173706.803 559989.500</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc1360d92-3a6c-a78f-3061-d93b220dce4e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7bb68e7044d5487db903bf2d6c81c2e6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173836.852 558734.675 173842.016 558734.675 173842.016 558737.109 173836.790 558736.949 173836.852 558734.675</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6ba3a94b-d227-750d-860f-4e0521eb13b5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7c53b702fc424d0d9f8cbc5b1e0e15c1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173880.169 558756.209 173877.455 558755.391 173879.573 558748.553 173882.194 558749.345 173880.169 558756.209</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b196441d0-f918-14d3-9639-51a91a019641">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-22T11:12:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.82b3135c784745fab40fd4d55a3580e1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173799.842 558706.408 173800.606 558706.609 173800.416 558707.331 173799.668 558707.156 173799.842 558706.408</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3a5916a9-001c-b3ae-5fe8-9a2922f883f1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.83f906d30ab841898bed01c778cccaa9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173918.499 558652.910 173921.553 558652.237 173921.987 558654.208 173918.917 558654.805 173918.499 558652.910</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4cb4987a-c675-7481-1fed-b9c69ff5f051">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-10-18T09:50:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8567c64ede7c4cccb5e0ba8063491ed3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173903.701 558662.604 173905.530 558665.155 173895.631 558674.336 173893.171 558672.552 173896.704 558669.214 173903.701 558662.604</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b949a3427-d7b7-a60d-9d44-41733e4d28df">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8f1ff58c9de942cea557a2ac60edd07c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173985.086 558755.757 173982.743 558754.811 173982.891 558754.434 173986.424 558747.745 173988.645 558748.894 173985.086 558755.757</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bce09fad2-92ad-f495-5f52-6ff854d8ce32">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8fe830f8792f4ed78460bb6ca3365e74</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173979.590 559396.503 173977.618 559396.100 173979.426 559392.798 173980.860 559392.985 173981.620 559396.722 173979.590 559396.503</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8106a296-1c61-83b1-175a-e7a01820eedf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.91cf6f4ef0de49ea8af007c478aa5975</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173979.822 558769.060 173977.100 558767.983 173979.612 558761.588 173979.792 558761.172 173982.508 558762.381 173979.822 558769.060</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbdb8b37c-3156-f53c-c29d-e7f7108d5867">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9253d7b8714745f6b68a591137982c9d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173637.398 558689.806 173639.630 558683.775 173640.976 558684.273 173639.645 558690.445 173637.398 558689.806</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b046d0205-adbe-fdb9-d78a-50f3587858f2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9432444b7d1c4079b21f6ea41c68c6ed</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173644.768 558692.872 173646.297 558692.633 173649.085 558688.535 173649.910 558689.160 173647.114 558693.195 173647.428 558694.820 173644.768 558692.872</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b58a2b3c0-f9f2-e0d9-28f4-d9179dc46bed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.960232caa5984ebeacfc9220e13f0712</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173939.162 558843.348 173941.603 558843.173 173941.641 558843.593 173942.285 558849.499 173942.407 558849.900 173939.776 558850.706 173939.162 558843.348</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b9ae74422-c5c6-e130-a99a-3cf77c7e0058">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-18T08:54:19.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9aa9e33d3e58414cbb7a2ce54304d114</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173554.578 558718.779 173554.391 558718.025 173544.835 558720.250 173544.484 558718.740 173564.548 558714.068 173564.927 558715.698 173555.250 558717.843 173555.387 558718.612 173556.661 558724.162 173555.952 558724.327 173554.578 558718.779</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf419257a-973b-2613-7f1d-75f465018e2e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9c464ccaf5234bf6b3f4e1f1c55f703c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173953.882 559384.178 173952.461 559382.746 173955.831 559381.025 173956.832 559381.975 173955.441 559385.472 173953.882 559384.178</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0b98a780-25b2-548a-27ac-0aad7197d991">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1bc2d02a0ec4e6aaa5c283d05e379fa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173681.412 559807.631 173679.924 559809.752 173675.737 559818.806 173674.981 559818.454 173679.438 559809.570 173679.888 559807.072 173681.412 559807.631</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b375d52c9-12e4-b0e2-7b04-14a2497f91a5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a857f134575e411c8924a867021975b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173655.554 559798.989 173653.962 559801.005 173649.995 559809.916 173649.455 559809.654 173653.530 559800.882 173654.012 559798.459 173655.554 559798.989</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b83a73b20-d5dc-6664-44be-b5903c046643">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a9488f8de21b41988b83521caf9539f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173534.396 558975.929 173532.749 558976.099 173531.111 558976.330 173529.482 558976.621 173528.321 558968.947 173533.267 558968.199 173534.396 558975.929</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7889a8e9-2e4a-8894-d850-6ca15ff3eae6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a98e2e90ccbe4915ac452189c4360ecb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173672.525 559804.663 173670.931 559806.765 173666.948 559815.846 173666.377 559815.599 173670.560 559806.564 173670.982 559804.117 173672.525 559804.663</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdaffcbf3-d4d0-6b7c-f9a2-7da3098a6f69">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ac1b1a7885ef4f889a60ad3bc6d06747</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173836.958 558754.294 173842.556 558754.440 173842.440 558756.351 173836.846 558756.152 173836.958 558754.294</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf895e63d-7265-a51d-9bbd-0ec9c673619b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-22T10:54:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b16b83231a304638a8165265f28b94db</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">174005.903 558665.781 174003.684 558670.461 174000.209 558668.648 173999.327 558668.188 173997.783 558671.147 173996.478 558670.466 174002.012 558659.860 174003.259 558660.511 174001.663 558663.569 174002.720 558664.120 174005.903 558665.781</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="baf6c4d0f-d818-4939-da56-ac92de7bfca3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b66b557d27564416a2b7e855583925de</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173657.382 558695.952 173658.151 558697.303 173652.718 558701.211 173651.624 558699.233 173652.461 558698.753 173657.382 558695.952</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="badb2f112-9f44-eb65-26ee-5c0d298ea977">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b8243f159808422aa7c853bf65b41576</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173799.851 558941.141 173799.543 558938.286 173807.300 558937.614 173807.520 558940.390 173807.528 558940.457 173799.851 558941.141</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b28b19c5f-1eeb-ef5e-492c-48131e252b0d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b8a16698b881462abc88bef2851265f4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173989.180 559397.035 173987.207 559397.028 173988.270 559393.413 173989.704 559393.373 173991.213 559396.843 173989.180 559397.035</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b9e301159-ef26-1148-821e-096ddc2783da">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bc265b4e78e04cf4baf8fddc58ccc7fd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173815.830 558946.118 173815.538 558943.436 173815.924 558943.436 173816.175 558946.085 173815.830 558946.118</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbfe35cb9-ea05-0ac3-909c-3e433b5d152b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bcb427f04ef84411a35699ad56c18063</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173975.260 558776.723 173976.281 558773.847 173976.865 558774.054 173975.743 558776.883 173975.260 558776.723</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b51e007bb-3544-3368-75ed-a037ffe94b36">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bdd17e7e1dff4193811efa7fdc94eee8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173993.795 558740.205 173992.062 558739.077 173988.388 558743.906 173987.997 558743.603 173991.576 558738.760 173991.765 558738.442 173991.796 558738.462 173992.289 558738.778 173993.991 558739.870 173993.795 558740.205</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6ce384b3-88a9-569f-2c0e-216dfebb13aa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bf6b94a5d8b948c38649c33aecc84dc2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173691.497 559811.009 173689.990 559813.028 173685.777 559822.202 173685.144 559821.893 173689.500 559812.943 173689.963 559810.490 173691.497 559811.009</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1e617c3c-613e-7a8a-8e75-d255d70a6897">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c50f78d37d0847e0a75076c66b687f29</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173886.089 558732.199 173883.989 558731.772 173884.069 558731.434 173884.856 558726.890 173887.032 558727.393 173886.089 558732.199</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b16b3909b-fc89-2c49-0b91-244e0ded445a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c83aaf1a9dec4b3fbcfcec2396e33e93</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173974.191 558776.328 173975.572 558772.394 173976.109 558772.481 173974.678 558776.516 173974.191 558776.328</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5251c46c-9195-86f5-9022-c528ab64c125">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ccb78cd44b794de589c43baefc521941</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173997.958 558699.633 173995.383 558699.704 173995.350 558699.302 173997.902 558699.167 173997.958 558699.633</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b27c087be-3ee9-8ea6-e733-d77eb639b18d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ceb60580c6424cb09e0a70c10ace0cb0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173628.464 558689.163 173629.552 558687.948 173629.234 558683.053 173630.230 558682.969 173630.392 558687.937 173631.569 558688.974 173628.464 558689.163</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b814865a4-8677-d6e3-744f-ce9b5b78b7f7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d48fa589d1c04f04915ff485a9a5c38c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173878.631 558761.526 173876.124 558760.761 173876.253 558760.426 173878.746 558761.189 173878.631 558761.526</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3d39511e-50ff-0dec-e4d3-234b36d4e019">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d60d1114ae894ae5926ef550f5880e86</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173885.679 558737.760 173883.076 558737.280 173883.128 558736.922 173885.755 558737.414 173885.679 558737.760</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bda65f986-a61c-a71c-e560-055be7e1ef0c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e7cd7debbfcc40deb0f52a4758aa5168</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173701.621 559814.331 173700.027 559816.223 173696.402 559824.121 173695.988 559823.926 173699.478 559816.223 173699.977 559813.785 173701.621 559814.331</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b72f1ffa2-4eaf-9f62-36e3-8101d2c53417">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-22T11:12:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.eb0a4faea664438ba186136515e3d667</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173800.606 558706.609 173799.842 558706.408 173800.968 558701.572 173801.476 558699.390 173791.765 558697.129 173792.204 558695.246 173812.435 558699.956 173812.006 558701.800 173802.458 558699.577 173801.884 558701.756 173800.606 558706.609</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba8e06040-8267-7ea6-691b-ffe541e6b701">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ffdcb266b2bc48d7a11cd20b52f226c6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173620.446 558691.625 173618.352 558685.589 173619.684 558684.983 173622.614 558690.688 173620.446 558691.625</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b572d86ca-df14-7ea9-8fe9-be508cfe174b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.09ebf364ce044e128e16245c48fed3b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173677.907 559976.507 173676.348 559978.484 173676.086 559978.314 173676.278 559976.729 173676.395 559975.766 173677.907 559976.507</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b55801864-3d5a-fbfc-95b1-03fa79370e4e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0d88875768644ab1a8cd2ef055a371f2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173886.160 558696.842 173883.268 558696.521 173883.301 558696.148 173886.220 558696.446 173886.160 558696.842</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b91e59525-157e-a128-9bad-e57eab70ca62">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.11e1c055fbb44e0f892aa0916f6764e1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173647.431 559796.248 173645.732 559798.608 173641.780 559807.255 173641.313 559807.043 173645.279 559798.663 173645.877 559795.710 173647.431 559796.248</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b071acd0d-3a58-5970-2dc4-243f076d05b2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.44ff689f00b5488aa029d04edfcc34b9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173906.750 558658.794 173907.299 558658.448 173911.745 558665.516 173911.900 558665.626 173911.448 558665.938 173906.750 558658.794</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b506adeb1-5599-dcbc-6c82-133e60262884">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.511c4993ebb74b00b36caa98185c05e7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173885.329 558704.043 173882.385 558703.659 173882.423 558703.287 173885.350 558703.643 173885.329 558704.043</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd2e02a50-df88-36d5-5d87-5b20802bee45">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.53f3063698ad4092b236a4a16a5ad4ea</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173943.156 558651.614 173951.902 558653.671 173949.911 558658.263 173942.024 558656.425 173943.156 558651.614</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbc471fa2-2f8a-efdc-6858-03a8eecb0963">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.62a64e27504c4dc4ba06ae134185b671</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173992.796 558954.784 173999.044 558956.729 173998.220 558959.300 173998.219 558959.302 173992.040 558957.430 173992.796 558954.784</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b669f94a1-83fc-2d84-ffd5-7c2a7cf686a9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6dcf4bfe52f449439ae28bcb1dde9adb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173970.217 559394.099 173968.395 559393.331 173970.751 559390.403 173972.107 559390.899 173972.176 559394.705 173970.217 559394.099</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0f6ab2e1-6c75-64d3-63ed-d34fde598ccc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7e4a1a907f3640c9ae6f73d3ae6d7e12</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173885.467 558688.409 173887.070 558684.751 173889.738 558680.027 173889.124 558679.602 173889.429 558679.162 173891.995 558680.937 173891.613 558681.685 173890.138 558684.575 173887.877 558689.098 173885.467 558688.409</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6e746371-66e5-c0dc-a992-be5f7cd33f17">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8b66c0f2463b496893e6babe2c4fd85f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173984.608 559307.514 173983.097 559310.028 173979.194 559319.088 173979.158 559319.171 173978.796 559318.996 173979.440 559317.462 173979.691 559316.865 173982.765 559309.535 173983.182 559306.914 173983.290 559306.238 173984.608 559307.514</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b899abcc8-cdf2-4ca4-aa91-8852d7805452">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8d0e575718fe4628bafd2391cce6c923</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173628.278 559828.938 173629.982 559827.204 173634.829 559819.204 173635.261 559819.467 173630.383 559827.513 173629.799 559829.576 173628.278 559828.938</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be2545cb5-58ca-2e7f-2fbd-ab06cea666a5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.91bbe63d72fb45a48d54cff271aa116d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173923.837 558944.470 173923.830 558944.340 173923.685 558941.644 173923.632 558940.951 173927.726 558944.470 173923.837 558944.470</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd378efe6-3e27-8fe5-1192-6d05261fc04c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.abc3c1231fd141a7a74ffa5733e335cb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173942.564 559368.683 173941.808 559366.836 173945.572 559366.541 173946.156 559367.782 173943.497 559370.455 173942.564 559368.683</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf0d749de-e568-48fb-80a3-ecd4b5edd639">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ae50dfe2ce4e4a6f94cffde27249cbfc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173971.033 558796.033 173968.398 558795.553 173970.344 558788.694 173970.163 558788.626 173970.357 558788.244 173970.461 558788.281 173972.753 558789.092 173971.033 558796.033</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bbcfcedd8-a726-b1cd-3405-5dbabc4f9b34">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b9d9f2aa4e3349f985921be5e7ddb4aa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173864.740 558820.627 173862.221 558820.204 173863.324 558813.643 173863.413 558813.236 173865.827 558813.752 173864.740 558820.627</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b26493161-6724-ed8f-6ab5-c7717ba7ebad">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b9e2fc5e0319411db2dfeb835758224d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173966.213 558803.182 173966.940 558800.508 173967.305 558800.608 173966.583 558803.266 173966.213 558803.182</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2dc39120-2c2f-1476-6f96-402a166f0f62">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bb8c55b05ed1408aa07b3878d2f1fbc5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173938.495 558944.868 173932.995 558944.645 173932.995 558942.100 173938.605 558942.100 173938.495 558944.868</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b04fa5c42-6b97-88c1-dcaa-6ddaed3f8a69">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c1154fbb9f8b44f3afeaa7a4419e53f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173990.183 559310.121 173987.990 559312.786 173985.738 559318.362 173984.483 559317.708 173986.781 559312.217 173987.084 559308.557 173990.183 559310.121</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6dd9d1b4-7957-6a49-6fae-1945e1feb0d9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d188fd925c794a018198726a6dd651cf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173865.602 558948.617 173868.346 558945.529 173868.631 558945.518 173868.939 558948.195 173865.602 558948.617</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b453f4737-4765-ef0f-deed-01e586e775a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.db3a696e7cd945c7a2b502aa92c6dab3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173699.571 559986.233 173698.036 559987.998 173697.709 559987.795 173697.895 559985.438 173699.571 559986.233</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b60d0e42e-fb14-c45c-90cf-92250ddf3dc7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d3384c25c21b451ebf3448dcd31e5997</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173685.131 559979.766 173683.557 559981.712 173683.233 559981.573 173683.647 559979.037 173685.131 559979.766</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfb3c8fef-5f44-c73a-f0a3-699f67acbe93">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d3803a8616784706b3303bdf2660cf45</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173959.428 558941.932 173960.175 558942.203 173961.173 558942.565 173960.056 558947.821 173959.269 558947.714 173958.698 558947.596 173959.428 558941.932</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcb3db01b-bc6e-a85b-1bc2-127a65188037">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e519a507b90f448ab9083a12f86c7531</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173896.124 558945.316 173895.835 558942.686 173916.752 558941.864 173916.890 558944.560 173916.898 558944.717 173896.124 558945.316</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf6a08d04-2ce1-5059-537f-c163b9032364">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f234c8bee84d4637a21fdbfd164dbd79</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173862.426 558847.970 173859.460 558848.210 173859.423 558847.815 173859.423 558841.829 173862.426 558841.534 173862.426 558847.970</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd6ac4b52-2a17-9973-74b2-5c3ccfb17d6a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f5ea1df547324191a8346955d114bb1b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173825.867 558909.576 173829.153 558910.278 173829.190 558910.286 173829.077 558910.741 173825.777 558909.957 173825.867 558909.576</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3d14ee3d-a963-df4b-5ba5-6e25873e1d74">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.0c2b66958e9e4b2bb35c49e7338fefd7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172885.336 558265.710 172898.395 558257.650</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc1b1f52f-b883-33da-7ff7-56c054504378">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.9ce73794256b4749ac03852e81781087</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172926.807 558695.744 172928.689 558707.682</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b64fc604f-7b45-7e98-89c1-9e0953a8bec5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.576d811ac2354dec81c11befecfbd4c8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172880.014 558398.964 172878.561 558399.130 172878.022 558399.191 172874.485 558399.594 172872.668 558399.802 172867.881 558400.348 172865.256 558400.647</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1e8a0b0d-ae03-5571-159d-25943c1da424">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.5f862d24d13d4922a043bc4c29d75f8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172831.957 558104.607 172831.112 558101.284 172830.447 558098.671 172829.431 558094.677</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1539ccaa-c91e-1336-d1b7-eb67f93ddeaf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.6559d0d637e1463593ee1d1f17fafc39</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172849.592 558069.259 172849.041 558069.328 172848.084 558069.449 172846.870 558069.602 172843.379 558070.041 172841.300 558070.303 172836.756 558070.876 172825.672 558072.272 172824.045 558072.477</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1fa13c5c-2ceb-f706-abc7-d503e2c3dc2d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.6571ee6da43d42658c74cba082022580</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172819.684 558013.750 172864.019 558010.054</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b13139009-d2c0-4b52-2585-b94bb29c9f59">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-05</terminationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-03-05T11:42:24</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.6ba48404ad9e4ce28973f8b792ece221</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172900.970 558402.782 172901.215 558405.019 172901.714 558409.585 172902.122 558413.317 172902.588 558417.583</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfe43daa8-0f0d-51a9-9689-59277bac09a7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.78c54dd9266c4387b41842bf5a02b296</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172912.344 558541.295 172911.387 558530.184</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b57dd3219-eaf3-96f2-e490-39f1180d8b9f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.82608c32649941a68b46bfcdc48c058a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172905.947 558709.635 172904.034 558709.815 172900.525 558710.147 172898.521 558710.336 172893.973 558710.765 172890.809 558711.063 172890.125 558711.128</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5a80d9f6-2c61-12d5-7597-097b16c99f94">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.961851ec1da24bd08daa8eca7ee7aa9c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172869.307 558092.401 172869.519 558099.549</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8fe604ed-2ab3-4e0b-11ca-cdd8fcbfac2e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.abd0abf235db4f5ebf8d6ff4173d8025</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172904.479 558691.949 172902.517 558692.174 172899.049 558692.572 172897.130 558692.792 172892.603 558693.311 172889.021 558693.722 172888.700 558693.759</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba7185114-d623-9ba2-c82b-32459ea485c0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.bb6683997e5246c1bae75f4b53d01ff3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172912.363 558784.113 172896.318 558785.846</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b769e969c-efd7-e6c1-639d-2d3e6f780375">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.cc4484d2cb3c412ca20591b606e0d9c2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172847.570 558140.919 172843.178 558141.235 172839.352 558141.509 172838.951 558141.538</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b89bc6159-a411-0124-5ada-640236450373">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.e1df448ddfe74a7e89992768415b90a9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172841.250 558178.259 172846.388 558177.740 172850.941 558177.280 172852.952 558177.077 172856.461 558176.723 172858.360 558176.531</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b58f1aed0-7fc1-bfbb-75db-141f3b3e7327">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.e6a52502f7a04dee82c32781a923a780</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172850.493 558282.726 172840.379 558263.153</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bcca4e884-f706-3a92-36cb-e224d7309a9f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.f5636d8177ab4505a6a8a016e9e4b611</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172886.486 558682.477 172886.508 558682.675 172886.798 558685.328 172887.103 558688.118 172887.455 558691.333 172887.492 558691.672</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b7cf8844f-69ff-88fb-eb1b-b73f386030a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-10-18T09:50:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8567c64ede7c4cccb5e0ba8063491ed3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173903.701 558662.604 173905.530 558665.155 173895.789 558674.297 173893.171 558672.552 173896.704 558669.214 173903.701 558662.604</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0f998bf4-bf49-0c05-539d-28d3957e221d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-02-01T20:50:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2017-02-21T14:22:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.64fd38b065c243b1b13cdf54e423827d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173663.077 559968.269 173668.587 559970.694 173670.232 559967.149 173671.660 559967.785 173670.063 559971.325 173681.701 559976.527 173692.219 559981.287 173693.896 559977.687 173695.184 559978.261 173693.611 559981.950 173708.838 559988.663 173710.503 559985.083 173711.943 559985.724 173710.340 559989.375 173720.219 559993.743 173720.953 559994.102 173720.301 559995.441 173715.956 559993.493 173715.322 559993.209 173714.864 559993.004 173713.841 559992.545 173712.351 559991.971 173709.206 559990.571 173708.631 559990.314 173707.977 559990.023 173706.803 559989.500 173705.136 559988.695 173703.298 559987.882 173702.480 559987.520 173702.035 559987.323 173699.571 559986.233 173697.895 559985.438 173696.593 559984.864 173695.957 559984.584 173695.423 559984.348 173692.316 559982.978 173690.765 559982.268 173689.829 559981.852 173689.343 559981.636 173688.532 559981.276 173685.131 559979.766 173683.647 559979.037 173683.396 559978.914 173682.120 559978.354 173677.907 559976.507 173676.395 559975.766 173675.653 559975.441 173670.097 559973.001 173665.162 559983.264 173658.009 559997.998 173657.970 559998.190 173656.498 560001.111 173654.899 560000.278 173656.765 559997.017 173658.015 559994.515 173661.872 559986.619 173657.158 559984.318 173657.520 559983.320 173662.130 559985.620 173662.234 559985.675 173668.710 559972.350 173662.620 559969.762 173663.077 559968.269</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b389a86fb-4c62-8455-ad19-4dfbe2e020aa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-05</terminationDate>
            <imgeo:LV-publicatiedatum>2019-03-05T11:47:09</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-03-05T11:42:24</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.6ba48404ad9e4ce28973f8b792ece221</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172900.970 558402.782 172901.215 558405.019 172901.714 558409.585 172902.122 558413.317 172902.588 558417.583</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bb5d43824-f9f2-9226-ebd7-59e3af418098">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-05</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-05T11:47:09</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-03-05T11:42:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.0741be039c6543e5948af4b809abb884</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172865.804 558428.371 172865.718 558427.475 172901.420 558424.041 172901.506 558424.937 172865.804 558428.371</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b0e247af4-d95c-3b0c-cdef-350575c537f3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-03-05</creationDate>
            <imgeo:LV-publicatiedatum>2019-03-05T11:47:09</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-03-05T11:42:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.44f5f225b04549b8a043f9c1563ac764</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172901.127 558402.765 172901.372 558405.002 172901.871 558409.568 172902.279 558413.300 172902.745 558417.566 172902.432 558417.600 172901.966 558413.334 172901.558 558409.602 172901.059 558405.036 172900.814 558402.799 172901.127 558402.765</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerkPlus">duiker</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b843f0490-faf4-658e-5e19-bb3bac5f457e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-08-11T14:58:16.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.98693c4c929d4663a7023ad5948a5d1d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172479.742 559241.588 172479.705 559241.635 172479.636 559241.721 172479.485 559241.910 172477.674 559244.171 172475.849 559242.709 172473.020 559246.241 172471.512 559245.029 172474.194 559241.538 172470.570 559238.790 172472.118 559236.704 172472.500 559236.190 172472.716 559236.123 172476.142 559238.706 172477.785 559240.021 172479.742 559241.588</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bd5d8e924-41bb-102b-f390-1afc2dd4fb44">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-12-15</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-12-15T16:35:47</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.73656929c7364d89a6e0f2065e23aa76</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173974.158 558727.158 173976.351 558727.842 173974.652 558733.895 173974.494 558734.219 173972.228 558733.266 173974.158 558727.158</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="baee197ad-2e93-ab10-d0b1-f94e180418e6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-12-15</terminationDate>
            <imgeo:LV-publicatiedatum>2022-12-20T10:43:57</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-12-15T16:35:47</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.73656929c7364d89a6e0f2065e23aa76</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173974.158 558727.158 173976.351 558727.842 173974.652 558733.895 173974.494 558734.219 173972.228 558733.266 173974.158 558727.158</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc34b1b09-315b-279a-93e4-fdd7766522b1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-10T11:21:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.381bf55080c1401e8c36f24274065f0e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172294.556 558602.903 172293.348 558607.430</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bafc5d89c-8473-2ee3-3051-7a4a69526bf9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-10</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-06-14T11:08:00</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-10T11:21:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.381bf55080c1401e8c36f24274065f0e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172294.556 558602.903 172293.348 558607.430</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be6b98cae-c5b5-40ca-3350-99127e63dde7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:21:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.4f8db86f376f4c0ab0a525b93fd64f26</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172141.721 558731.806 172143.197 558725.904</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfbdc1eb2-ddbc-e72e-107a-d5a1e7850abf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-06-14T11:08:00</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:21:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.4f8db86f376f4c0ab0a525b93fd64f26</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172141.721 558731.806 172143.197 558725.904</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfa311f89-ae3c-a5ea-7545-32d1b3cbfa2d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:24:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.90fb56229c564587aa67e7eb6f1e6fd4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172328.514 558486.378 172329.637 558480.988</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4cc659ac-f14a-abd1-3b5f-eacffaea16ec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-06-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-06-14T11:08:00</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-06-14T10:00:00</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-21T09:24:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.90fb56229c564587aa67e7eb6f1e6fd4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172328.514 558486.378 172329.637 558480.988</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">stuw</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b238d37e2-611d-e16a-3afb-718a814cbe19">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:11:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-18T09:41:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3882a02e326c48a691de4b57a743da4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173145.253 559139.212 173147.017 559138.030 173147.571 559138.828 173145.773 559140.074 173138.433 559145.160 173137.195 559146.019 173137.015 559144.868 173138.748 559143.678 173145.253 559139.212</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc97a227f-8437-c188-eb0c-58ca96720f26">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:11:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-18T09:41:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3882a02e326c48a691de4b57a743da4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173145.253 559139.212 173147.017 559138.030 173147.571 559138.828 173145.773 559140.074 173138.433 559145.160 173137.195 559146.019 173137.015 559144.868 173138.748 559143.678 173145.253 559139.212</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bfe72feb8-f30f-4f49-55a2-d64965acb56b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-21</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-21T09:38:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4423f80758da4a2aa89873ac78b8a9e4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173871.861 558810.018 173861.814 558807.894 173861.928 558807.357 173871.969 558809.480 173871.861 558810.018</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba8108059-723c-2f18-8afb-89cdad68b4af">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-21</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-21T09:38:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.4423f80758da4a2aa89873ac78b8a9e4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173871.861 558810.018 173861.814 558807.894 173861.928 558807.357 173871.969 558809.480 173871.861 558810.018</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b2c6fd905-ef45-dc9b-8c82-b3b341144990">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:26:35</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9d7cba63595a4c9d9c2a3a71b3554dd7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173607.072 558708.830 173611.893 558710.025 173611.401 558711.696 173611.093 558711.658 173611.054 558711.972 173597.174 558710.602 173597.827 558707.295 173597.813 558707.098 173602.161 558707.926 173607.072 558708.830</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba8b9bffe-2982-7c19-f16b-3bdf8facf92e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:26:35</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-16T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9d7cba63595a4c9d9c2a3a71b3554dd7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173607.072 558708.830 173611.893 558710.025 173611.401 558711.696 173611.093 558711.658 173611.054 558711.972 173597.174 558710.602 173597.827 558707.295 173597.813 558707.098 173602.161 558707.926 173607.072 558708.830</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b1e355ca0-e0a2-47da-3e14-a1b5c6cd233a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:11:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-18T09:41:40.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fac810f937ce48c982e732c3a05ae3e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173137.015 559144.868 173137.195 559146.019 173136.624 559146.414 173134.725 559147.639 173134.177 559146.817 173137.015 559144.868</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf857816b-db0a-0eb9-9c06-dde2b4fbdcb7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-11-14</terminationDate>
            <imgeo:LV-publicatiedatum>2024-11-22T15:08:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-11-14T15:11:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-18T09:41:40.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.fac810f937ce48c982e732c3a05ae3e9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173137.015 559144.868 173137.195 559146.019 173136.624 559146.414 173134.725 559147.639 173134.177 559146.817 173137.015 559144.868</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bb42f3bca-9b6b-a57c-0937-087150cbd568">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:55</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3e8ae877401944ea96abccbe80076060</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173864.210 559937.398 173860.865 559942.377 173857.510 559947.370 173854.160 559952.357 173850.811 559957.342 173847.456 559962.336 173844.102 559967.330 173840.752 559972.315 173837.291 559977.468 173837.018 559977.877 173835.928 559977.135 173849.072 559957.404 173844.373 559954.613 173845.933 559952.303 173850.453 559955.354 173863.084 559936.640 173864.210 559937.398</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b615a6a38-ea79-ee1f-9214-f502f2f97822">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:10:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3e8ae877401944ea96abccbe80076060</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173864.210 559937.398 173860.865 559942.377 173857.510 559947.370 173854.160 559952.357 173850.811 559957.342 173847.456 559962.336 173844.102 559967.330 173840.752 559972.315 173837.291 559977.468 173836.665 559978.406 173835.696 559977.639 173836.301 559976.631 173829.446 559971.752 173831.019 559969.695 173837.753 559974.413 173842.672 559967.195 173836.866 559963.163 173837.632 559961.873 173843.519 559965.704 173849.072 559957.404 173844.373 559954.613 173845.933 559952.303 173850.453 559955.354 173853.035 559951.551 173848.115 559948.002 173848.962 559946.994 173853.962 559950.220 173862.067 559938.244 173856.986 559934.897 173858.018 559933.228 173863.084 559936.640 173864.210 559937.398</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b02e1ec80-d673-931e-4a7a-b0c488b070d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:55</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6297927e011d4b16a37122e0af282d4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173840.624 559993.124 173837.255 559998.143 173836.008 560000.000 173833.907 560003.130 173830.560 560008.117 173827.212 560013.105 173823.865 560018.091 173820.517 560023.078 173817.056 560028.235 173814.762 560026.696 173813.970 560027.876 173813.703 560026.951 173813.538 560026.833 173810.088 560024.353 173810.511 560023.765 173814.075 560026.327 173814.844 560026.393 173816.237 560027.246 173817.198 560025.676 173814.165 560023.820 173814.644 560023.130 173817.501 560025.113 173822.966 560017.243 173820.497 560015.528 173823.450 560011.276 173825.721 560012.853 173827.531 560010.454 173822.035 560007.044 173822.588 560006.151 173827.990 560009.502 173832.349 560003.178 173825.573 559998.883 173826.536 559997.364 173833.315 560001.661 173839.640 559992.464 173840.624 559993.124</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="ba7fe1c64-0c2e-7a13-388e-520f6bf641e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:10:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6297927e011d4b16a37122e0af282d4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173840.624 559993.124 173837.255 559998.143 173836.008 560000.000 173833.907 560003.130 173830.560 560008.117 173827.212 560013.105 173823.865 560018.091 173820.517 560023.078 173817.056 560028.235 173816.000 560027.526 173817.380 560025.484 173814.345 560023.537 173814.757 560022.889 173817.653 560024.894 173820.916 560020.209 173818.179 560018.327 173818.663 560017.643 173821.429 560019.382 173823.197 560016.702 173820.659 560014.906 173823.368 560010.771 173825.991 560012.496 173827.702 560010.116 173822.328 560006.532 173822.741 560005.810 173828.054 560009.410 173832.492 560002.959 173825.791 559998.340 173826.591 559997.083 173833.315 560001.661 173839.640 559992.464 173840.624 559993.124</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc3bb5254-fef4-f458-2d7d-5c28b3f09282">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6b45e442428749ea9a3faf915367d86b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173907.116 559920.145 173907.294 559920.024 173907.482 559919.918 173907.678 559919.829 173907.881 559919.757 173908.089 559919.703 173908.302 559919.668 173908.516 559919.650 173908.732 559919.652 173908.946 559919.672 173909.158 559919.710 173909.366 559919.767 173909.568 559919.841 173909.763 559919.933 173909.949 559920.040 173910.125 559920.164 173910.290 559920.303 173910.443 559920.455 173910.582 559920.619 173910.706 559920.796 173910.814 559920.982 173910.906 559921.177 173910.980 559921.379 173911.037 559921.586 173911.076 559921.798 173911.096 559922.013 173911.098 559922.228 173911.081 559922.443 173911.046 559922.655 173910.992 559922.864 173910.921 559923.067 173910.832 559923.263 173910.687 559923.515 173906.815 559920.832 173906.967 559920.486 173907.116 559920.145</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b307ddd0d-0f3a-7e9d-7a02-a08d01e76ac8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6b45e442428749ea9a3faf915367d86b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173907.116 559920.145 173907.294 559920.024 173907.482 559919.918 173907.678 559919.829 173907.881 559919.757 173908.089 559919.703 173908.302 559919.668 173908.516 559919.650 173908.732 559919.652 173908.946 559919.672 173909.158 559919.710 173909.366 559919.767 173909.568 559919.841 173909.763 559919.933 173909.949 559920.040 173910.125 559920.164 173910.290 559920.303 173910.443 559920.455 173910.582 559920.619 173910.706 559920.796 173910.814 559920.982 173910.906 559921.177 173910.980 559921.379 173911.037 559921.586 173911.076 559921.798 173911.096 559922.013 173911.098 559922.228 173911.081 559922.443 173911.046 559922.655 173910.992 559922.864 173910.921 559923.067 173910.832 559923.263 173910.687 559923.515 173906.815 559920.832 173906.967 559920.486 173907.116 559920.145</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b30a437c4-10cd-8f7d-55eb-d6a6a2e6a9aa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:55</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.76e1022501cd4a509b34d3377535a348</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173586.316 559967.917 173585.186 559969.980 173583.765 559974.887 173583.344 559974.765 173584.514 559970.072 173584.666 559967.397 173586.316 559967.917</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be772b362-8ab1-f410-bb0f-429f055c3136">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:46:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.76e1022501cd4a509b34d3377535a348</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173586.316 559967.917 173585.186 559969.980 173582.590 559977.781 173582.140 559977.806 173584.514 559970.072 173584.666 559967.397 173586.316 559967.917</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b32dbc1fe-8452-3903-9b39-593f30ec5926">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.90de8c59bd6149dcb4cd8b87312f3eae</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173570.944 559962.758 173569.354 559964.444 173567.883 559968.859 173567.370 559968.688 173568.668 559964.791 173568.993 559962.240 173570.944 559962.758</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be76c0604-e10c-ec7f-1335-ee167f0ca4ef">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:46:54.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.90de8c59bd6149dcb4cd8b87312f3eae</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173572.204 559963.104 173570.732 559965.534 173568.612 559972.247 173568.047 559971.894 173570.026 559965.322 173570.451 559962.632 173572.204 559963.104</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b3b4d1ba1-9f47-5e0f-a165-52097c049982">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9af542fd668f40fba077deebbea95c42</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173578.563 559964.992 173577.360 559966.545 173575.650 559971.864 173575.138 559971.700 173576.744 559966.456 173576.551 559964.298 173578.563 559964.992</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5a96e650-3044-3315-d35e-502314ac2875">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9af542fd668f40fba077deebbea95c42</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173578.563 559964.992 173577.360 559966.545 173575.650 559971.864 173575.138 559971.700 173576.744 559966.456 173576.551 559964.298 173578.563 559964.992</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bdf5cb563-e6f3-2b5d-4c00-0c4eba2c5504">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:55</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a714758496a54866bfe157d12c9a9313</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173604.930 559973.550 173600.487 559986.935 173592.073 560012.618 173582.666 560014.415 173582.666 560013.564 173590.798 560011.666 173592.203 560008.006 173590.536 560008.161 173582.355 560009.890 173582.309 560009.350 173590.644 560007.342 173592.650 560006.570 173594.827 559999.697 173593.071 559999.859 173585.292 560001.346 173585.238 560000.778 173592.909 559999.130 173595.529 559998.319 173597.717 559991.292 173595.421 559991.400 173586.453 559992.940 173586.372 559992.454 173595.367 559990.805 173598.149 559989.994 173600.688 559982.210 173598.771 559982.319 173590.046 559983.670 173589.992 559983.319 173598.149 559981.940 173601.175 559980.967 173603.651 559973.260 173603.827 559973.300 173604.930 559973.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b8607c0da-50f7-fe23-0b23-2c57b14e57f5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:46:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a714758496a54866bfe157d12c9a9313</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173604.930 559973.550 173592.073 560012.618 173582.666 560014.415 173582.666 560013.564 173590.798 560011.666 173603.651 559973.260 173603.827 559973.300 173604.930 559973.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be35efff3-089f-5cc5-d321-bffa7fdf7a6d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e1ce555cf17541439ddc8139a1458c01</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173562.457 559960.026 173561.308 559961.737 173559.089 559969.012 173558.548 559968.847 173560.444 559962.629 173560.827 559959.436 173562.457 559960.026</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b6c4c56cb-e30e-5189-3541-bb02c8446c56">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2024-12-05</terminationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:46:54</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e1ce555cf17541439ddc8139a1458c01</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173562.457 559960.026 173561.308 559961.737 173559.089 559969.012 173558.548 559968.847 173560.444 559962.629 173560.827 559959.436 173562.457 559960.026</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b5481e382-e7ac-3678-d99d-c79f5d65d9f8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-02-06T14:39:01</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.516c5fb4117d47ab959cf42c814f98ec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173701.270 558692.999 173702.742 558691.217 173704.376 558689.583 173706.158 558688.111 173702.494 558683.055 173702.981 558682.656 173706.671 558687.736 173708.469 558686.575 173710.361 558685.577 173712.334 558684.749 173710.586 558679.841 173711.056 558679.659 173712.836 558684.570 173715.007 558683.933 173717.227 558683.501 173719.478 558683.276 173719.044 558674.626 173724.219 558674.834 173723.300 558683.373 173725.539 558683.713 173727.736 558684.258 173729.874 558685.006 173733.208 558676.976 173733.970 558677.201 173730.667 558685.342 173732.490 558686.245 173734.231 558687.297 173735.879 558688.491 173739.975 558683.380 173740.598 558683.891 173736.512 558689.009 173738.167 558690.547 173739.673 558692.232 173741.016 558694.049 173748.816 558689.108 173749.057 558689.531 173741.307 558694.495 173741.602 558694.969 173741.886 558695.449 173742.159 558695.936 173742.252 558696.108 173740.136 558697.241 173739.762 558696.571 173739.365 558695.914 173738.945 558695.272 173738.504 558694.645 173738.040 558694.034 173737.556 558693.439 173737.050 558692.861 173736.525 558692.302 173735.981 558691.761 173735.419 558691.239 173734.838 558690.737 173734.240 558690.256 173733.626 558689.797 173732.996 558689.359 173732.351 558688.943 173731.692 558688.550 173731.020 558688.180 173730.335 558687.834 173729.639 558687.512 173728.932 558687.214 173728.215 558686.942 173727.488 558686.694 173726.754 558686.472 173726.012 558686.276 173725.264 558686.106 173724.510 558685.962 173723.752 558685.845 173722.990 558685.754 173722.225 558685.690 173721.459 558685.653 173720.692 558685.642 173719.925 558685.658 173719.159 558685.701 173718.395 558685.771 173717.634 558685.867 173716.876 558685.990 173716.124 558686.139 173715.377 558686.315 173714.636 558686.516 173713.903 558686.743 173713.179 558686.996 173712.464 558687.273 173711.759 558687.576 173711.065 558687.903 173710.382 558688.254 173709.713 558688.629 173709.057 558689.027 173708.415 558689.447 173707.788 558689.890 173707.177 558690.354 173706.583 558690.839 173706.006 558691.345 173705.447 558691.870 173704.907 558692.415 173704.386 558692.979 173703.885 558693.560 173703.405 558694.158 173702.946 558694.773 173702.913 558694.821 173701.016 558693.345 173693.582 558688.127 173693.844 558687.740 173701.270 558692.999</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bc8a01a25-9d8e-e78a-76a8-6f7f873a3fa6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2025-02-07T16:30:20</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-02-06T14:39:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.516c5fb4117d47ab959cf42c814f98ec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173701.270 558692.999 173702.742 558691.217 173704.376 558689.583 173706.158 558688.111 173702.494 558683.055 173702.981 558682.656 173706.671 558687.736 173708.469 558686.575 173710.361 558685.577 173712.334 558684.749 173710.586 558679.841 173711.056 558679.659 173712.836 558684.570 173715.007 558683.933 173717.227 558683.501 173719.478 558683.276 173719.044 558674.626 173724.219 558674.834 173723.300 558683.373 173725.539 558683.713 173727.736 558684.258 173729.874 558685.006 173733.208 558676.976 173733.970 558677.201 173730.667 558685.342 173732.490 558686.245 173734.231 558687.297 173735.879 558688.491 173739.975 558683.380 173740.598 558683.891 173736.512 558689.009 173738.167 558690.547 173739.673 558692.232 173741.016 558694.049 173748.816 558689.108 173749.057 558689.531 173741.307 558694.495 173741.602 558694.969 173741.886 558695.449 173742.159 558695.936 173742.252 558696.108 173740.136 558697.241 173739.762 558696.571 173739.365 558695.914 173738.945 558695.272 173738.504 558694.645 173738.040 558694.034 173737.556 558693.439 173737.050 558692.861 173736.525 558692.302 173735.981 558691.761 173735.419 558691.239 173734.838 558690.737 173734.240 558690.256 173733.626 558689.797 173732.996 558689.359 173732.351 558688.943 173731.692 558688.550 173731.020 558688.180 173730.335 558687.834 173729.639 558687.512 173728.932 558687.214 173728.215 558686.942 173727.488 558686.694 173726.754 558686.472 173726.012 558686.276 173725.264 558686.106 173724.510 558685.962 173723.752 558685.845 173722.990 558685.754 173722.225 558685.690 173721.459 558685.653 173720.692 558685.642 173719.925 558685.658 173719.159 558685.701 173718.395 558685.771 173717.634 558685.867 173716.876 558685.990 173716.124 558686.139 173715.377 558686.315 173714.636 558686.516 173713.903 558686.743 173713.179 558686.996 173712.464 558687.273 173711.759 558687.576 173711.065 558687.903 173710.382 558688.254 173709.713 558688.629 173709.057 558689.027 173708.415 558689.447 173707.788 558689.890 173707.177 558690.354 173706.583 558690.839 173706.006 558691.345 173705.447 558691.870 173704.907 558692.415 173704.386 558692.979 173703.885 558693.560 173703.405 558694.158 173702.944 558694.770 173702.910 558694.817 173701.016 558693.345 173693.582 558688.127 173693.844 558687.740 173701.270 558692.999</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="be2926d34-4951-9bf8-fdef-250d2c1b54e1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-02-06T14:39:01</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-09-11T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bc1254e0738745eeb42145876885df17</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173216.089 558758.003 173214.294 558758.463 173214.518 558754.991 173217.337 558755.210 173217.044 558759.754 173215.942 558759.645 173216.089 558758.003</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bb3fa3326-ef09-fcf7-aef9-b0a93d62c4dd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-09-11</creationDate>
            <imgeo:LV-publicatiedatum>2025-02-07T16:30:20</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-02-06T14:39:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bc1254e0738745eeb42145876885df17</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173216.089 558758.003 173214.294 558758.463 173214.518 558754.991 173217.337 558755.210 173217.017 558759.743 173215.943 558759.633 173216.089 558758.003</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="bf717bc19-ce0a-217b-d136-ff4364bc4a32">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-08-28</creationDate>
            <imgeo:LV-publicatiedatum>2026-09-01T14:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2026-08-28T12:21:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1cf9bab2efc24ccc834e39e70c1ecf4f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173701.388 559524.882 173701.729 559516.237 173720.967 559516.300 173720.917 559524.139 173701.388 559524.882</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b4b435f87-ce4e-b6de-44e0-be7d41ad4074">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-08-28</creationDate>
            <imgeo:LV-publicatiedatum>2026-09-01T14:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2026-08-28T12:21:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.727dd00f2fb94097bd94fc2de9240750</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173721.335 559498.166 173721.154 559507.680 173701.979 559507.743 173702.149 559499.041 173721.335 559498.166</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">steiger</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Kunstwerkdeel gml:id="b12a48f5f-b3d9-64bd-c23f-e1e6f1b3dd7b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-08-28</creationDate>
            <imgeo:LV-publicatiedatum>2026-09-01T14:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2026-08-28T11:57:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ea65c5551ff54ec9a4edf4b50b6192bc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:MultiSurface xmlns:gml="http://www.opengis.net/gml"><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173642.309 559591.812 173639.232 559596.895 173632.319 559592.740 173634.396 559589.336 173636.207 559590.351 173637.144 559588.742 173642.309 559591.812</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></gml:surfaceMember></gml:MultiSurface></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeKunstwerk">hoogspanningsmast</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:Kunstwerkdeel>
    </cityObjectMember>
</CityModel>