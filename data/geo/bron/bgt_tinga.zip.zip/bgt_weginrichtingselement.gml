<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf2ff0067-b165-fe18-a735-b792a9409d95">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-06T15:45:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5bf6e753a62b4ed6b3a72dbea5a332ef</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">wildrooster</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170685.155 558051.857 170684.842 558053.370 170682.674 558052.920 170682.920 558051.410 170683.078 558050.436 170685.359 558050.875 170685.155 558051.857</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b34c3de93-8686-3a6a-0553-26e3f424a256">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.049e9670a5ab44f1a6adf60f36858a57</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">rooster</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171039.883 559242.385 171037.612 559240.536 171038.117 559239.915 171040.395 559241.770 171039.883 559242.385</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b06266dbb-0eb8-5d3b-bec6-3d6c7cb4a890">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.0e38896201644494a0fca5531996db91</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">balustrade</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171910.483 559961.433 171880.532 559936.476</gml:posList></gml:LineString></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b50a7e9ea-f82c-bf5f-2c2a-e6dbc149f51b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.80ad3b143c2b4d519e03ceaa30c98dae</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">rooster</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171440.563 559577.447 171436.620 559574.138 171438.111 559572.386 171442.023 559575.670 171440.563 559577.447</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b5a2a95f1-5876-882e-fbd6-3a87be107e6f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.adf7eaa2cc81471ea792b920c5d59491</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">rooster</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171042.987 559243.901 171045.295 559245.771 171044.791 559246.392 171042.475 559244.516 171042.987 559243.901</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b845d92c7-68ae-0d89-41b1-0b8f0443eb66">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.e0338d9dd04746339ccc08b92aa2b9b5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">balustrade</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171905.881 559966.956 171875.929 559942.000</gml:posList></gml:LineString></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b80a056ea-b3ea-f0fc-2d36-bc97117ac08d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.e36a5cdf49c3492fb5fd35bf0074f53f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">balustrade</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171440.663 559577.596 171436.458 559574.067</gml:posList></gml:LineString></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b2547b29b-18c3-8304-1ac7-f74f30fbf9fe">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.00ddb181eb9947eca1e0fdd1085f9c20</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173181.610 559854.680 173181.740 559856.170 173180.220 559856.320 173180.110 559854.820 173181.610 559854.680</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bfdc8852b-570d-6b28-e114-3b48bfc313df">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.01eb551cff6044f59c6adb932550bc84</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173408.811 559646.094 173408.921 559647.393 173407.770 559647.491 173407.661 559646.191 173408.811 559646.094</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba695b8a9-283d-9107-d6e5-4c4c9ea6a699">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.03dcc81157454122a3920c7da109a458</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173190.230 559953.210 173188.740 559953.360 173188.600 559951.860 173190.120 559951.710 173190.230 559953.210</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b2e9981c8-5150-2afb-0107-8ad08ad3982c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0949a9a4e6734ebc8bb4f293daa0770c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173180.630 559843.070 173180.710 559844.570 173179.200 559844.690 173179.080 559843.200 173180.630 559843.070</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b0bf3c7e6-5c12-955a-9fa4-e4a1fa882a1f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0d91215205dd4b27a24bfb82e5656142</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173169.220 559734.690 173169.360 559736.120 173167.900 559736.240 173167.730 559734.750 173169.220 559734.690</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba05a1d48-9820-798c-4dc0-c9857f017801">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5de5516eb139471cad11d6e17018f2f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173161.810 559648.450 173161.960 559649.960 173160.460 559650.090 173160.320 559648.580 173161.810 559648.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b634f0e91-ab21-823d-da03-35c58dc404c0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6d5cb5b4d90f46129686cf52df7dd957</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173185.460 559901.820 173185.820 559903.390 173184.330 559903.550 173184.180 559902.040 173185.460 559901.820</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bed7545f4-70c6-daa3-c0ca-2d06a91bd4db">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7018d465ccf747af8fd7a915bba04699</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173151.320 559686.450 173151.460 559687.950 173149.950 559688.100 173149.820 559686.590 173151.320 559686.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bfbfd1e81-f9e3-c591-c9d8-452a52a20c37">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7432f0e6d64946e98940bb8e78a7c8f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173412.201 559630.147 173412.311 559631.446 173411.161 559631.544 173411.051 559630.244 173412.201 559630.147</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b0d7214e8-ae62-4926-c996-50b36f705ac9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.84bbc423724c44b19870e30902b4eb9b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173199.450 559904.390 173199.590 559905.950 173198.080 559906.080 173197.970 559904.570 173199.450 559904.390</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b95d6a0ed-c733-b482-ac85-ca4a1d53eefd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9aab3f2d8ae14f15a3ccb716385dd389</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173411.117 559621.975 173411.227 559623.274 173410.076 559623.372 173409.966 559622.072 173411.117 559621.975</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b1eb4a568-c0ac-d934-fa30-0c8991163336">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c418a7912b4b4c0c83acb3a091502025</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173156.820 559749.010 173156.940 559750.510 173155.440 559750.630 173155.320 559749.130 173156.820 559749.010</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b4f8acdaf-6552-a03d-4661-f888aabfa17d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cf1dd455bf844da39c290a86e1515c37</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173194.517 559844.159 173194.637 559845.659 173193.137 559845.779 173193.027 559844.289 173194.517 559844.159</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bdcb41b55-e983-621a-62a1-f50a2c77ae0e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d00d1293ff6141cd8d514e26e0827a0f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173171.490 559761.120 173169.970 559761.250 173169.860 559759.770 173171.330 559759.630 173171.490 559761.120</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b6940c2aa-13b7-fc3d-b62d-b467dc06e348">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d570322350474885b08bf0e4a0e98c7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173414.175 559645.486 173414.285 559646.786 173413.134 559646.883 173413.024 559645.584 173414.175 559645.486</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc6008a46-5c7a-08ac-ac9d-4af6099e7b3e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e0025ff5a1d34657a1a4d86639abbd18</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173400.033 559623.559 173400.143 559624.858 173398.992 559624.955 173398.882 559623.656 173400.033 559623.559</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bec69b25d-8dc3-68c6-8091-87bc9eb027fa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T10:04:33</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e4d24895c63648c7b4f0e54ea77bb6e2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173148.240 559650.550 173148.410 559652.080 173146.880 559652.220 173146.810 559650.740 173148.240 559650.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb7ef6514-48ba-88b9-806c-0fd044698190">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0e38424679b441979472de9a84fe71f4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173193.480 559832.530 173193.600 559834.040 173192.100 559834.180 173191.970 559832.690 173193.480 559832.530</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b686faa7c-490e-ec64-64db-2f8321419c30">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1424ddbac32f4190a7a74359d0d63fc7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173179.604 559815.097 173179.838 559817.631 173177.348 559817.832 173177.104 559815.349 173179.604 559815.097</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b5b56d682-baa7-6f21-afda-febf0221215a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.145e5b8fdf8941babc2790da1d653bf5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173405.537 559622.828 173405.647 559624.128 173404.496 559624.225 173404.386 559622.925 173405.537 559622.828</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba63dfc39-715e-193f-348e-a57fde5cc34e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1651882578ea4e9c95ab0aca887a460d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173170.198 559746.341 173170.360 559747.830 173168.870 559747.960 173168.720 559746.460 173170.198 559746.341</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bff215eff-2956-bea6-4c81-aa56945f9fb6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.17f8532da1694e759824c67115c5cb04</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173186.910 559915.540 173187.010 559917.110 173185.520 559917.210 173185.450 559915.710 173186.910 559915.540</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b26477ee7-02c9-a1a2-c31b-03b98f1f99d7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T13:18:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1d0bd4d1ac1340f28a214f5e361ce745</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173181.360 559869.030 173181.260 559867.530 173182.730 559867.400 173182.830 559868.900 173181.360 559869.030</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b4f745238-e0cd-0647-75d1-54d517c2ceaa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e88e62a35d847fd839638873fbe4fc6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173201.630 559929.710 173201.770 559931.220 173200.260 559931.360 173200.120 559929.840 173201.630 559929.710</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b243db2a3-dbf5-4ea0-5617-b50a65695c35">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.34089009cfdf4f06bc1a39e497d8de02</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173162.800 559660.100 173162.950 559661.590 173161.410 559661.760 173161.310 559660.230 173162.800 559660.100</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="beaa8404b-0d8c-3770-c68b-ac26138359e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3c36b79c6cda438abbc7c4b3afad22c4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173188.990 559939.030 173189.130 559940.530 173187.620 559940.670 173187.510 559939.190 173188.990 559939.030</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b7fc5a782-3a31-30d7-64c8-895a7b6ff83b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.41b2aba00b804ed99c261e10017c00ba</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173157.880 559761.340 173158.000 559762.860 173156.490 559762.980 173156.360 559761.470 173157.880 559761.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb4618a21-a8b7-7c8b-4fd4-df865072b9b5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.575112dbf5fd4311a5b0b7a92cc42c5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173198.450 559892.760 173198.480 559894.320 173197.070 559894.420 173196.960 559892.910 173198.450 559892.760</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b99a08afa-60a2-d3e1-a84e-3016f31efa8b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5f2631afd30e4e1d86822b29c379afbc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173413.188 559637.361 173413.298 559638.660 173412.147 559638.758 173412.037 559637.458 173413.188 559637.361</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b7d9899d7-1682-1a95-7b46-6104a0206089">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6019cec11fb94e658fa67ee84169e697</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173200.470 559916.080 173200.590 559917.600 173199.100 559917.730 173198.960 559916.210 173200.470 559916.080</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bca4c4809-db0d-e9c5-a269-dd815ba2a065">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6725711295d94e66ad18132541caa4f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173403.246 559646.878 173403.355 559648.178 173402.205 559648.275 173402.095 559646.976 173403.246 559646.878</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b406cca63-c89e-5fd0-9b2c-45c4b751bfbd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.793286eec8284bc98e62ba0b8727b3a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173192.460 559820.800 173192.600 559822.310 173191.090 559822.460 173190.950 559820.960 173192.460 559820.800</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b639e02b8-0a8f-27f6-c720-72b1d43c6288">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7d166757131445529034a98ec1a78b3c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173150.370 559675.040 173150.510 559676.560 173149.010 559676.670 173148.880 559675.170 173150.370 559675.040</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b1a8c86f1-a143-64d7-cbb0-1c8f544aee1b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7dc9aa44d56f487b8d1eb65476554f4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173190.280 559795.480 173190.400 559796.980 173188.900 559797.130 173188.750 559795.600 173190.280 559795.480</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b514c4b49-9791-7c3f-ba4f-d0686fdc3030">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7ea413d9fa1d418288bcd062aa48ae3d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173159.930 559785.600 173160.040 559787.120 173158.540 559787.250 173158.410 559785.720 173159.930 559785.600</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b27564466-a0af-9844-1938-5d20fcf4cf0b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.828313ad672342c88f9ebdbe997e3b81</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173168.240 559722.990 173168.360 559724.480 173166.850 559724.600 173166.760 559723.090 173168.240 559722.990</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb0e3747d-4c59-3c9b-eb3e-03602613faae">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.85453fe71912487a863b08b79e27da4e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173149.390 559663.850 173149.510 559665.370 173148.030 559665.490 173147.900 559664.000 173149.390 559663.850</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="be5de4f3f-0d75-530f-1640-5b62f76fb35a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T12:03:10</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8c178311e3094dbb85c7165bf2338da6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173158.860 559773.120 173159.000 559774.630 173157.500 559774.760 173157.380 559773.270 173158.860 559773.120</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b963cc435-63f8-e7d8-4c8d-f32c1ca0b059">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.906fef74cb1e41e1bee6c7c548b85512</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173152.420 559699.000 173152.520 559700.510 173151.050 559700.640 173150.930 559699.150 173152.420 559699.000</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bd15149b3-2293-2c1b-837f-838b3b8ae565">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9d4891caefef44ff99070acd247d759e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173197.120 559877.670 173197.240 559879.160 173195.760 559879.300 173195.600 559877.800 173197.120 559877.670</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc8d919ea-d9c6-b8b1-e26e-1d0d30a42307">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ad14c04f71dc4a638fcde933fb22c40e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173155.780 559736.700 173155.900 559738.180 173154.410 559738.330 173154.300 559736.840 173155.780 559736.700</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b465207f5-b4e9-f696-e860-bf15c3d34231">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b2e0449ecf404e1096c8a3bccb5fe63a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173179.614 559831.582 173179.750 559833.000 173178.230 559833.100 173178.110 559831.620 173179.614 559831.582</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf09c50ec-89fc-c981-5736-9210b375ce59">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bb65d221af9a475984497066eea25e85</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173191.450 559809.250 173191.600 559810.750 173190.090 559810.870 173189.960 559809.370 173191.450 559809.250</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b70d1aa91-9a57-b088-9b32-04e0b8b6e0d5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.db7be2dda1e347ed9bf95ca7d1a39973</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173401.171 559631.619 173401.281 559632.918 173400.130 559633.016 173400.020 559631.716 173401.171 559631.619</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc3cb17c3-d291-c5e3-0ca1-e29eb8459dff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dc6f4814062c48118222faa1f01d7826</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173187.990 559927.230 173188.090 559928.760 173186.630 559928.850 173186.460 559927.380 173187.990 559927.230</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf49a6eac-2904-dd3a-8f53-a04668aefd99">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e3306f64380e4e39b95ffab69d8f1366</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173402.132 559638.804 173402.242 559640.103 173401.091 559640.201 173400.982 559638.901 173402.132 559638.804</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b3f34bf90-bd69-44ea-26d2-a71f823d2df0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ea9df2bb4bdc4718a1fb5ecd046b05c6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173167.050 559709.220 173167.200 559710.740 173165.690 559710.870 173165.560 559709.360 173167.050 559709.220</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc77a9fab-6f43-7a3c-f3c6-4ce7de3bc9f6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.eb7d3a68456541d5899836911388d765</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173160.830 559636.660 173160.960 559638.170 173159.470 559638.290 173159.340 559636.780 173160.830 559636.660</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b2bd6b2a3-0304-1a3b-a1b3-ed7851b3bc69">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ee8dd75853ee4aaca19f49912c10b4c8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173164.130 559675.900 173164.280 559677.410 173162.780 559677.550 173162.640 559676.030 173164.130 559675.900</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bfd17b535-887e-7afa-b8c3-0ff896583ed3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f124a8099d4a46918379e727168e06bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173158.310 559624.730 173159.880 559624.610 173159.922 559625.507 173159.950 559626.100 173158.450 559626.230 173158.310 559624.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b790eac91-24b2-416a-ff76-4aabd96cf406">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.07c173631f4444b6ac4191b3ef3e9957</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">geleideconstructie</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172858.374 558193.180 172858.794 558199.272 172859.255 558211.236 172859.251 558223.265 172858.867 558231.281 172858.087 558243.149 172857.546 558249.721 172856.446 558263.078 172855.932 558267.096 172854.867 558273.185</gml:posList></gml:LineString></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b0c319adf-b493-0965-80db-24d0a4e49cc5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.523ce8f6815e4f46a6c885877df26ad7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">geleideconstructie</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172866.515 558328.032 172867.903 558331.175 172869.393 558334.940 172870.650 558338.697 172871.851 558342.453 172872.876 558346.346 172873.684 558350.713 172874.332 558354.211 172874.890 558358.190 172875.283 558362.143 172877.764 558390.054 172878.561 558399.130 172879.866 558413.984 172881.704 558433.898 172882.697 558445.835 172883.032 558449.336 172883.456 558453.762 172883.587 558454.959 172883.718 558456.153 172884.329 558461.722 172885.354 558469.668 172886.692 558477.560 172887.984 558485.471 172889.112 558493.334 172890.097 558501.267 172891.900 558521.725 172894.247 558547.355 172894.786 558553.242 172897.112 558580.941 172898.199 558592.882 172898.811 558600.872 172899.269 558608.829 172899.492 558616.811 172899.364 558624.869 172898.951 558635.420</gml:posList></gml:LineString></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b8b6acc81-1472-3a99-4915-da1c500ab3e9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.00ddb181eb9947eca1e0fdd1085f9c20</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173181.610 559854.680 173181.740 559856.170 173180.220 559856.320 173180.110 559854.820 173181.610 559854.680</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b8f1c048c-581b-7348-4027-8ddab1e886c3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.03dcc81157454122a3920c7da109a458</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173190.230 559953.210 173188.740 559953.360 173188.600 559951.860 173190.120 559951.710 173190.230 559953.210</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b0f632a6b-ae10-378b-d990-dea5aef73ab1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0949a9a4e6734ebc8bb4f293daa0770c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173180.630 559843.070 173180.710 559844.570 173179.200 559844.690 173179.080 559843.200 173180.630 559843.070</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bd7c5b6e2-ab4a-46cb-d9f9-0b4c5267dc59">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0d91215205dd4b27a24bfb82e5656142</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173169.220 559734.690 173169.360 559736.120 173167.900 559736.240 173167.730 559734.750 173169.220 559734.690</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bd7b6fe97-c2be-d4c7-8981-71b0b055ce9e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0e38424679b441979472de9a84fe71f4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173193.480 559832.530 173193.600 559834.040 173192.100 559834.180 173191.970 559832.690 173193.480 559832.530</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b9888677f-b095-2c85-2cda-293741a92e6e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1424ddbac32f4190a7a74359d0d63fc7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173179.604 559815.097 173179.838 559817.631 173177.348 559817.832 173177.104 559815.349 173179.604 559815.097</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b4c51afe8-c123-27b8-194f-737ad2dffb1f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1651882578ea4e9c95ab0aca887a460d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173170.198 559746.341 173170.360 559747.830 173168.870 559747.960 173168.720 559746.460 173170.198 559746.341</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b82ca80fd-ea71-9a14-750c-42f1c8528973">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.17f8532da1694e759824c67115c5cb04</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173186.910 559915.540 173187.010 559917.110 173185.520 559917.210 173185.450 559915.710 173186.910 559915.540</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bdfac49c8-f8b3-6895-76ec-48e58100db2e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T13:18:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.1d0bd4d1ac1340f28a214f5e361ce745</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173181.360 559869.030 173181.260 559867.530 173182.730 559867.400 173182.830 559868.900 173181.360 559869.030</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bdb4322d1-2d0e-2930-21b6-0fc70b2c2a12">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e88e62a35d847fd839638873fbe4fc6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173201.630 559929.710 173201.770 559931.220 173200.260 559931.360 173200.120 559929.840 173201.630 559929.710</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bfb722185-a2f6-3b27-538b-8996f344b913">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.34089009cfdf4f06bc1a39e497d8de02</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173162.800 559660.100 173162.950 559661.590 173161.410 559661.760 173161.310 559660.230 173162.800 559660.100</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc217b5e4-f4a2-3f2d-6296-e278ec375b37">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3c36b79c6cda438abbc7c4b3afad22c4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173188.990 559939.030 173189.130 559940.530 173187.620 559940.670 173187.510 559939.190 173188.990 559939.030</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf3a70ab7-df36-2e67-7700-5d660111924f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.41b2aba00b804ed99c261e10017c00ba</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173157.880 559761.340 173158.000 559762.860 173156.490 559762.980 173156.360 559761.470 173157.880 559761.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b2937597b-3522-b225-125d-701c5e48907b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.575112dbf5fd4311a5b0b7a92cc42c5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173198.450 559892.760 173198.480 559894.320 173197.070 559894.420 173196.960 559892.910 173198.450 559892.760</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bbbac1b8f-66b1-055f-0ace-05f3c7faca4d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5de5516eb139471cad11d6e17018f2f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173161.810 559648.450 173161.960 559649.960 173160.460 559650.090 173160.320 559648.580 173161.810 559648.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b86b9758b-31d9-cfd7-63e7-a73a6f6bd86b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6019cec11fb94e658fa67ee84169e697</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173200.470 559916.080 173200.590 559917.600 173199.100 559917.730 173198.960 559916.210 173200.470 559916.080</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb4358a9c-b408-739b-6514-a8c161acbba3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6d5cb5b4d90f46129686cf52df7dd957</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173185.460 559901.820 173185.820 559903.390 173184.330 559903.550 173184.180 559902.040 173185.460 559901.820</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b296539d3-bc20-e14f-9427-780ff2f986b2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7018d465ccf747af8fd7a915bba04699</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173151.320 559686.450 173151.460 559687.950 173149.950 559688.100 173149.820 559686.590 173151.320 559686.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb2168fda-d196-c578-4679-83438f10269d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.793286eec8284bc98e62ba0b8727b3a7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173192.460 559820.800 173192.600 559822.310 173191.090 559822.460 173190.950 559820.960 173192.460 559820.800</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b74d5068a-4e46-c01c-4c21-bae39fe58cfd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7d166757131445529034a98ec1a78b3c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173150.370 559675.040 173150.510 559676.560 173149.010 559676.670 173148.880 559675.170 173150.370 559675.040</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b8e27485b-4f01-1198-1c18-65508f5f0353">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7dc9aa44d56f487b8d1eb65476554f4d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173190.280 559795.480 173190.400 559796.980 173188.900 559797.130 173188.750 559795.600 173190.280 559795.480</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b94643ab3-d1ff-3bff-6e65-e76252400314">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7ea413d9fa1d418288bcd062aa48ae3d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173159.930 559785.600 173160.040 559787.120 173158.540 559787.250 173158.410 559785.720 173159.930 559785.600</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba7185975-65d7-8d21-d8c2-42f822c0b3b0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.828313ad672342c88f9ebdbe997e3b81</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173168.240 559722.990 173168.360 559724.480 173166.850 559724.600 173166.760 559723.090 173168.240 559722.990</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b3d8e7ebe-5d17-933d-a382-c1a4079e8283">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.84bbc423724c44b19870e30902b4eb9b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173199.450 559904.390 173199.590 559905.950 173198.080 559906.080 173197.970 559904.570 173199.450 559904.390</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b4a4f18b3-9dc8-a67a-3956-4e22bcda42e5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.85453fe71912487a863b08b79e27da4e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173149.390 559663.850 173149.510 559665.370 173148.030 559665.490 173147.900 559664.000 173149.390 559663.850</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bdafc71e0-6dc0-b204-141d-94dba307b61a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T12:03:10</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8c178311e3094dbb85c7165bf2338da6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173158.860 559773.120 173159.000 559774.630 173157.500 559774.760 173157.380 559773.270 173158.860 559773.120</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf27362ad-570f-9750-df39-72a8bff0767a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.906fef74cb1e41e1bee6c7c548b85512</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173152.420 559699.000 173152.520 559700.510 173151.050 559700.640 173150.930 559699.150 173152.420 559699.000</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba3c3d38b-0084-f095-de7b-0660fcf9ff3e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9d4891caefef44ff99070acd247d759e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173197.120 559877.670 173197.240 559879.160 173195.760 559879.300 173195.600 559877.800 173197.120 559877.670</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b08405d9d-26ca-666e-e857-3f4f5df1a61a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ad14c04f71dc4a638fcde933fb22c40e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173155.780 559736.700 173155.900 559738.180 173154.410 559738.330 173154.300 559736.840 173155.780 559736.700</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b8322f740-fb6c-fbb6-bd20-07ef5949111c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b2e0449ecf404e1096c8a3bccb5fe63a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173179.614 559831.582 173179.750 559833.000 173178.230 559833.100 173178.110 559831.620 173179.614 559831.582</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b6e1e22b9-252a-d8e3-ddbd-95524f5f574b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:46</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bb65d221af9a475984497066eea25e85</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173191.450 559809.250 173191.600 559810.750 173190.090 559810.870 173189.960 559809.370 173191.450 559809.250</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b7b3f6f84-95a2-565d-5625-340e72079213">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c418a7912b4b4c0c83acb3a091502025</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173156.820 559749.010 173156.940 559750.510 173155.440 559750.630 173155.320 559749.130 173156.820 559749.010</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b877a0810-19f7-5259-15d2-8e22d5c30dec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:14:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cf1dd455bf844da39c290a86e1515c37</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173194.517 559844.159 173194.637 559845.659 173193.137 559845.779 173193.027 559844.289 173194.517 559844.159</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b41b666f7-ea87-39b2-d4f5-7f587413fa94">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:42</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d00d1293ff6141cd8d514e26e0827a0f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173171.490 559761.120 173169.970 559761.250 173169.860 559759.770 173171.330 559759.630 173171.490 559761.120</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb3d9558a-daeb-f728-1d46-08ac91f4cd98">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:18:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.dc6f4814062c48118222faa1f01d7826</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173187.990 559927.230 173188.090 559928.760 173186.630 559928.850 173186.460 559927.380 173187.990 559927.230</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf9f79d64-71ed-2abe-00d1-403bd718618b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T10:04:33</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e4d24895c63648c7b4f0e54ea77bb6e2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173148.240 559650.550 173148.410 559652.080 173146.880 559652.220 173146.810 559650.740 173148.240 559650.550</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b308047e2-1b61-bbc1-b0a6-1fe55798d1a0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ea9df2bb4bdc4718a1fb5ecd046b05c6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173167.050 559709.220 173167.200 559710.740 173165.690 559710.870 173165.560 559709.360 173167.050 559709.220</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b5811e1ae-81de-efa3-216e-e9e5dcaab3a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.eb7d3a68456541d5899836911388d765</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173160.830 559636.660 173160.960 559638.170 173159.470 559638.290 173159.340 559636.780 173160.830 559636.660</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b51a60249-99bc-65b8-7c66-fbba0ff1d23d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ee8dd75853ee4aaca19f49912c10b4c8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173164.130 559675.900 173164.280 559677.410 173162.780 559677.550 173162.640 559676.030 173164.130 559675.900</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc659eb5a-da6b-7c0b-3e86-b5b156aae474">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2017-02-10</terminationDate>
            <imgeo:LV-publicatiedatum>2018-01-29T16:38:14</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-02-10T09:58:44</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:23:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f124a8099d4a46918379e727168e06bb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173158.310 559624.730 173159.880 559624.610 173159.922 559625.507 173159.950 559626.100 173158.450 559626.230 173158.310 559624.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b86afe868-b402-fed2-310e-528dcdafa086">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.01eb551cff6044f59c6adb932550bc84</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173408.811 559646.094 173408.921 559647.393 173407.770 559647.491 173407.661 559646.191 173408.811 559646.094</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b9c4cef6a-d128-bb3a-a7e0-c2c23959082b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.145e5b8fdf8941babc2790da1d653bf5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173405.537 559622.828 173405.647 559624.128 173404.496 559624.225 173404.386 559622.925 173405.537 559622.828</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b962f7243-fa9d-5604-369c-b85bc93b147a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5f2631afd30e4e1d86822b29c379afbc</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173413.188 559637.361 173413.298 559638.660 173412.147 559638.758 173412.037 559637.458 173413.188 559637.361</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b14aa7c3e-880f-f6d5-8312-a5cbe64c6e9f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6725711295d94e66ad18132541caa4f1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173403.246 559646.878 173403.355 559648.178 173402.205 559648.275 173402.095 559646.976 173403.246 559646.878</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b0d48ca20-c3b6-e96c-22d8-bcc0773d5c95">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7432f0e6d64946e98940bb8e78a7c8f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173412.201 559630.147 173412.311 559631.446 173411.161 559631.544 173411.051 559630.244 173412.201 559630.147</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b3ccc9e01-1e2d-b20a-a0bf-e738fed609d7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9aab3f2d8ae14f15a3ccb716385dd389</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173411.117 559621.975 173411.227 559623.274 173410.076 559623.372 173409.966 559622.072 173411.117 559621.975</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b5e20c3b7-fa0e-e340-7cc7-1727baff0414">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d570322350474885b08bf0e4a0e98c7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173414.175 559645.486 173414.285 559646.786 173413.134 559646.883 173413.024 559645.584 173414.175 559645.486</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bd4affaaf-97c8-7c7b-844a-9c8e74db65f2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.db7be2dda1e347ed9bf95ca7d1a39973</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173401.171 559631.619 173401.281 559632.918 173400.130 559633.016 173400.020 559631.716 173401.171 559631.619</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b7f1e2f1d-62ab-2211-3aa1-c20d337c9f42">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e0025ff5a1d34657a1a4d86639abbd18</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173400.033 559623.559 173400.143 559624.858 173398.992 559624.955 173398.882 559623.656 173400.033 559623.559</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bc2cfbe2d-1972-691f-8fdc-921eb02a5a0e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</terminationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2019-06-24T12:13:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-27T15:07:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e3306f64380e4e39b95ffab69d8f1366</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173402.132 559638.804 173402.242 559640.103 173401.091 559640.201 173400.982 559638.901 173402.132 559638.804</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bef4df2f8-ba0f-2613-dcea-12abb6fd6884">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-24T12:19:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.478f659ef31f4f9d9da68ed4b8f5909f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173411.284 559639.740 173411.067 559637.787 173412.857 559637.516 173413.128 559639.523 173411.284 559639.740</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bd82f096e-65a0-d9c9-27f1-c406bf0d76d4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-24T12:21:30.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.550e0f4f43364847abeda19756139442</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173404.396 559623.740 173404.125 559621.896 173406.186 559621.517 173406.403 559623.469 173404.396 559623.740</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bba9f9355-9d4f-9763-9840-aaa0699bb2cf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-24T12:20:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9222b980f6db41848136b4858caf2b91</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173401.521 559636.757 173401.359 559634.750 173403.203 559634.533 173403.420 559636.486 173401.521 559636.757</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bef807f30-1714-b549-e6db-ba9e00ae6679">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-24T12:19:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.993abf1d81104a1da9cd10c54066c87b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173407.596 559647.875 173407.379 559646.031 173409.114 559645.760 173409.331 559647.712 173407.596 559647.875</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b1369f726-b163-3100-d748-1b2546bf92c1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-06-24</creationDate>
            <imgeo:LV-publicatiedatum>2019-10-02T16:53:21</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-06-24T12:21:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e018c0fb4c5849958a683bc1f65d322a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173410.199 559631.876 173409.982 559630.086 173411.772 559629.760 173412.043 559631.659 173410.199 559631.876</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b11a6012b-3d5d-a3bd-18c2-ee2c5949ed5e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-05-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-01-27</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-01-27T10:19:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-09T09:48:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.31773aefef754502a88ee05eb3d5af10</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173099.570 559300.854 173099.899 559300.651 173100.247 559300.727 173100.489 559300.981 173100.494 559301.435 173100.267 559301.692 173099.881 559301.692 173099.645 559301.583 173099.485 559301.231 173099.570 559300.854</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b84344861-e304-501a-0ddf-2b8f522a50ce">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-05-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-01-27</terminationDate>
            <imgeo:LV-publicatiedatum>2023-02-02T17:18:15</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-01-27T10:19:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-09T09:48:22.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.31773aefef754502a88ee05eb3d5af10</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173099.570 559300.854 173099.899 559300.651 173100.247 559300.727 173100.489 559300.981 173100.494 559301.435 173100.267 559301.692 173099.881 559301.692 173099.645 559301.583 173099.485 559301.231 173099.570 559300.854</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="ba5565d8a-0036-1907-59f5-a23803d297e0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-05-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-01-27</terminationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-01-27T10:19:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-09T09:48:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d2dee9509f9d4711b27acc8451b98ed0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173098.847 559287.450 173099.176 559287.247 173099.533 559287.315 173099.767 559287.577 173099.754 559287.963 173099.545 559288.289 173099.158 559288.289 173098.923 559288.179 173098.763 559287.827 173098.847 559287.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b634fb2cf-b9b4-ccdb-21fa-c1bc4d7e694b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-05-09</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-01-27</terminationDate>
            <imgeo:LV-publicatiedatum>2023-02-02T17:18:15</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-01-27T10:19:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-09T09:48:21.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d2dee9509f9d4711b27acc8451b98ed0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173098.847 559287.450 173099.176 559287.247 173099.533 559287.315 173099.767 559287.577 173099.754 559287.963 173099.545 559288.289 173099.158 559288.289 173098.923 559288.179 173098.763 559287.827 173098.847 559287.450</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bcb44bf2d-26d3-a96c-e75e-eb16c886ff94">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2018-05-09</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-09T10:06:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.78877e4cb11740c5b5fbf47fb5f3ae6c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173869.049 559055.203 173869.136 559055.089 173869.251 559055.001 173869.384 559054.946 173869.527 559054.927 173869.670 559054.946 173869.804 559055.001 173869.918 559055.089 173870.006 559055.203 173870.061 559055.336 173870.080 559055.480 173870.061 559055.623 173870.006 559055.756 173869.918 559055.870 173869.804 559055.958 173869.670 559056.013 173869.527 559056.032 173869.384 559056.013 173869.251 559055.958 173869.136 559055.870 173869.049 559055.756 173868.993 559055.623 173868.975 559055.480 173868.993 559055.336 173869.049 559055.203</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf0d04764-1334-453e-0d74-702973ef9507">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-17</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-22T20:53:55</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-17T14:08:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a39b7c9bcb5c417c806b522c714ee6f8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173843.759 559135.774 173843.340 559134.857 173844.635 559134.289 173845.062 559135.221 173843.759 559135.774</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bf7fdf832-4755-8cf7-c5ec-7b78480de37c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-17</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-22T20:53:55</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-17T14:08:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b830c0f39888495fb39abc9ecb370ae6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173856.061 559172.665 173855.730 559173.534 173854.687 559173.092 173855.050 559172.223 173856.061 559172.665</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="bb769dac1-c92c-fd3e-6d78-f4a7c00dd18f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-17</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-22T20:53:55</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-17T14:08:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ce4e8f7b88564751823339dd1db8bf7d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173834.566 559147.535 173834.187 559148.467 173833.081 559147.946 173833.508 559147.061 173834.566 559147.535</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Weginrichtingselement gml:id="b689df8be-0d6a-7b9e-5ab7-9e0aa321b5a5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-09-17</creationDate>
            <imgeo:LV-publicatiedatum>2020-10-22T20:53:55</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-09-17T14:08:23.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ec23e01024ee4d388534f3272c2d1a86</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichting">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeWeginrichtingPlus">boomspiegel</imgeo:plus-type>
            <imgeo:geometrie2dWeginrichtingselement><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173840.287 559167.175 173840.919 559165.879 173841.977 559166.401 173841.392 559167.649 173840.287 559167.175</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dWeginrichtingselement>
        </imgeo:Weginrichtingselement>
    </cityObjectMember>
</CityModel>