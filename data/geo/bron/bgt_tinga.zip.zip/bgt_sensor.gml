<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Sensor gml:id="b29018470-cf07-7ba2-459c-c0380b671e6a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.6676e14b8f90467f93dbc35442e1a26f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensor">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensorPlus">detectielus</imgeo:plus-type>
            <imgeo:geometrie2dSensor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172903.668 558677.686 172906.327 558677.128 172906.402 558677.122 172910.094 558676.806 172910.825 558676.744 172910.838 558677.139 172912.612 558676.955 172912.785 558678.454 172911.000 558678.638 172910.838 558677.139</gml:posList></gml:LineString></imgeo:geometrie2dSensor>
        </imgeo:Sensor>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Sensor gml:id="b6ba210c1-4294-f913-8a9a-d2c696776ba4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.66a15f46d0dc4bdca7ddbe4344c2d1f2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensor">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensorPlus">detectielus</imgeo:plus-type>
            <imgeo:geometrie2dSensor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172907.259 558676.482 172909.077 558676.293 172908.931 558674.799 172907.135 558674.977 172907.259 558676.482 172907.274 558676.660 172906.367 558676.724 172906.295 558676.729 172903.668 558677.686</gml:posList></gml:LineString></imgeo:geometrie2dSensor>
        </imgeo:Sensor>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Sensor gml:id="bea9eb4f2-9409-b6f8-0d40-f1201eea9726">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.8b28666e3ba6468e9146c8272672367a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensor">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensorPlus">detectielus</imgeo:plus-type>
            <imgeo:geometrie2dSensor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172903.668 558677.686 172906.344 558677.332 172906.419 558677.326 172907.326 558677.250 172907.372 558677.451 172909.183 558677.282 172909.311 558678.765 172907.512 558678.945 172907.372 558677.451</gml:posList></gml:LineString></imgeo:geometrie2dSensor>
        </imgeo:Sensor>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Sensor gml:id="bd497ccf8-eb1a-2b7a-b7cf-92cebcf92331">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-20T18:48:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-12-20T15:18:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>P0021.fe8b935eb3e14f9aad194f8218357f8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>P0021</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensor">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeSensorPlus">detectielus</imgeo:plus-type>
            <imgeo:geometrie2dSensor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172903.668 558677.686 172906.292 558676.929 172906.384 558676.922 172910.078 558676.643 172910.816 558676.588 172910.759 558676.191 172910.646 558674.670 172912.388 558674.504 172912.543 558675.976 172910.759 558676.191</gml:posList></gml:LineString></imgeo:geometrie2dSensor>
        </imgeo:Sensor>
    </cityObjectMember>
</CityModel>