<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="be5e70800-541e-9fc9-426c-697319f7949a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-23T16:20:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.669d56942a024cd98aeea7d13bf1d534</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171943.697 559595.243 171943.741 559593.165 171943.967 559591.098 171944.374 559589.060 171944.959 559587.065 171945.717 559585.129 171946.643 559583.268 171947.728 559581.495 171948.965 559579.825 171950.344 559578.269 171951.855 559576.842 171953.486 559575.552 171955.223 559574.411 171957.054 559573.427 171958.965 559572.608 171960.940 559571.961 171962.965 559571.489 171965.023 559571.197 171967.099 559571.088 171969.176 559571.161 171971.239 559571.417 171973.272 559571.854 171975.258 559572.467 171977.182 559573.253 171979.030 559574.205 171980.787 559575.316 171982.440 559576.577 171983.975 559577.978 171985.347 559579.477 171986.586 559581.089 171987.681 559582.801 171988.625 559584.600 171989.411 559586.475 171990.033 559588.409 171990.486 559590.391 171990.767 559592.403 171990.875 559594.433 171990.808 559596.464 171990.566 559598.482 171990.152 559600.472 171989.568 559602.418 171988.819 559604.308 171987.911 559606.126 171986.850 559607.859 171985.643 559609.495 171984.301 559611.020 171982.833 559612.425 171981.249 559613.699 171979.561 559614.832 171977.783 559615.815 171975.926 559616.642 171974.006 559617.307 171972.035 559617.804 171970.029 559618.129 171968.002 559618.281 171965.970 559618.259 171963.947 559618.062 171961.949 559617.692 171959.990 559617.151 171958.044 559616.421 171956.169 559615.522 171954.381 559614.462 171952.693 559613.249 171951.118 559611.892 171949.669 559610.402 171948.356 559608.790 171947.190 559607.069 171946.180 559605.253 171945.334 559603.354 171944.658 559601.388 171944.157 559599.371 171943.836 559597.317 171943.697 559595.243</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b49a14de6-2634-578f-3eba-3129c7aa6291">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-23T16:20:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.95d652e1743d46278616871d19360953</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172027.092 559629.297 172027.003 559631.323 172026.739 559633.333 172026.300 559635.312 172025.690 559637.246 172024.914 559639.119 172023.978 559640.918 172022.889 559642.628 172021.654 559644.236 172020.285 559645.731 172018.790 559647.101 172017.181 559648.335 172015.471 559649.425 172013.673 559650.361 172011.800 559651.137 172009.866 559651.746 172007.887 559652.185 172005.876 559652.450 172003.851 559652.538 172001.825 559652.450 171999.815 559652.185 171997.836 559651.746 171995.902 559651.137 171994.029 559650.361 171992.230 559649.425 171990.520 559648.335 171988.912 559647.101 171987.417 559645.731 171986.047 559644.236 171984.813 559642.628 171983.723 559640.918 171982.787 559639.119 171982.011 559637.246 171981.402 559635.312 171980.963 559633.333 171980.698 559631.323 171980.610 559629.297 171980.698 559627.272 171980.963 559625.261 171981.402 559623.282 171982.011 559621.348 171982.787 559619.475 171983.723 559617.677 171984.813 559615.967 171986.047 559614.358 171987.417 559612.863 171988.912 559611.493 171990.520 559610.259 171992.230 559609.170 171994.029 559608.234 171995.902 559607.458 171997.836 559606.848 171999.815 559606.409 172001.825 559606.145 172003.851 559606.056 172005.876 559606.145 172007.887 559606.409 172009.866 559606.848 172011.800 559607.458 172013.673 559608.234 172015.471 559609.170 172017.181 559610.259 172018.790 559611.493 172020.285 559612.863 172021.654 559614.358 172022.889 559615.967 172023.978 559617.677 172024.914 559619.475 172025.690 559621.348 172026.300 559623.282 172026.739 559625.261 172027.003 559627.272 172027.092 559629.297</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b09c35567-9546-e588-83f5-9ac2720e1e94">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-16T10:34:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.91e6b04aed73461a9bc7a876d2e455b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171101.209 559874.832 171100.111 559873.657 171100.915 559872.906 171102.002 559874.091 171101.209 559874.832</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b172f250e-713e-966f-af35-75b7190d9c2b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T13:42:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.9880e3903c6a4cbea3f53b8241950846</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171336.740 558300.630 171338.200 558301.020 171337.810 558302.480 171336.350 558302.090 171336.740 558300.630</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b72d4c1fa-c813-633a-ab8b-929d30266b8a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2018-08-02T11:18:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-14T10:39:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.3710794e8f564a8a8aee504593efe472</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170387.682 558679.004 170393.754 558671.781 170397.158 558674.585 170391.004 558681.773 170387.682 558679.004</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b6afb6f01-6368-4455-18e5-1c3df9f40e34">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2018-08-02T11:18:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-14T10:39:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.44e2479fa49c40a08d7b74dabadcc8af</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170385.394 558673.077 170389.475 558668.181 170392.837 558670.868 170388.778 558675.794 170385.394 558673.077</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bae2f57ff-d53c-1622-4b7d-d085121266db">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2018-08-02T11:18:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-14T10:39:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.8e98a5716bad4f618c96dcf4e045af09</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170367.160 558666.072 170374.590 558672.231 170371.800 558675.597 170364.371 558669.438 170367.160 558666.072</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bbac3b48f-b1d2-ceff-1c20-876946ad6591">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-01-18T13:42:03</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-12-17T13:37:05.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f998f5fe70224c7e8e62121b9f86b582</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171831.816 559813.969 171836.988 559808.079 171844.421 559814.182 171839.347 559820.301 171831.816 559813.969</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">opslagtank</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b557e6b61-3ad5-275b-17d0-af9a6bc3d4ff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-09</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-10-09T23:07:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b096802cf6e65528e0530b29a8c0e7f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170396.616 558681.471 170398.983 558678.692 170401.049 558680.452 170398.683 558683.231 170396.616 558681.471</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b466fee7d-8d30-1afd-a675-98ad209ce7b8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-21</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-21T14:03:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.757c0cb2480540ce852d07c4eda20266</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170261.296 558458.825 170263.221 558459.771 170262.425 558461.681 170260.370 558460.918 170261.167 558458.762 170261.296 558458.825</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="be446b8e5-1213-45c1-1f02-1c91771ca285">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-09-07T10:19:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.127d8a77be4c4f50bacdaac1ab11d3d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172006.907 559665.482 172010.080 559668.355 172008.136 559670.583 172004.035 559666.901 172005.185 559665.526 172006.907 559665.482</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerkPlus">schuur</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bac9dcef3-6cd3-2234-044f-56fb6cd5a7e0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-22T10:36:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.87284601d4d24dafae23303851e85daf</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173680.708 558980.276 173680.513 558978.264 173682.437 558978.090 173682.634 558980.102 173680.708 558980.276</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="beb870224-8c1d-3127-bdf8-2eb96663d083">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2019-11-28</creationDate>
            <imgeo:LV-publicatiedatum>2019-11-28T06:31:12</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2019-11-28T06:17:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.3e5403a03bf24e5ca2e3d6fc0052ae1c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173306.953 558113.358 173306.821 558111.109 173307.086 558108.794 173308.078 558105.685 173310.459 558103.237 173313.700 558101.319 173317.934 558100.790 173320.447 558101.121 173322.564 558101.981 173324.350 558103.105 173326.466 558105.288 173328.186 558108.000 173328.385 558110.976 173328.319 558112.961 173328.186 558114.681 173327.326 558116.533 173326.268 558118.583 173322.895 558121.229 173320.315 558122.486 173317.537 558122.684 173314.428 558122.155 173311.716 558120.898 173309.798 558118.980 173308.144 558116.665 173306.953 558113.358</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">opslagtank</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b62f5895c-8749-9e95-e32f-c9f4625d7c23">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-14T13:12:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.baf685cefe384f29b8bdc489101dd486</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:MultiSurface xmlns:gml="http://www.opengis.net/gml"><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173124.999 559078.810 173123.182 559083.452 173115.800 559080.501 173117.657 559075.856 173124.999 559078.810</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></gml:surfaceMember></gml:MultiSurface></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">overkapping</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b17dbd7c7-77d1-82b4-b9a9-234bc585eacf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-14T13:12:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8932e52dda6349749560f76db41ba59c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:MultiSurface xmlns:gml="http://www.opengis.net/gml"><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173104.782 559127.398 173105.488 559127.893 173106.660 559128.871 173098.925 559138.537 173097.042 559136.919 173104.782 559127.398</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></gml:surfaceMember></gml:MultiSurface></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">overkapping</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bb3a49094-6a7f-bc34-9f1f-e8f3d53fe402">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2024-01-18</creationDate>
            <imgeo:LV-publicatiedatum>2024-02-09T14:07:22</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-18T13:08:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.eea0396ffae04133a1fa4469528cebf3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:MultiSurface xmlns:gml="http://www.opengis.net/gml"><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173251.508 559405.995 173251.858 559412.094 173248.446 559412.289 173248.364 559412.294 173248.015 559406.195 173251.508 559405.995</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></gml:surfaceMember></gml:MultiSurface></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">overkapping</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b559830d8-2324-b7f5-1f6a-c3b281c26992">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-09-14</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-09-14T16:44:08</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T10:31:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7fd568e11d024e868541ed2474069d49</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172787.575 559192.008 172787.290 559190.142 172787.480 559190.115 172789.178 559189.874 172789.382 559189.845 172789.634 559191.742 172787.575 559192.008</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bd09fef14-537f-6e03-4770-64091e524962">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2023-09-14</terminationDate>
            <imgeo:LV-publicatiedatum>2023-09-26T13:21:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-09-14T16:44:08</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-22T10:31:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.7fd568e11d024e868541ed2474069d49</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172787.575 559192.008 172787.290 559190.142 172787.480 559190.115 172789.178 559189.874 172789.382 559189.845 172789.634 559191.742 172787.575 559192.008</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b19410ae7-6f37-e1b8-6575-bc2bc173a2ea">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-27T12:45:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-14T13:11:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a3607052cd2549e6a74efb0c646cf1c0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:MultiSurface xmlns:gml="http://www.opengis.net/gml"><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172947.715 559220.945 172948.649 559231.667 172924.159 559233.779 172923.200 559223.090 172947.715 559220.945</gml:posList></gml:LinearRing></gml:exterior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172943.149 559225.018 172942.139 559225.094 172942.761 559231.906 172943.748 559231.819 172943.149 559225.018</gml:posList></gml:LinearRing></gml:interior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172935.959 559225.669 172934.949 559225.749 172935.278 559229.354 172936.291 559229.276 172935.959 559225.669</gml:posList></gml:LinearRing></gml:interior><gml:interior><gml:LinearRing><gml:posList srsDimension="2">172929.296 559226.247 172928.291 559226.321 172928.613 559229.942 172929.629 559229.839 172929.296 559226.247</gml:posList></gml:LinearRing></gml:interior></gml:Polygon></gml:surfaceMember></gml:MultiSurface></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">overkapping</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="be3f93824-f0cb-a5ad-2f03-8573e492c60a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-22T10:34:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a55e79d7367a454f9075def55c407088</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173022.048 559120.752 173022.149 559122.557 173020.109 559122.670 173020.009 559120.865 173022.048 559120.752</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b14706748-1be1-7df5-a07e-d963de9b36f9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-09-07T10:19:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.061d4c105f0f460e93967cc93c27a849</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172037.282 559639.119 172034.835 559641.703 172031.983 559639.016 172032.996 559637.957 172034.244 559639.117 172042.363 559630.452 172042.065 559630.113 172043.058 559629.057 172043.328 559629.120 172044.461 559629.387 172044.889 559629.897 172045.340 559631.242 172044.376 559632.265 172044.242 559632.161 172044.028 559631.994 172037.282 559639.119</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerkPlus">schuur</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bd1ab8c52-c0a8-2c56-7e63-8234b3cdad02">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-14T14:58:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bd0b391ffea14e65847ff1c3acfbbbb0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172021.590 559677.190 172021.792 559676.282 172022.072 559675.394 172022.428 559674.534 172022.857 559673.709 172023.357 559672.924 172023.924 559672.186 172024.553 559671.500 172025.239 559670.871 172025.977 559670.305 172026.762 559669.805 172027.587 559669.375 172028.447 559669.019 172029.334 559668.739 172030.243 559668.538 172031.166 559668.416 172032.095 559668.376 172033.025 559668.416 172033.948 559668.538 172034.856 559668.739 172035.744 559669.019 172036.603 559669.375 172037.429 559669.805 172038.214 559670.305 172038.952 559670.871 172039.638 559671.500 172040.267 559672.186 172040.833 559672.924 172041.333 559673.709 172041.763 559674.534 172042.119 559675.394 172042.399 559676.282 172042.600 559677.190 172042.722 559678.113 172042.762 559679.042 172042.722 559679.972 172042.600 559680.895 172042.399 559681.803 172042.119 559682.691 172041.763 559683.550 172041.333 559684.376 172040.833 559685.161 172040.267 559685.899 172039.638 559686.585 172038.952 559687.214 172038.214 559687.780 172037.429 559688.280 172036.603 559688.710 172035.744 559689.066 172034.856 559689.346 172033.948 559689.547 172033.025 559689.669 172032.095 559689.709 172031.166 559689.669 172030.243 559689.547 172029.334 559689.346 172028.447 559689.066 172027.587 559688.710 172026.762 559688.280 172025.977 559687.780 172025.239 559687.214 172024.553 559686.585 172023.924 559685.899 172023.357 559685.161 172022.857 559684.376 172022.428 559683.550 172022.072 559682.691 172021.792 559681.803 172021.590 559680.895 172021.469 559679.972 172021.428 559679.042 172021.469 559678.113 172021.590 559677.190</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">opslagtank</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="bb03e051d-d27a-d521-e82d-0592dbdeb94b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2018-11-08T16:11:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-05-14T14:58:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6f3ab3a639204066be146c9d15037a71</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172059.317 559661.678 172059.276 559662.619 172059.153 559663.553 172058.949 559664.473 172058.666 559665.371 172058.306 559666.241 172057.871 559667.076 172057.365 559667.871 172056.791 559668.618 172056.155 559669.312 172055.461 559669.949 172054.713 559670.522 172053.919 559671.028 172053.084 559671.463 172052.213 559671.823 172051.315 559672.107 172050.396 559672.311 172049.462 559672.433 172048.521 559672.475 172047.580 559672.433 172046.646 559672.311 172045.727 559672.107 172044.828 559671.823 172043.958 559671.463 172043.123 559671.028 172042.328 559670.522 172041.581 559669.949 172040.887 559669.312 172040.250 559668.618 172039.677 559667.871 172039.171 559667.076 172038.736 559666.241 172038.376 559665.371 172038.092 559664.473 172037.888 559663.553 172037.766 559662.619 172037.724 559661.678 172037.766 559660.737 172037.888 559659.803 172038.092 559658.884 172038.376 559657.986 172038.736 559657.115 172039.171 559656.280 172039.677 559655.486 172040.250 559654.738 172040.887 559654.044 172041.581 559653.408 172042.328 559652.834 172043.123 559652.328 172043.958 559651.893 172044.828 559651.533 172045.727 559651.250 172046.646 559651.046 172047.580 559650.923 172048.521 559650.882 172049.462 559650.923 172050.396 559651.046 172051.315 559651.250 172052.213 559651.533 172053.084 559651.893 172053.919 559652.328 172054.713 559652.834 172055.461 559653.408 172056.155 559654.044 172056.791 559654.738 172057.365 559655.486 172057.871 559656.280 172058.306 559657.115 172058.666 559657.986 172058.949 559658.884 172059.153 559659.803 172059.276 559660.737 172059.317 559661.678</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">opslagtank</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b9ad962e9-92e4-b121-6427-f0c5a8873675">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:53:07</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-23T16:20:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6aeb60027e9e48e7bb6b0ed5b7bbd430</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172046.677 559634.323 172047.147 559633.981 172047.645 559633.682 172048.167 559633.426 172048.709 559633.216 172049.267 559633.053 172049.837 559632.940 172050.415 559632.876 172050.996 559632.861 172051.576 559632.897 172052.151 559632.983 172052.716 559633.118 172053.268 559633.302 172053.802 559633.532 172054.314 559633.807 172054.800 559634.125 172055.257 559634.484 172055.682 559634.881 172056.070 559635.314 172056.420 559635.778 172056.729 559636.270 172056.994 559636.788 172057.214 559637.326 172057.386 559637.881 172057.510 559638.449 172057.584 559639.025 172057.609 559639.606 172057.583 559640.187 172057.508 559640.763 172057.383 559641.331 172057.209 559641.885 172056.989 559642.423 172056.723 559642.940 172056.413 559643.432 172056.605 559643.543 172055.175 559644.975 172055.049 559644.872 172054.571 559645.202 172054.067 559645.490 172053.540 559645.733 172052.993 559645.929 172052.432 559646.078 172051.860 559646.178 172051.282 559646.229 172050.701 559646.229 172050.123 559646.179 172049.551 559646.080 172048.989 559645.932 172048.443 559645.736 172047.915 559645.493 172047.411 559645.206 172046.933 559644.877 172046.485 559644.507 172046.070 559644.101 172045.692 559643.660 172045.354 559643.188 172045.057 559642.689 172044.805 559642.166 172044.598 559641.624 172044.440 559641.065 172044.329 559640.495 172044.269 559639.918 172044.258 559639.337 172044.297 559638.758 172044.386 559638.184 172044.525 559637.620 172044.711 559637.070 172044.944 559636.539 172045.222 559636.029 172045.543 559635.545 172045.430 559635.359 172046.503 559634.219 172046.677 559634.323</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b29bf3b3a-f258-16f6-e0af-09114dbcdc3d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T12:53:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6aeb60027e9e48e7bb6b0ed5b7bbd430</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172050.483 559646.210 172050.123 559646.179 172049.551 559646.080 172048.989 559645.932 172048.443 559645.736 172047.915 559645.493 172047.411 559645.206 172046.933 559644.877 172046.485 559644.507 172046.070 559644.101 172045.692 559643.660 172045.354 559643.188 172045.057 559642.689 172044.805 559642.166 172044.598 559641.624 172044.440 559641.065 172044.329 559640.495 172044.269 559639.918 172044.258 559639.337 172044.297 559638.758 172044.386 559638.184 172044.525 559637.620 172044.711 559637.070 172044.944 559636.539 172045.222 559636.029 172045.543 559635.545 172045.430 559635.359 172046.181 559634.561 172046.503 559634.219 172046.643 559634.303 172046.677 559634.323 172046.912 559634.152 172047.147 559633.981 172047.645 559633.682 172048.167 559633.426 172048.709 559633.216 172049.267 559633.053 172049.837 559632.940 172050.415 559632.876 172050.996 559632.861 172051.576 559632.897 172052.151 559632.983 172052.716 559633.118 172053.268 559633.302 172053.802 559633.532 172054.314 559633.807 172054.557 559633.966 172054.800 559634.125 172055.257 559634.484 172055.682 559634.881 172056.070 559635.314 172056.420 559635.778 172056.729 559636.270 172056.994 559636.788 172057.214 559637.326 172057.386 559637.881 172057.510 559638.449 172057.584 559639.025 172057.609 559639.606 172057.583 559640.187 172057.508 559640.763 172057.383 559641.331 172057.240 559641.788 172057.209 559641.885 172056.989 559642.423 172056.723 559642.940 172056.413 559643.432 172056.605 559643.543 172055.175 559644.975 172055.049 559644.872 172054.571 559645.202 172054.067 559645.490 172053.540 559645.733 172052.993 559645.929 172052.432 559646.078 172051.860 559646.178 172051.338 559646.224 172051.282 559646.229 172050.701 559646.229 172050.483 559646.210</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="ba813ac0e-d058-43bb-d127-3b3d13afa0de">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-23T16:20:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ee206393c2a74c2bbbd6c10f1e004beb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172054.260 559715.490 172076.920 559691.260 172103.167 559716.619 172103.409 559716.340 172113.623 559726.129 172108.017 559731.966 172106.512 559730.062 172094.691 559742.597 172098.321 559746.141 172101.155 559748.267 172103.944 559749.020 172107.132 559748.755 172109.389 559747.559 172111.205 559745.964 172112.293 559744.129 172113.102 559742.053 172113.127 559739.674 172112.697 559737.674 172111.787 559735.928 172109.611 559733.599 172115.619 559727.226 172117.609 559729.127 172117.895 559729.535 172119.725 559732.148 172120.845 559734.800 172121.444 559737.703 172121.648 559740.539 172121.302 559743.411 172120.584 559746.053 172119.313 559748.607 172117.717 559750.802 172115.993 559752.448 172113.598 559754.178 172110.505 559755.606 172107.179 559756.385 172103.635 559756.624 172100.214 559755.952 172096.909 559754.552 172094.349 559752.756 172091.734 559750.423 172090.279 559749.056 172056.379 559717.480 172054.260 559715.490</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b050cf8ef-7a93-ffc1-2b1e-8949dce1de04">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <imgeo:LV-publicatiedatum>2019-06-19T12:22:35</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2018-09-07T10:19:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.bfbdff6b01964abfb0ca393226ebc926</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172138.078 559849.721 172136.034 559847.837 172135.565 559847.415 172122.393 559835.174 172120.399 559833.321 172120.320 559833.247 172120.243 559833.176 172120.235 559833.042 172120.215 559832.879 172120.238 559832.718 172120.303 559832.568 172120.368 559832.480 172125.552 559826.901 172135.303 559836.046 172138.538 559839.080 172139.470 559839.776 172141.250 559837.948 172149.325 559845.603 172144.133 559850.770 172143.694 559850.360 172141.280 559852.944 172138.078 559849.721</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">niet-bgt</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b34bf0a8b-f5c8-f3f9-b72f-e6af1eac03c2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-23T16:20:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5e5a827508d042688a1cdac8f1074af9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172144.845 559676.892 172144.841 559677.322 172144.830 559677.752 172144.811 559678.181 172144.785 559678.610 172144.751 559679.039 172144.710 559679.466 172144.661 559679.893 172144.605 559680.319 172144.542 559680.744 172144.471 559681.168 172144.392 559681.591 172144.307 559682.012 172144.214 559682.432 172144.113 559682.850 172144.006 559683.266 172143.891 559683.680 172143.769 559684.092 172143.640 559684.502 172143.503 559684.909 172143.360 559685.314 172143.209 559685.717 172143.052 559686.117 172142.887 559686.514 172142.716 559686.908 172142.538 559687.299 172142.353 559687.687 172142.161 559688.072 172141.962 559688.453 172141.757 559688.830 172141.546 559689.204 172141.328 559689.575 172141.103 559689.941 172140.872 559690.304 172140.635 559690.662 172140.392 559691.016 172140.142 559691.366 172139.886 559691.712 172139.625 559692.053 172139.357 559692.389 172139.084 559692.721 172138.805 559693.047 172138.520 559693.369 172138.230 559693.686 172137.934 559693.998 172137.633 559694.304 172137.326 559694.606 172137.014 559694.901 172136.697 559695.192 172136.376 559695.476 172136.049 559695.756 172135.717 559696.029 172135.381 559696.296 172135.040 559696.558 172134.694 559696.814 172134.344 559697.063 172133.990 559697.307 172133.632 559697.544 172133.269 559697.775 172132.903 559697.999 172132.533 559698.218 172132.159 559698.429 172131.781 559698.634 172131.400 559698.833 172131.015 559699.024 172130.627 559699.209 172130.236 559699.388 172129.842 559699.559 172129.445 559699.724 172129.045 559699.881 172128.643 559700.032 172128.237 559700.175 172127.830 559700.311 172127.420 559700.441 172127.008 559700.563 172126.594 559700.677 172126.178 559700.785 172125.760 559700.885 172125.340 559700.978 172124.919 559701.064 172124.497 559701.142 172124.073 559701.213 172123.648 559701.277 172123.222 559701.333 172122.795 559701.382 172122.367 559701.423 172121.938 559701.457 172121.509 559701.483 172121.080 559701.502 172120.650 559701.513 172120.221 559701.517 172119.791 559701.513 172119.361 559701.502 172118.932 559701.483 172118.503 559701.457 172118.075 559701.423 172117.647 559701.382 172117.220 559701.333 172116.794 559701.277 172116.369 559701.213 172115.945 559701.142 172115.522 559701.064 172115.101 559700.978 172114.681 559700.885 172114.264 559700.785 172113.847 559700.677 172113.433 559700.563 172113.021 559700.441 172112.611 559700.311 172112.204 559700.175 172111.799 559700.032 172111.396 559699.881 172110.996 559699.724 172110.599 559699.559 172110.205 559699.388 172109.814 559699.209 172109.426 559699.024 172109.042 559698.833 172108.660 559698.634 172108.283 559698.429 172107.909 559698.218 172107.538 559697.999 172107.172 559697.775 172106.809 559697.544 172106.451 559697.307 172106.097 559697.063 172105.747 559696.814 172105.401 559696.558 172105.061 559696.296 172104.724 559696.029 172104.393 559695.756 172104.066 559695.476 172103.744 559695.192 172103.427 559694.901 172103.115 559694.606 172102.809 559694.304 172102.508 559693.998 172102.212 559693.686 172101.921 559693.369 172101.637 559693.047 172101.357 559692.721 172101.084 559692.389 172100.817 559692.053 172100.555 559691.712 172100.299 559691.366 172100.050 559691.016 172099.806 559690.662 172099.569 559690.304 172099.338 559689.941 172099.114 559689.575 172098.896 559689.204 172098.684 559688.830 172098.479 559688.453 172098.280 559688.072 172098.089 559687.687 172097.904 559687.299 172097.725 559686.908 172097.554 559686.514 172097.390 559686.117 172097.232 559685.717 172097.082 559685.314 172096.938 559684.909 172096.802 559684.502 172096.672 559684.092 172096.550 559683.680 172096.436 559683.266 172096.328 559682.850 172096.228 559682.432 172096.135 559682.012 172096.049 559681.591 172095.971 559681.168 172095.900 559680.744 172095.836 559680.319 172095.780 559679.893 172095.731 559679.466 172095.690 559679.039 172095.657 559678.610 172095.630 559678.181 172095.612 559677.752 172095.600 559677.322 172095.597 559676.892 172095.600 559676.463 172095.612 559676.033 172095.630 559675.604 172095.657 559675.175 172095.690 559674.746 172095.731 559674.319 172095.780 559673.892 172095.836 559673.465 172095.900 559673.040 172095.971 559672.616 172096.049 559672.194 172096.135 559671.773 172096.228 559671.353 172096.328 559670.935 172096.436 559670.519 172096.550 559670.105 172096.672 559669.693 172096.802 559669.283 172096.938 559668.876 172097.082 559668.470 172097.232 559668.068 172097.390 559667.668 172097.554 559667.271 172097.725 559666.877 172097.904 559666.486 172098.089 559666.098 172098.280 559665.713 172098.479 559665.332 172098.684 559664.954 172098.896 559664.580 172099.114 559664.210 172099.338 559663.844 172099.569 559663.481 172099.806 559663.123 172100.050 559662.769 172100.299 559662.419 172100.555 559662.073 172100.817 559661.732 172101.084 559661.396 172101.357 559661.064 172101.637 559660.738 172101.921 559660.416 172102.212 559660.099 172102.508 559659.787 172102.809 559659.481 172103.115 559659.179 172103.427 559658.883 172103.744 559658.593 172104.066 559658.308 172104.393 559658.029 172104.724 559657.756 172105.061 559657.488 172105.401 559657.227 172105.747 559656.971 172106.097 559656.722 172106.451 559656.478 172106.809 559656.241 172107.172 559656.010 172107.538 559655.785 172107.909 559655.567 172108.283 559655.356 172108.660 559655.151 172109.042 559654.952 172109.426 559654.760 172109.814 559654.575 172110.205 559654.397 172110.599 559654.226 172110.996 559654.061 172111.396 559653.904 172111.799 559653.753 172112.204 559653.610 172112.611 559653.474 172113.021 559653.344 172113.433 559653.222 172113.847 559653.107 172114.264 559653.000 172114.681 559652.899 172115.101 559652.806 172115.522 559652.721 172115.945 559652.642 172116.369 559652.571 172116.794 559652.508 172117.220 559652.452 172117.647 559652.403 172118.075 559652.362 172118.503 559652.328 172118.932 559652.302 172119.361 559652.283 172119.791 559652.272 172120.221 559652.268 172120.650 559652.272 172121.080 559652.283 172121.509 559652.302 172121.938 559652.328 172122.367 559652.362 172122.795 559652.403 172123.222 559652.452 172123.648 559652.508 172124.073 559652.571 172124.497 559652.642 172124.919 559652.721 172125.340 559652.806 172125.760 559652.899 172126.178 559653.000 172126.594 559653.107 172127.008 559653.222 172127.420 559653.344 172127.830 559653.474 172128.237 559653.610 172128.643 559653.753 172129.045 559653.904 172129.445 559654.061 172129.842 559654.226 172130.236 559654.397 172130.627 559654.575 172131.015 559654.760 172131.400 559654.952 172131.781 559655.151 172132.159 559655.356 172132.533 559655.567 172132.903 559655.785 172133.269 559656.010 172133.632 559656.241 172133.990 559656.478 172134.344 559656.722 172134.694 559656.971 172135.040 559657.227 172135.381 559657.488 172135.717 559657.756 172136.049 559658.029 172136.376 559658.308 172136.697 559658.593 172137.014 559658.883 172137.326 559659.179 172137.633 559659.481 172137.934 559659.787 172138.230 559660.099 172138.520 559660.416 172138.805 559660.738 172139.084 559661.064 172139.357 559661.396 172139.625 559661.732 172139.886 559662.073 172140.142 559662.419 172140.392 559662.769 172140.635 559663.123 172140.872 559663.481 172141.103 559663.844 172141.328 559664.210 172141.546 559664.580 172141.757 559664.954 172141.962 559665.332 172142.161 559665.713 172142.353 559666.098 172142.538 559666.486 172142.716 559666.877 172142.887 559667.271 172143.052 559667.668 172143.209 559668.068 172143.360 559668.470 172143.503 559668.876 172143.640 559669.283 172143.769 559669.693 172143.891 559670.105 172144.006 559670.519 172144.113 559670.935 172144.214 559671.353 172144.307 559671.773 172144.392 559672.194 172144.471 559672.616 172144.542 559673.040 172144.605 559673.465 172144.661 559673.892 172144.710 559674.319 172144.751 559674.746 172144.785 559675.175 172144.811 559675.604 172144.830 559676.033 172144.841 559676.463 172144.845 559676.892</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">bezinkbak</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigBouwwerk gml:id="b8d62a86d-24b8-ec67-6dfa-0752269d193d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-08-28</creationDate>
            <imgeo:LV-publicatiedatum>2026-09-01T14:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2026-08-28T10:42:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0ea2da93b98543ba9d2e720d4558dfe6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172348.398 559733.354 172347.119 559734.505 172344.833 559731.788 172346.096 559730.669 172348.398 559733.354</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:bgt-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverigBouwwerk">lage trafo</imgeo:bgt-type>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:plus-type>
        </imgeo:OverigBouwwerk>
    </cityObjectMember>
</CityModel>