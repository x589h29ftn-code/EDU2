<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b05eceb60-1f8f-4a72-b85a-64ce83bb9609">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.f082fcd0dc924de4bb6eecd8b917f332</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172437.273 560405.866 172390.294 560366.486 172336.796 560321.912 172218.599 560223.031 172111.481 560133.637 172009.635 560048.435 171925.782 559978.570 171908.351 559963.992</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b0fdd8364-954d-5691-6b31-249b89dbb8b5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T11:27:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.f082fcd0dc924de4bb6eecd8b917f332</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172437.273 560405.866 172390.294 560366.486 172336.796 560321.912 172218.599 560223.031 172111.481 560133.637 172009.635 560048.435 171925.782 559978.570 171903.247 559959.724</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b2af6ff4a-3961-97d8-0715-4383b8d66566">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-05-30T14:08:08</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-05-30T12:33:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.be05535d941b4861ab8e89a9f44cec36</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170995.326 559201.253 170835.435 559067.447 170785.591 559025.848 170731.763 558980.696 170703.379 558957.092 170522.222 558805.568 170280.853 558603.864 170211.298 558545.881 170145.720 558490.971 169973.913 558347.487 169921.089 558303.461 169808.900 558209.699 169739.150 558151.702 169737.798 558150.568</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="bfec38635-b08a-a154-c04a-22742c483dae">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-05-30T12:33:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-15T13:37:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.be05535d941b4861ab8e89a9f44cec36</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171438.786 559571.618 171425.341 559560.428 170995.326 559201.253 170835.435 559067.447 170785.591 559025.848 170731.763 558980.696 170703.379 558957.092 170522.222 558805.568 170280.853 558603.864 170211.298 558545.881 170145.720 558490.971 169973.913 558347.487 169921.089 558303.461 169808.900 558209.699 169739.150 558151.702 169737.080 558149.966</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="bf9bc5f33-fc65-af20-6233-718415f54b3a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-15T13:37:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.17520ecc385845ecbcea2c541740a132</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171442.702 559574.877 171438.786 559571.618</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b76275620-cded-bef7-e05b-df7e4de5092f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.17520ecc385845ecbcea2c541740a132</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171442.858 559575.006 171438.604 559571.467</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b4a4c2678-102d-5a88-8549-b5598fc9689e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-15T13:37:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.d61f4a6c69c34505b28cff4bdf68fcae</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171878.383 559938.932 171762.881 559842.340 171586.218 559694.786 171516.408 559636.345 171503.264 559625.427 171488.941 559613.360 171442.702 559574.877</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="be7d5e08c-a231-9f86-4c01-f8a46d1e8a2d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.d61f4a6c69c34505b28cff4bdf68fcae</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171878.444 559938.983 171762.881 559842.340 171586.218 559694.786 171516.408 559636.345 171503.264 559625.427 171488.941 559613.360 171442.858 559575.006</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="bd3e89e61-644c-e5db-7b04-a7e9146ac5dc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-16T11:42:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9c9e7cc59f7f481aa759e1ff71e3b81b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171903.247 559959.724 171883.453 559943.171 171878.383 559938.932</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b2f90abb3-291f-4fcc-3c47-c0d494ebf6fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.9c9e7cc59f7f481aa759e1ff71e3b81b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171908.351 559963.992 171878.444 559938.983</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b30681c10-c60c-4e3e-57b0-7bbb95974553">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-17T11:55:28</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.be05535d941b4861ab8e89a9f44cec36</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171438.604 559571.467 171425.341 559560.428 170995.326 559201.253 170835.435 559067.447 170785.591 559025.848 170731.763 558980.696 170703.379 558957.092 170522.222 558805.568 170280.853 558603.864 170211.298 558545.881 170145.720 558490.971 169973.913 558347.487 169921.089 558303.461 169808.900 558209.699 169739.150 558151.702 169737.798 558150.568</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
    <cityObjectMember>
        <Railway xmlns="http://www.opengis.net/citygml/transportation/2.0" gml:id="b531985d9-ab19-b8ac-962a-b67950fcd2e4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2011-08-22</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-17T11:55:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.be05535d941b4861ab8e89a9f44cec36</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#FunctieSpoor">trein</function>
            <imgeo:geometrie2dSpoor><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171438.604 559571.467 171425.341 559560.428 171041.134 559239.292 170995.326 559201.253 170835.435 559067.447 170785.591 559025.848 170731.763 558980.696 170703.379 558957.092 170522.222 558805.568 170280.853 558603.864 170211.298 558545.881 170145.720 558490.971 169973.913 558347.487 169921.089 558303.461 169808.900 558209.699 169739.150 558151.702 169737.798 558150.568</gml:posList></gml:LineString></imgeo:geometrie2dSpoor>
            <imgeo:plus-functieSpoor codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue"></imgeo:plus-functieSpoor>
        </Railway>
    </cityObjectMember>
</CityModel>