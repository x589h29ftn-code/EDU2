<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b37446963-3cee-6fcb-e3b1-193f5db382a7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T14:40:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.07b377a9d8984ca29fb5575819c4d38d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171539.252 557861.221 171540.711 557864.551 171542.011 557867.947 171543.150 557871.400 171544.201 557875.211 171545.054 557879.072 171545.708 557882.971 171546.125 557889.622 171546.144 557889.918 171546.160 557890.173 171546.121 557892.169 171546.040 557896.284 171546.029 557896.862 171546.019 557897.389 171545.794 557899.589 171545.507 557902.925 171545.426 557903.199 171545.437 557903.473 171545.415 557903.637 171545.342 557904.019 171545.286 557904.568 171541.891 557925.348 171540.938 557931.184 171539.988 557937.592 171538.480 557949.440 171536.134 557963.761 171535.749 557966.106 171535.611 557966.952 171532.082 557988.487 171530.196 558000.000 171528.020 558013.280 171525.357 558029.337 171522.054 558049.249 171521.800 558050.780 171521.180 558055.922 171519.572 558065.284 171515.097 558068.118</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="baf8dcaf4-3f9f-2065-8885-e5f4e96e62bb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:30:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.14f836b5340746ca8ca11ee84e9d1fec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170507.727 558187.613 170499.547 558186.622 170493.474 558185.788 170446.807 558179.372 170429.103 558172.752 170417.808 558167.960</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b179b5d4d-7640-ace0-c5b2-74f1a8fd74a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-17T07:57:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.47ec88b143654572be6ff806baee6790</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172008.350 559717.069 172000.000 559709.187 171996.643 559706.018 171985.334 559695.515 171984.655 559694.914 171983.210 559693.634 171982.615 559693.106 171981.521 559692.080 171911.778 559626.291 171871.206 559587.950 171865.400 559582.464 171856.449 559574.005 171855.182 559572.859 171853.959 559571.666 171852.780 559570.430 171851.337 559568.780 171849.974 559567.064 171848.693 559565.285 171838.149 559548.526 171835.950 559544.809 171828.938 559526.549 171819.300 559500.000 171818.039 559496.528 171816.603 559492.976 171814.330 559486.250 171812.620 559481.510 171810.630 559476.130 171809.900 559474.540 171808.529 559470.881 171806.986 559466.675 171806.704 559465.907 171804.506 559460.567 171801.805 559454.892 171799.293 559450.495 171797.995 559448.307 171795.330 559443.820 171784.089 559426.611 171772.557 559410.207 171775.921 559410.038</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b36dbf39b-c44e-2a07-e4e2-915b1855b8c8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:44:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.9b287a0ffe6746b090e00d9ba8036872</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171010.422 558008.532 171011.038 558007.379 171024.795 557978.741 171033.227 557961.207 171039.967 557946.925 171050.790 557924.100 171066.800 557891.650 171075.802 557874.479 171078.209 557870.500 171082.103 557867.359 171088.738 557864.805 171095.908 557864.712</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b9feee15c-f431-a86c-06a5-06e0095906f7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:33:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.e82414fc4ad04ad792147fe3e1e505dd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171125.590 558455.635 171129.448 558451.114 171131.619 558449.153 171134.842 558447.174 171138.213 558445.561 171141.107 558444.828 171143.928 558445.085 171148.177 558446.074 171156.017 558448.969 171160.569 558450.490 171167.053 558452.286 171172.036 558453.349 171190.985 558457.380 171207.653 558460.715 171211.390 558461.475 171215.969 558461.402 171217.775 558459.951 171219.342 558458.527 171219.545 558457.917 171219.585 558457.208 171219.530 558454.600 171219.480 558453.920 171219.415 558453.174 171219.373 558452.824 171219.176 558451.155 171218.862 558450.129 171218.443 558449.123 171213.590 558441.160 171213.140 558439.860 171211.970 558435.790 171211.450 558433.010 171211.230 558431.580 171211.220 558429.330 171211.882 558426.304 171216.242 558408.798 171217.762 558401.620 171218.727 558399.552 171220.570 558397.730 171225.235 558395.636 171228.145 558394.694 171232.080 558394.463 171236.749 558394.819 171239.889 558395.385 171246.860 558396.830 171251.800 558398.023 171260.509 558400.306 171267.480 558402.296 171274.765 558404.641 171281.108 558406.400 171287.765 558408.253 171298.462 558411.436 171305.998 558413.907 171309.452 558415.080 171312.069 558415.373 171314.309 558415.415 171316.235 558414.661 171318.391 558413.551 171319.396 558411.730 171320.170 558409.154 171318.039 558398.249 171316.490 558389.200 171316.370 558387.840 171315.385 558384.367 171312.210 558372.174 171310.694 558364.839 171310.133 558354.965 171312.327 558348.726 171314.232 558348.600 171314.808 558348.711 171317.497 558349.229 171319.067 558351.009 171319.804 558354.050 171320.317 558364.494 171320.793 558369.918 171322.442 558376.111 171324.164 558383.038 171325.849 558390.037 171326.508 558393.555 171326.508 558398.393 171326.655 558410.230 171326.728 558416.020 171326.240 558417.610 171325.602 558418.076</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b3ebec9f9-66ad-c0f0-c38a-283e792ee504">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:37</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:42:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.ee322036f3ae4b018b5e1b74428b49de</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170945.560 558211.030 170947.340 558206.109 170947.428 558205.054 170950.861 558191.862 170956.630 558165.929 170959.093 558155.214 170961.772 558144.660 170963.572 558135.550 170964.598 558129.226 170965.289 558122.609 170966.126 558117.144 170967.738 558112.264 170971.096 558105.677 170974.781 558097.971 170978.716 558089.511 170981.781 558082.442 170984.293 558076.621 170988.098 558067.312 170991.594 558057.601 170994.231 558049.665 170999.160 558035.263 171002.345 558026.739 171003.452 558027.213 171005.509 558022.389 171004.354 558022.012 171008.879 558012.626 171009.410 558011.469</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b14f4ac9b-ac1f-67e8-c682-b7b9e93d4b0d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-12-08T10:17:58</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-06-30T13:41:26.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.400a78fd1ceb483cab0b4f11ddd428b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171915.488 559952.934 171924.054 559948.031 171924.551 559947.739 171933.333 559942.563 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171954.644 559929.088 171954.867 559929.308 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171915.488 559952.934</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bb1bcf487-dbc3-a9ac-38c3-d9d11089d807">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2017-12-08T09:30:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-05-19T13:56:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b1356e3f298d444ba2f98b61616e8b38</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.674 559972.731 171877.696 559973.051 171877.324 559973.224 171872.384 559975.515 171871.139 559976.087 171869.154 559976.992 171865.221 559978.781 171858.728 559981.717 171858.605 559981.443 171862.015 559979.913 171865.400 559978.369 171870.631 559975.991 171872.247 559975.251 171877.674 559972.731</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bd0894a1b-1edd-71e1-4ee1-6c9044e7e94a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2cd39e1862ce4447afb54cccc3da2358</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171921.212 559958.386 171915.521 559952.966</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bdb8926c1-4020-47dd-b0b6-26a0dd51bc63">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-08-12</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T14:16:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.38c3ad9270f549738fb8ef148b9eebd0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170364.846 558667.124 170364.513 558667.461</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b6a3e12bc-4c06-9eeb-dd4c-d1d39d92ca9b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2014-07-11T16:40:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.71c5cd511fc64ecd98a22309cf1aa527</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170272.293 558600.020 170267.934 558596.310</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b8f00ba51-1f8b-9c2c-1c98-e214e663217f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2014-07-11T16:40:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b89449a2bf4d4a33b41868cc8cc88645</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171755.697 559839.732 171751.361 559836.127</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b0f1661c8-d8be-15d5-f887-5fe7b7ed1833">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-06T08:35:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:04:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-12-08T10:17:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.400a78fd1ceb483cab0b4f11ddd428b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171915.521 559952.966 171915.488 559952.934 171924.054 559948.031 171924.551 559947.739 171933.353 559942.550 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171954.644 559929.088 171954.867 559929.308 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171915.521 559952.966</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b97eb3c6e-41bf-8ab7-55c0-024c98523334">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2019-06-06T08:35:07</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:06:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-12-08T09:30:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b1356e3f298d444ba2f98b61616e8b38</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.674 559972.731 171877.696 559973.052 171877.324 559973.224 171872.384 559975.515 171871.139 559976.087 171869.154 559976.992 171865.221 559978.781 171858.728 559981.717 171858.605 559981.443 171862.015 559979.913 171865.400 559978.369 171870.631 559975.991 171872.247 559975.251 171877.674 559972.731</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bf6c4b7ea-7aba-4e77-6832-14383bc1bce6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T14:40:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.07b377a9d8984ca29fb5575819c4d38d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171539.252 557861.221 171540.711 557864.551 171542.011 557867.947 171543.150 557871.400 171544.201 557875.211 171545.054 557879.072 171545.708 557882.971 171546.125 557889.622 171546.144 557889.918 171546.160 557890.173 171546.121 557892.169 171546.040 557896.284 171546.029 557896.862 171546.019 557897.389 171545.794 557899.589 171545.507 557902.925 171545.426 557903.199 171545.437 557903.473 171545.415 557903.637 171545.342 557904.019 171545.286 557904.568 171541.891 557925.348 171540.938 557931.184 171539.988 557937.592 171538.480 557949.440 171536.134 557963.761 171535.749 557966.106 171535.611 557966.952 171532.082 557988.487 171530.196 558000.000 171528.020 558013.280 171525.357 558029.337 171522.054 558049.249 171521.800 558050.780 171521.180 558055.922 171519.572 558065.284 171515.097 558068.118</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b55aae9c4-51f4-f092-de8e-28b9da6faff0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:38</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:30:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.14f836b5340746ca8ca11ee84e9d1fec</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170507.727 558187.613 170499.547 558186.622 170493.474 558185.788 170446.807 558179.372 170429.103 558172.752 170417.808 558167.960</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba11226a9-76c9-babb-c98b-b0754dc35c32">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-17T07:57:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.47ec88b143654572be6ff806baee6790</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172008.350 559717.069 172000.000 559709.187 171996.643 559706.018 171985.334 559695.515 171984.655 559694.914 171983.210 559693.634 171982.615 559693.106 171981.521 559692.080 171911.778 559626.291 171871.206 559587.950 171865.400 559582.464 171856.449 559574.005 171855.182 559572.859 171853.959 559571.666 171852.780 559570.430 171851.337 559568.780 171849.974 559567.064 171848.693 559565.285 171838.149 559548.526 171835.950 559544.809 171828.938 559526.549 171819.300 559500.000 171818.039 559496.528 171816.603 559492.976 171814.330 559486.250 171812.620 559481.510 171810.630 559476.130 171809.900 559474.540 171808.529 559470.881 171806.986 559466.675 171806.704 559465.907 171804.506 559460.567 171801.805 559454.892 171799.293 559450.495 171797.995 559448.307 171795.330 559443.820 171784.089 559426.611 171772.557 559410.207 171775.921 559410.038</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bfa145884-cc41-ebc0-00a2-b46244933334">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:39</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:44:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.9b287a0ffe6746b090e00d9ba8036872</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171010.422 558008.532 171011.038 558007.379 171024.795 557978.741 171033.227 557961.207 171039.967 557946.925 171050.790 557924.100 171066.800 557891.650 171075.802 557874.479 171078.209 557870.500 171082.103 557867.359 171088.738 557864.805 171095.908 557864.712</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba0a64447-ab57-1f74-91e7-3179e54e9e75">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:33:33.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.e82414fc4ad04ad792147fe3e1e505dd</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171125.590 558455.635 171129.448 558451.114 171131.619 558449.153 171134.842 558447.174 171138.213 558445.561 171141.107 558444.828 171143.928 558445.085 171148.177 558446.074 171156.017 558448.969 171160.569 558450.490 171167.053 558452.286 171172.036 558453.349 171190.985 558457.380 171207.653 558460.715 171211.390 558461.475 171215.969 558461.402 171217.775 558459.951 171219.342 558458.527 171219.545 558457.917 171219.585 558457.208 171219.530 558454.600 171219.480 558453.920 171219.415 558453.174 171219.373 558452.824 171219.176 558451.155 171218.862 558450.129 171218.443 558449.123 171213.590 558441.160 171213.140 558439.860 171211.970 558435.790 171211.450 558433.010 171211.230 558431.580 171211.220 558429.330 171211.882 558426.304 171216.242 558408.798 171217.762 558401.620 171218.727 558399.552 171220.570 558397.730 171225.235 558395.636 171228.145 558394.694 171232.080 558394.463 171236.749 558394.819 171239.889 558395.385 171246.860 558396.830 171251.800 558398.023 171260.509 558400.306 171267.480 558402.296 171274.765 558404.641 171281.108 558406.400 171287.765 558408.253 171298.462 558411.436 171305.998 558413.907 171309.452 558415.080 171312.069 558415.373 171314.309 558415.415 171316.235 558414.661 171318.391 558413.551 171319.396 558411.730 171320.170 558409.154 171318.039 558398.249 171316.490 558389.200 171316.370 558387.840 171315.385 558384.367 171312.210 558372.174 171310.694 558364.839 171310.133 558354.965 171312.327 558348.726 171314.232 558348.600 171314.808 558348.711 171317.497 558349.229 171319.067 558351.009 171319.804 558354.050 171320.317 558364.494 171320.793 558369.918 171322.442 558376.111 171324.164 558383.038 171325.849 558390.037 171326.508 558393.555 171326.508 558398.393 171326.655 558410.230 171326.728 558416.020 171326.240 558417.610 171325.602 558418.076</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bb3ff1c2f-069b-423f-fb0d-2c46e62fc702">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-04</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:37</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-04T13:42:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.ee322036f3ae4b018b5e1b74428b49de</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170945.560 558211.030 170947.340 558206.109 170947.428 558205.054 170950.861 558191.862 170956.630 558165.929 170959.093 558155.214 170961.772 558144.660 170963.572 558135.550 170964.598 558129.226 170965.289 558122.609 170966.126 558117.144 170967.738 558112.264 170971.096 558105.677 170974.781 558097.971 170978.716 558089.511 170981.781 558082.442 170984.293 558076.621 170988.098 558067.312 170991.594 558057.601 170994.231 558049.665 170999.160 558035.263 171002.345 558026.739 171003.452 558027.213 171005.509 558022.389 171004.354 558022.012 171008.879 558012.626 171009.410 558011.469</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bce552be7-56c9-a681-bea3-6473c6642e8a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-02-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-02-22T12:50:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2cd39e1862ce4447afb54cccc3da2358</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171921.212 559958.386 171915.521 559952.966</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b19073288-4193-c8eb-a07b-31f3fd1da813">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-08-12</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-12T14:16:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.38c3ad9270f549738fb8ef148b9eebd0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170364.846 558667.124 170364.513 558667.461</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bc66d2e64-835c-1000-c2b4-34de9e503575">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2014-07-11T16:40:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.71c5cd511fc64ecd98a22309cf1aa527</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">170272.293 558600.020 170267.934 558596.310</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b2dc856fc-5103-c1d2-9adb-a6fb18016e54">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2014-07-11</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-01-26</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-26T15:47:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2014-07-11T16:40:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.b89449a2bf4d4a33b41868cc8cc88645</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">171755.697 559839.732 171751.361 559836.127</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">hek</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b16284fcd-7f2d-3d9d-029e-6e6e44edde63">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:04:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-12-08T10:17:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.400a78fd1ceb483cab0b4f11ddd428b8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171915.521 559952.966 171915.488 559952.934 171924.054 559948.031 171924.551 559947.739 171933.353 559942.550 171934.513 559941.834 171939.283 559938.887 171942.692 559936.760 171947.283 559933.854 171949.520 559932.312 171953.137 559929.997 171953.873 559929.526 171954.644 559929.088 171954.867 559929.308 171954.036 559929.778 171952.743 559930.615 171951.400 559931.485 171949.720 559932.573 171948.635 559933.273 171947.159 559934.215 171945.511 559935.267 171944.456 559935.941 171943.155 559936.771 171942.348 559937.287 171941.467 559937.848 171939.996 559938.788 171939.383 559939.178 171938.613 559939.653 171936.939 559940.687 171936.469 559940.978 171935.880 559941.342 171935.241 559941.737 171934.730 559942.052 171934.131 559942.422 171933.597 559942.752 171932.775 559943.240 171925.478 559947.541 171924.772 559947.957 171915.733 559953.168 171915.521 559952.966</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b999733f7-18fc-8dcd-3306-5e133b7f3dd6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-05-19</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:06:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-12-08T09:30:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b1356e3f298d444ba2f98b61616e8b38</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.674 559972.731 171877.696 559973.052 171877.324 559973.224 171872.384 559975.515 171871.139 559976.087 171869.154 559976.992 171865.221 559978.781 171858.728 559981.717 171858.605 559981.443 171862.015 559979.913 171865.400 559978.369 171870.631 559975.991 171872.247 559975.251 171877.674 559972.731</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b0e54d51f-c787-7404-66df-bed759a865c1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-16</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-09-16T11:25:08</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-03-24T13:29:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f1ab00cab5934f07aba076a409caeaf3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172500.540 559603.275 172498.386 559603.872 172498.234 559604.160 172492.438 559615.139 172491.783 559614.799 172497.887 559603.293 172497.955 559603.274 172506.441 559600.898 172509.401 559600.069 172518.881 559607.149 172519.248 559607.423 172519.176 559607.558 172518.820 559607.307 172516.945 559605.982 172514.929 559604.558 172509.572 559600.772 172508.375 559601.104 172506.598 559601.596 172505.349 559601.942 172501.912 559602.895 172500.540 559603.275</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bdc085e00-3db5-8ce7-d92e-f12f9149f967">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T12:02:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.19a6c4a12e2c403380446b8142a577d9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173266.230 558766.909 173258.238 558766.397 173257.107 558767.901 173256.446 558768.711 173255.879 558769.198 173257.629 558775.650 173246.308 558778.371 173244.762 558771.816 173244.031 558772.204 173243.969 558772.088 173240.061 558774.070 173239.882 558773.820 173239.025 558774.155</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b1e343246-3120-4186-d0c3-d3c410f1f81e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T11:53:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.28ab3b19586c493fafdecea835e0c81b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173345.528 558751.367 173331.319 558751.641 173320.372 558751.864 173309.380 558757.465</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bf09f77ae-1394-a11f-51a6-5fc70941814a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-09-19T11:38:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-17T08:11:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.739abed88da84ce0bea025119d1baf68</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172177.456 559875.510 172173.444 559871.598 172172.224 559863.998 172171.902 559861.899 172171.759 559860.966 172169.513 559845.785 172224.386 559791.410</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba97db451-4760-09c3-d70d-2a100f86c7b4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T13:17:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.9a49001509a44d55b7295f9ad88191a8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173116.940 558811.506 173116.758 558811.537 173107.448 558815.653 173098.204 558818.225 173097.466 558818.580 173087.594 558821.365 173079.971 558819.112</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba0d4864a-9d91-c4a3-bfef-377b3f8facf9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T12:12:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.abe3e15f236a4df7843177872fe1f091</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173187.237 558788.906 173182.667 558789.400 173181.822 558789.478 173183.537 558796.105 173172.378 558798.993 173170.587 558791.360 173169.768 558791.771 173162.016 558795.887 173159.261 558797.317 173159.350 558797.556 173159.261 558797.606</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b23e87493-7640-8251-ad41-1a1e68994b50">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-17T08:22:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.d076839cfc5c49d7a4c9e8d8ece2d5f9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172188.827 559886.375 172190.807 559887.627 172193.079 559889.772 172212.240 559908.310 172232.520 559927.730 172251.050 559946.480 172271.150 559966.220 172280.140 559975.000 172285.530 559980.330 172293.730 559988.420 172297.140 559991.630 172305.550 560000.000 172313.630 560008.000 172321.290 560015.520 172322.631 560016.827 172323.127 560017.310 172332.260 560026.210 172346.240 560039.900 172356.990 560050.460 172365.240 560058.730 172366.130 560059.570 172366.700 560060.130 172367.240 560060.640 172367.810 560061.050 172368.274 560061.359 172369.044 560062.112 172371.204 560063.388 172379.905 560068.523 172380.942 560069.337 172405.491 560090.821 172408.840 560093.970 172413.235 560097.849 172418.584 560102.965 172435.662 560120.280 172440.680 560125.368 172440.890 560125.590 172441.587 560126.287 172442.465 560127.177 172456.495 560138.645 172476.162 560151.044</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bab5ced9e-5760-95a3-2073-f20664576ad6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T11:48:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.f09a07830e4d4bb09001b5e0a9ee1f63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173420.653 558733.112 173417.874 558734.016 173412.469 558735.940 173409.426 558737.023 173406.565 558738.210 173402.555 558739.669 173400.417 558740.586 173398.186 558741.352 173397.577 558741.561 173395.662 558742.365 173395.352 558742.505</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b955d4ad2-246f-3e49-e92e-63b4ebb6f890">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:47:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.43647e97e5bb4b5d90ed91b4b1289c70</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173936.533 559644.293 173928.577 559653.758 173924.267 559659.252 173924.088 559659.443 173916.397 559671.121 173914.330 559673.989 173907.825 559683.014 173902.460 559690.463 173902.375 559690.405 173900.241 559693.535 173899.885 559694.038 173895.553 559700.601 173889.991 559709.495 173890.699 559709.972 173887.794 559715.107 173875.986 559733.310 173875.213 559734.504 173872.990 559737.930 173865.145 559752.372 173861.818 559759.760 173859.197 559767.734 173858.852 559769.221 173857.915 559773.259 173856.870 559777.760 173854.001 559783.527 173852.753 559786.037</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b8cb4ecce-9c86-3014-f7e5-c34d3dce4a5e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:14</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:49:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.7a190b0d2dbb4b0ca4ce6d54021ac12a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173848.688 559788.946 173847.242 559791.788 173838.510 559807.010</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b262e5e32-5369-8ba2-2a0c-6e83b6826d90">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-12-01T16:24:55</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T11:45:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.aeca6b159d6c4e81ba9334f83c4344f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173664.402 558654.030 173668.716 558655.056 173680.816 558655.056 173688.255 558653.840 173696.018 558651.376 173706.410 558649.331 173710.550 558648.703 173713.022 558648.565 173742.891 558645.808 173746.875 558644.855 173750.925 558644.247</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bf50db039-d23d-88ee-0f9d-191971e34826">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:40:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.dfc4de43140a43099a50a1bcebb7c658</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">174053.814 559498.778 174050.623 559502.793 174047.180 559510.197 174039.489 559526.737 174035.594 559536.281 174029.423 559545.739 174028.490 559547.056 174012.282 559569.952 174012.053 559570.308 174011.733 559570.948 174011.784 559571.661 174011.971 559572.137 174013.494 559573.668 174021.246 559580.561 174027.290 559585.936 174027.795 559588.551 174026.577 559589.889 174026.174 559589.982 174024.364 559592.237 174017.160 559601.212 174014.709 559604.571 174013.209 559606.369 174010.402 559609.252 174009.166 559610.890 174005.094 559616.006 174004.525 559616.675 174004.090 559617.093 174003.674 559617.483 174003.055 559618.188 174001.866 559619.522 174000.074 559621.566 173997.638 559624.806 173991.096 559632.517 173985.776 559638.651 173978.733 559647.122 173973.888 559652.581 173970.762 559656.255 173969.922 559657.207 173953.862 559675.679 173948.860 559672.221 173941.544 559665.758</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba4f4899c-66e5-7c15-9c79-20096656796f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-12-22</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2016-09-16</terminationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-09-16T11:25:08</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-03-24T13:29:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f1ab00cab5934f07aba076a409caeaf3</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172500.540 559603.275 172498.386 559603.872 172498.234 559604.160 172492.438 559615.139 172491.783 559614.799 172497.887 559603.293 172497.955 559603.274 172506.441 559600.898 172509.401 559600.069 172518.881 559607.149 172519.248 559607.423 172519.176 559607.558 172518.820 559607.307 172516.945 559605.982 172514.929 559604.558 172509.572 559600.772 172508.375 559601.104 172506.598 559601.596 172505.349 559601.942 172501.912 559602.895 172500.540 559603.275</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">muur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b9571d9fe-a606-a70d-3b66-ffe2b47c81f1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:04</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T11:38:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.739abed88da84ce0bea025119d1baf68</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172177.456 559875.510 172173.444 559871.598 172172.224 559863.998 172171.902 559861.899 172171.759 559860.966 172169.513 559845.785 172224.222 559791.299</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="ba8d289e3-b018-b155-aa34-f412ae932103">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2017-10-20T14:41:59</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:34</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T16:24:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.aeca6b159d6c4e81ba9334f83c4344f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173664.402 558654.030 173665.350 558654.136 173668.828 558654.773 173671.889 558654.969 173678.016 558654.969 173680.651 558654.819 173684.598 558654.315 173688.250 558653.559 173691.805 558652.649 173695.388 558651.613 173698.845 558650.717 173702.400 558649.862 173708.634 558648.679 173713.606 558648.287 173718.676 558648.115 173724.653 558648.385 173728.816 558648.409 173734.548 558647.919 173738.662 558647.380 173744.222 558646.351 173750.051 558644.881 173752.746 558644.146</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b215d289f-e0f0-5e52-7e02-ad5df08aa18f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2019-03-12T10:42:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:50:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-15T13:04:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.014a43a860bd456d890fa0cb41628948</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173552.365 559956.345 173553.610 559956.800 173543.661 559988.436 173543.257 559989.613 173533.227 560020.412 173532.743 560021.763 173521.227 560056.996 173519.671 560056.470 173519.658 560056.168 173521.122 560051.964 173521.721 560050.137 173523.847 560043.449 173530.657 560022.588 173532.371 560018.341 173533.881 560012.919 173537.077 560003.436 173541.209 559990.432 173542.380 559986.637 173544.290 559981.151 173547.180 559972.584 173550.935 559960.205 173552.336 559956.468 173552.365 559956.345</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bf30f6e01-05cc-b534-5347-95ba5e54b8a6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T12:02:35.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.19a6c4a12e2c403380446b8142a577d9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173266.230 558766.909 173258.238 558766.397 173257.107 558767.901 173256.446 558768.711 173255.879 558769.198 173257.629 558775.650 173246.308 558778.371 173244.762 558771.816 173244.031 558772.204 173243.969 558772.088 173240.061 558774.070 173239.882 558773.820 173239.025 558774.155</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b6c15c679-3cce-b6ec-c28e-e64f148946bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T11:53:14.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.28ab3b19586c493fafdecea835e0c81b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173345.528 558751.367 173331.319 558751.641 173320.372 558751.864 173309.380 558757.465</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bd00940e0-8407-3ef8-1076-1cc9ad9527ec">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:47:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.43647e97e5bb4b5d90ed91b4b1289c70</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173936.533 559644.293 173928.577 559653.758 173924.267 559659.252 173924.088 559659.443 173916.397 559671.121 173914.330 559673.989 173907.825 559683.014 173902.460 559690.463 173902.375 559690.405 173900.241 559693.535 173899.885 559694.038 173895.553 559700.601 173889.991 559709.495 173890.699 559709.972 173887.794 559715.107 173875.986 559733.310 173875.213 559734.504 173872.990 559737.930 173865.145 559752.372 173861.818 559759.760 173859.197 559767.734 173858.852 559769.221 173857.915 559773.259 173856.870 559777.760 173854.001 559783.527 173852.753 559786.037</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b8f35f97e-72cb-712a-fbdd-cdd55886dceb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:04</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-09-19T11:38:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.739abed88da84ce0bea025119d1baf68</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172177.456 559875.510 172173.444 559871.598 172172.224 559863.998 172171.902 559861.899 172171.759 559860.966 172169.513 559845.785 172224.222 559791.299</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">damwand</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bafd322cc-3d85-efc4-0b3b-d4f92e76f768">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:14</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:49:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.7a190b0d2dbb4b0ca4ce6d54021ac12a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173848.688 559788.946 173847.242 559791.788 173838.510 559807.010</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="bd1a296d8-0acb-ab21-5483-1d7d598d76c9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T13:17:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.9a49001509a44d55b7295f9ad88191a8</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173116.940 558811.506 173116.758 558811.537 173107.448 558815.653 173098.204 558818.225 173097.466 558818.580 173087.594 558821.365 173079.971 558819.112</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b84dc720e-7b34-c5c4-4e62-95fa061dd29c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T12:12:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.abe3e15f236a4df7843177872fe1f091</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173187.237 558788.906 173182.667 558789.400 173181.822 558789.478 173183.537 558796.105 173172.378 558798.993 173170.587 558791.360 173169.768 558791.771 173162.016 558795.887 173159.261 558797.317 173159.350 558797.556 173159.261 558797.606</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b1e05047e-f43a-b26a-0d6e-0a34872e4aff">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:47:34</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T16:24:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.aeca6b159d6c4e81ba9334f83c4344f0</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173664.402 558654.030 173665.350 558654.136 173668.828 558654.773 173671.889 558654.969 173678.016 558654.969 173680.651 558654.819 173684.598 558654.315 173688.250 558653.559 173691.805 558652.649 173695.388 558651.613 173698.845 558650.717 173702.400 558649.862 173708.634 558648.679 173713.606 558648.287 173718.676 558648.115 173724.653 558648.385 173728.816 558648.409 173734.548 558647.919 173738.662 558647.380 173744.222 558646.351 173750.051 558644.881 173752.746 558644.146</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b8892bd91-fb4d-611b-e33f-6670a977da2d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-17</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-17T08:22:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.d076839cfc5c49d7a4c9e8d8ece2d5f9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">172182.920 559880.870 172188.827 559886.375 172190.807 559887.627 172193.079 559889.772 172212.240 559908.310 172232.520 559927.730 172251.050 559946.480 172271.150 559966.220 172280.140 559975.000 172285.530 559980.330 172293.730 559988.420 172297.140 559991.630 172305.550 560000.000 172313.630 560008.000 172321.290 560015.520 172322.631 560016.827 172323.127 560017.310 172332.260 560026.210 172346.240 560039.900 172356.990 560050.460 172365.240 560058.730 172366.130 560059.570 172366.700 560060.130 172367.240 560060.640 172367.810 560061.050 172368.274 560061.359 172369.044 560062.112 172371.204 560063.388 172379.905 560068.523 172380.942 560069.337 172405.491 560090.821 172408.840 560093.970 172413.235 560097.849 172418.584 560102.965 172435.662 560120.280 172440.680 560125.368 172440.890 560125.590 172441.587 560126.287 172442.465 560127.177 172456.495 560138.645 172476.162 560151.044</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b002516b8-7ea5-064d-d928-80513f757aab">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T10:40:13.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.dfc4de43140a43099a50a1bcebb7c658</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">174053.814 559498.778 174050.623 559502.793 174047.180 559510.197 174039.489 559526.737 174035.594 559536.281 174029.423 559545.739 174028.490 559547.056 174012.282 559569.952 174012.053 559570.308 174011.733 559570.948 174011.784 559571.661 174011.971 559572.137 174013.494 559573.668 174021.246 559580.561 174027.290 559585.936 174027.795 559588.551 174026.577 559589.889 174026.174 559589.982 174024.364 559592.237 174017.160 559601.212 174014.709 559604.571 174013.209 559606.369 174010.402 559609.252 174009.166 559610.890 174005.094 559616.006 174004.525 559616.675 174004.090 559617.093 174003.674 559617.483 174003.055 559618.188 174001.866 559619.522 174000.074 559621.566 173997.638 559624.806 173991.096 559632.517 173985.776 559638.651 173978.733 559647.122 173973.888 559652.581 173970.762 559656.255 173969.922 559657.207 173953.862 559675.679 173948.860 559672.221 173941.544 559665.758</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b77ff53c9-782b-e35c-1a87-9b67e41f3952">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-11-23</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-10-28</terminationDate>
            <imgeo:LV-publicatiedatum>2020-10-28T23:42:43</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-28T17:48:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-23T11:48:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>W0653.f09a07830e4d4bb09001b5e0a9ee1f63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>W0653</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:LineString xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:posList srsDimension="2">173420.653 558733.112 173417.874 558734.016 173412.469 558735.940 173409.426 558737.023 173406.565 558738.210 173402.555 558739.669 173400.417 558740.586 173398.186 558741.352 173397.577 558741.561 173395.662 558742.365 173395.352 558742.505</gml:posList></gml:LineString></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">walbescherming</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:OverigeScheiding gml:id="b4a63e03b-41eb-abec-4a58-cc9dd13e73fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2020-08-27</terminationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-27T15:50:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2018-05-15T13:04:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.014a43a860bd456d890fa0cb41628948</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dOverigeConstructie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173552.365 559956.345 173553.610 559956.800 173543.661 559988.436 173543.257 559989.613 173533.227 560020.412 173532.743 560021.763 173521.227 560056.996 173519.671 560056.470 173519.658 560056.168 173521.122 560051.964 173521.721 560050.137 173523.847 560043.449 173530.657 560022.588 173532.371 560018.341 173533.881 560012.919 173537.077 560003.436 173541.209 559990.432 173542.380 559986.637 173544.290 559981.151 173547.180 559972.584 173550.935 559960.205 173552.336 559956.468 173552.365 559956.345</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverigeConstructie>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeScheiding">kademuur</imgeo:plus-type>
        </imgeo:OverigeScheiding>
    </cityObjectMember>
</CityModel>