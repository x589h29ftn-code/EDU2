<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Paal gml:id="b18c38fc9-2c2d-fdc0-f604-27a4781b9e6c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-14</terminationDate>
            <imgeo:LV-publicatiedatum>2025-10-14T11:34:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-10-14T15:00:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-14T11:17:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.23d52cff418d44539bf2fe3e58262daa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171425.752 558007.823</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Paal gml:id="bf637c2ab-9f05-fb32-c3fe-897ff0e9df12">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-14</terminationDate>
            <imgeo:LV-publicatiedatum>2025-10-22T12:24:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-10-14T15:00:13</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-14T11:17:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.23d52cff418d44539bf2fe3e58262daa</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171425.752 558007.823</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Paal gml:id="be59a9908-a207-1dc9-a240-04c5139aedf8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-29</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-03-25</terminationDate>
            <imgeo:LV-publicatiedatum>2025-11-04T11:51:16</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-03-25T15:22:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-29T09:06:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e70735173504ccea7b58231d47d6ceb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171424.055 558006.854</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Paal gml:id="b7df5f2da-b79d-70f0-2e60-a434690a9d1a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-29</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-03-25</terminationDate>
            <imgeo:LV-publicatiedatum>2026-03-25T15:29:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-03-25T15:22:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-29T09:06:25.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e70735173504ccea7b58231d47d6ceb</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171424.055 558006.854</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Paal gml:id="b88fd0405-32d9-be6f-eb19-1eceb55e0fc1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-28</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-03-25</terminationDate>
            <imgeo:LV-publicatiedatum>2025-11-04T11:51:16</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-03-25T15:22:50</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-28T11:07:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f223afe189e44dc89f86e60a7a95477d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171427.332 558008.515</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Paal gml:id="b5c44435d-0ff7-933b-75b1-3b730ff2d009">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2025-10-28</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-03-25</terminationDate>
            <imgeo:LV-publicatiedatum>2026-03-25T15:29:39</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-03-25T15:22:50</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2025-10-28T11:07:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f223afe189e44dc89f86e60a7a95477d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaal">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypePaalPlus">lichtmast</imgeo:plus-type>
            <imgeo:geometrie2dPaal><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171427.332 558008.515</gml:pos></gml:Point></imgeo:geometrie2dPaal>
        </imgeo:Paal>
    </cityObjectMember>
</CityModel>