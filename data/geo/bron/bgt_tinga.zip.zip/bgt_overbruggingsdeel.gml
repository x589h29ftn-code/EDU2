<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b314eda3e-dabc-8295-9d71-49df8e3a6803">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-17T11:24:50</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.94d35ce854434301b40fd863dc61a90b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171905.785 559967.072 171903.608 559965.258 171899.725 559962.023 171900.179 559961.787 171906.837 559958.199 171908.811 559959.844 171910.579 559961.317 171910.483 559961.433 171909.683 559962.393 171907.122 559965.466 171908.275 559966.426 171908.115 559966.618 171906.962 559965.658 171906.897 559965.736 171906.642 559966.042 171906.255 559966.507 171905.881 559966.956 171905.785 559967.072</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b7514a581-a827-5cbc-8206-291f4be3d27f">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-17T11:24:50.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.94d35ce854434301b40fd863dc61a90b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171906.962 559965.658 171906.642 559966.042 171906.255 559966.507 171905.881 559966.956 171905.785 559967.072 171903.608 559965.258 171899.725 559962.023 171900.179 559961.787 171906.837 559958.199 171908.811 559959.844 171910.579 559961.317 171910.483 559961.433 171909.683 559962.393 171907.122 559965.466 171906.962 559965.658</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bfbcd2524-0136-da1c-0c6c-404922601579">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c6c25ec49f5e4701890ce187567d4e29</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170458.339 558103.858 170462.353 558104.490 170462.199 558105.583 170461.038 558112.791 170460.887 558113.810 170460.427 558116.796 170456.349 558116.158 170456.863 558113.404 170457.123 558111.925 170458.111 558105.840 170458.339 558103.858</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b21446fb8-280d-972d-389f-67a47749296a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b769c8a5250d434fa730913a6637942f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170450.484 558103.517 170450.540 558102.659 170454.569 558103.264 170454.265 558105.279 170453.328 558111.303 170453.105 558112.758 170452.907 558113.963 170448.989 558113.330 170449.188 558112.114 170449.372 558110.760 170450.306 558104.767 170450.484 558103.517</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6c669d0c-ad5b-7491-4d67-5e6765cfdb78">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e65e1d1c340a4fffbb53f3d8fcd5ff6d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170436.041 558108.708 170437.017 558102.398 170437.184 558101.345 170437.308 558100.613 170437.324 558100.390 170441.341 558101.186 170441.088 558102.241 170440.917 558103.405 170439.978 558109.401 170439.778 558110.716 170439.616 558111.705 170435.614 558111.083 170435.957 558109.265 170436.041 558108.708</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b85b7db9a-64c1-a413-d55c-8ef4fa2c6254">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.61ccda456b9647f39fff8b692c48443f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170408.190 558232.340 170408.722 558232.452 170408.603 558233.039 170410.443 558233.401 170410.556 558232.836 170411.060 558232.942 170408.410 558245.822 170407.986 558245.733 170408.111 558245.106 170406.238 558244.725 170406.113 558245.340 170405.491 558245.210 170408.190 558232.340</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bca050467-bfe6-ff5e-8904-cbc3ce0fd28a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e0921e07e46841c9989419377fd9a606</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170745.014 558219.394 170752.880 558213.490 170753.432 558214.209 170757.069 558218.945 170757.610 558219.650 170749.220 558226.120 170748.637 558225.377 170744.919 558220.638 170744.340 558219.900 170745.014 558219.394</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b79455be2-8eda-8415-0ba1-9c0fe7d1b5d9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2020-09-15T11:37:32</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:44:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0c49a6d8c5904b419a12399baf9d8621</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170753.105 558187.879 170752.025 558183.802 170756.724 558182.460 170757.911 558186.548 170753.105 558187.879</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b330e9b80-19bf-048a-12f0-5b2e118e9566">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:43:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.ac85ed82da4d47f18fb69abc648fea5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170795.282 558303.002 170792.503 558299.031 170797.176 558297.976 170799.824 558301.886 170795.282 558303.002</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b7f55806c-cb00-dc04-2cfb-48af792abaf9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.542bd660519b447588a228e51ace400a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170861.200 558097.980 170862.230 558097.880 170864.334 558098.364 170871.620 558100.040 170876.989 558101.028 170877.160 558101.060 170877.425 558101.081 170881.852 558101.426 170882.160 558101.450 170882.850 558101.560 170882.120 558104.310 170881.870 558104.180 170881.473 558103.964 170877.240 558102.790 170877.039 558102.748 170871.280 558101.540 170864.032 558100.730 170861.880 558100.490 170860.852 558100.322 170861.200 558097.980</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6189adaa-44a4-7a11-74a2-e82df867cc9b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c1b64ddaf3f2483c812fc2ffeb4e0ae1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170936.956 558209.923 170937.384 558208.405 170948.924 558212.110 170948.089 558213.623 170947.484 558215.464 170946.672 558217.938 170946.003 558219.693 170935.023 558215.760 170935.527 558214.223 170936.218 558212.144 170936.956 558209.923</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9885460a-e0dc-3d28-59bc-98ae1444fba9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.64f216d7d68a4e968412414057f2c307</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170999.993 558003.646 171000.040 558003.547 171001.639 558004.315 171010.422 558008.532 171013.137 558009.836 171011.846 558012.617 171009.410 558011.469 171000.317 558007.182 171000.000 558007.033 170998.692 558006.416 170999.993 558003.646</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6334ee98-3aa2-331b-4604-991724decc16">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.81ca4a4690394f0db12a33372cdfef8c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170999.660 558002.744 171003.204 558004.438 171003.067 558004.725 170999.511 558003.056 170999.660 558002.744</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b1cb593ba-05f9-9117-ad3c-64c9c526e58b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2b9f9114f34f48efa7038a851cb9e873</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">170997.946 558006.401 171001.501 558008.042 171001.334 558008.403 170997.787 558006.745 170997.946 558006.401</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bf4d579c8-631a-0be6-897e-97bcf7cc9017">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-02-16T18:04:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:45:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8f38731be69542f495d9afe40073142c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171108.849 558021.184 171109.431 558019.871 171114.288 558022.025 171113.705 558023.338 171108.849 558021.184</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bdb898be0-68a8-7e75-afa3-d410b6f948e3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d284d168967b4e0cb653d9794fa0d1ad</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171218.003 558398.586 171218.727 558399.552 171224.438 558406.391 171226.400 558408.740 171224.700 558410.100 171223.928 558409.139 171216.361 558399.911 171218.003 558398.586</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bb8eaafaf-a66c-0a46-5e34-8b5868c35dce">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-12-13T11:42:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c4a3d11d1a5e4e308edd2f939c219c7e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171123.890 558454.040 171132.310 558461.940 171130.510 558464.450 171122.230 558456.590 171123.800 558454.179 171123.890 558454.040</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="baec5589e-cedd-c800-b30c-418a29940203">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2021-12-13T14:29:46</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2021-12-13T11:42:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.c4a3d11d1a5e4e308edd2f939c219c7e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171122.230 558456.590 171123.800 558454.179 171123.890 558454.040 171124.561 558454.670 171125.590 558455.635 171130.713 558460.442 171131.101 558460.806 171131.201 558460.900 171132.310 558461.940 171130.510 558464.450 171129.547 558463.536 171128.857 558462.881 171123.868 558458.145 171122.230 558456.590</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="becdf8e98-3f44-f62f-a4b7-c37154dd2ea9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-13</creationDate>
            <imgeo:LV-publicatiedatum>2016-05-26T11:09:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-07-13T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e6d6b88dd9bd47458a51f1ea48eb2540</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171113.972 559877.157 171116.544 559879.428 171117.058 559879.657 171113.795 559883.355 171110.757 559880.799 171113.972 559877.157</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="be9ca3710-3229-c84a-2528-57c14c081e96">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T12:09:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-09T23:06:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-07-14T10:39:46.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02b32f0e7c8f4054828974c5a1186988</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171439.366 559570.939 171443.263 559574.194 171440.247 559577.870 171436.256 559574.583 171439.366 559570.939</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="be882af3c-dfa9-15e4-d364-d46d12607a8e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-11-09T14:26:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:06:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02b32f0e7c8f4054828974c5a1186988</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171440.273 559577.838 171440.247 559577.870 171436.256 559574.583 171436.304 559574.527 171436.525 559574.268 171439.366 559570.939 171443.263 559574.194 171440.490 559577.574 171440.273 559577.838</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bc3f727bf-a1d5-8d97-0064-a772b5211c50">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2021-11-09T14:38:26</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:09</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2021-11-09T14:26:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02b32f0e7c8f4054828974c5a1186988</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171440.273 559577.838 171440.247 559577.870 171436.256 559574.583 171436.304 559574.527 171436.525 559574.268 171439.366 559570.939 171443.263 559574.194 171440.490 559577.574 171440.273 559577.838</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bd1601edd-adc5-69ce-6c70-91e655827cb3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.02b32f0e7c8f4054828974c5a1186988</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171440.563 559577.447 171436.620 559574.138 171438.111 559572.386 171442.023 559575.670 171440.563 559577.447</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b40f27c1e-41af-9920-fe19-2b966c8a0856">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.c4fb936b5e664afa9bd75fb458b70c62</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171435.651 559573.965 171435.862 559573.711 171436.031 559573.852 171436.350 559574.117 171440.649 559577.692 171440.818 559577.832 171440.609 559578.087 171440.440 559577.947 171436.136 559574.368 171435.820 559574.106 171435.651 559573.965</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b80a1db7d-4257-4a30-9836-3cd5a9bf335a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.cea0f1e8dd9c49fc9e3188af385be950</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171442.094 559567.961 171440.672 559570.224 171436.774 559574.806 171435.108 559576.765 171433.258 559578.572 171432.772 559578.159 171432.225 559577.695 171432.517 559577.352 171432.953 559577.723 171432.992 559577.755 171434.544 559576.239 171435.358 559575.282 171436.136 559574.368 171436.350 559574.117 171437.943 559572.244 171439.497 559570.417 171440.050 559569.767 171440.186 559569.550 171441.259 559567.843 171440.777 559567.433 171441.068 559567.090 171441.608 559567.549 171442.094 559567.961</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b18895aea-661c-6dfe-059d-2c8559a085d3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-04-04</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.db819a5858555a3fe0530b29a8c0ec8b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171439.497 559570.417 171439.665 559570.559 171439.374 559570.901 171443.261 559574.163 171443.549 559573.820 171443.719 559573.960 171442.195 559575.812 171442.023 559575.670 171442.118 559575.554 171438.208 559572.272 171438.111 559572.386 171437.943 559572.244 171439.497 559570.417</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b47968a24-c23a-b130-523c-3b02087b8a9c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-05-31</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.a3b17d9fc4aa4d57a018e816a1cf222a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171446.666 559571.841 171446.375 559572.184 171445.893 559571.775 171444.283 559573.274 171443.719 559573.960 171442.195 559575.812 171440.649 559577.692 171440.440 559577.947 171440.206 559578.231 171439.667 559578.886 171438.871 559579.854 171437.639 559581.700 171437.661 559581.719 171438.114 559582.103 171437.823 559582.446 171437.223 559581.937 171436.941 559581.697 171436.797 559581.575 171438.252 559579.395 171439.863 559577.435 171443.721 559572.745 171445.634 559570.965 171446.035 559571.305 171446.666 559571.841</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b8590e1b2-1411-1341-e232-5ee8c14026a0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:57:27</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b3ae61b2243a4faeaa5b846dbdc34335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171987.395 559890.609 171986.430 559891.277 171985.426 559890.288 171985.756 559890.060 171986.568 559889.501 171987.395 559890.609</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bffde8922-b006-d68c-73f2-bd38144e44c8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-03-10T12:09:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:27.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b3ae61b2243a4faeaa5b846dbdc34335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171987.395 559890.609 171986.430 559891.277 171985.426 559890.288 171985.756 559890.060 171986.568 559889.501 171987.395 559890.609</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b15a1ac69-70a4-a706-0388-f23c9a1a52e6">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2023-03-10T12:16:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2023-03-10T12:09:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b3ae61b2243a4faeaa5b846dbdc34335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">pijler</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171987.395 559890.609 171986.430 559891.277 171985.426 559890.288 171985.756 559890.060 171986.568 559889.501 171987.395 559890.609</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b94d5ad0e-dddd-f18e-706e-86ed4286f9fd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e335302041f94be082d105e94eae37df</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171994.181 559897.278 171993.744 559897.572 171993.199 559897.945 171992.627 559897.382 171993.333 559896.888 171993.715 559896.631 171994.181 559897.278</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bb3d7894f-302e-75a5-a63b-aaf5a14556dd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-03-10T12:09:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e335302041f94be082d105e94eae37df</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171994.181 559897.278 171993.744 559897.572 171993.199 559897.945 171992.627 559897.382 171993.333 559896.888 171993.715 559896.631 171994.181 559897.278</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b67c87f63-70f1-9b36-4873-cb38d4fd4b69">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2023-03-10T12:16:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2023-03-10T12:09:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e335302041f94be082d105e94eae37df</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">pijler</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171994.181 559897.278 171993.744 559897.572 171993.199 559897.945 171992.627 559897.382 171993.333 559896.888 171993.715 559896.631 171994.181 559897.278</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b2a3ed2c0-94fe-71af-4d05-8e28111af2a1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b3ae61b2243a4faeaa5b846dbdc34335</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">pijler</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171996.751 559883.988 171992.696 559886.915 171988.596 559889.778 171987.395 559890.609 171986.430 559891.277 171985.426 559890.288 171985.756 559890.060 171986.568 559889.501 171989.874 559887.223 171994.038 559884.455 171998.219 559881.711 172002.394 559878.958 172006.577 559876.217 172006.865 559876.018 172007.162 559876.535 172004.870 559878.144 172000.818 559881.075 171996.751 559883.988</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b192544c7-3b6d-2a8b-e803-febbe91754ca">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:20</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.52756b38f7324e5e987eeae1868c3564</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171903.318 559929.846 171903.809 559929.240 171905.629 559930.778 171906.677 559930.175 171907.506 559929.698 171908.627 559929.054 171909.114 559928.773 171909.591 559928.499 171910.627 559927.903 171911.258 559927.540 171912.130 559927.038 171912.979 559926.550 171913.074 559926.495 171913.152 559926.450 171911.269 559924.855 171911.759 559924.280 171912.907 559925.252 171913.891 559926.084 171914.096 559926.257 171912.961 559926.930 171912.883 559926.976 171908.620 559929.451 171908.575 559929.478 171905.185 559931.423 171904.966 559931.238 171903.318 559929.846</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b39c21798-4e11-3d64-302f-724518b60cb8">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:20.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.52756b38f7324e5e987eeae1868c3564</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171903.318 559929.846 171903.809 559929.240 171905.629 559930.778 171906.677 559930.175 171907.506 559929.698 171908.627 559929.054 171909.114 559928.773 171909.591 559928.499 171910.627 559927.903 171911.258 559927.540 171912.130 559927.038 171912.979 559926.550 171913.074 559926.495 171913.152 559926.450 171911.269 559924.855 171911.759 559924.280 171912.907 559925.252 171913.891 559926.084 171914.096 559926.257 171912.961 559926.930 171912.883 559926.976 171908.620 559929.451 171908.575 559929.478 171905.185 559931.423 171904.966 559931.238 171903.318 559929.846</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b2f3caaeb-77d9-da63-55e3-13f015bb5615">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-08-29T13:26:15</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-18T09:57:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a79a5c51385f4a5db1a53e64c8bcd569</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171904.883 559930.122 171905.629 559930.778 171906.677 559930.175 171907.506 559929.698 171908.627 559929.054 171909.591 559928.499 171910.627 559927.903 171911.258 559927.540 171912.130 559927.038 171913.074 559926.495 171912.304 559925.854 171912.072 559926.074 171911.640 559925.746 171911.348 559925.485 171911.044 559925.213 171911.247 559924.873 171911.261 559924.857 171911.759 559924.280 171912.907 559925.252 171913.891 559926.084 171930.203 559939.949 171933.333 559942.563 171933.597 559942.753 171935.247 559944.148 171934.833 559944.699 171934.577 559945.070 171933.590 559944.213 171933.639 559944.035 171932.775 559943.240 171925.478 559947.541 171926.310 559948.245 171926.571 559947.894 171927.776 559948.780 171927.555 559949.116 171927.445 559949.203 171926.933 559949.781 171924.772 559947.957 171924.551 559947.739 171921.447 559945.086 171904.966 559931.238 171903.318 559929.846 171903.809 559929.240 171904.049 559928.924 171905.147 559929.763 171904.883 559930.122</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b345841b2-72a5-0d03-b9da-c5009123af08">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2024-09-18T09:51:44</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2023-08-29T13:26:15.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a79a5c51385f4a5db1a53e64c8bcd569</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171904.883 559930.122 171905.629 559930.778 171906.677 559930.175 171907.506 559929.698 171908.627 559929.054 171909.591 559928.499 171910.627 559927.903 171911.258 559927.540 171912.130 559927.038 171913.074 559926.495 171912.304 559925.854 171912.072 559926.074 171911.640 559925.746 171911.348 559925.485 171911.044 559925.213 171911.247 559924.873 171911.261 559924.857 171911.759 559924.280 171912.907 559925.252 171913.891 559926.084 171930.203 559939.949 171933.333 559942.563 171933.597 559942.753 171935.247 559944.148 171934.833 559944.699 171934.577 559945.070 171933.590 559944.213 171933.639 559944.035 171932.775 559943.240 171925.478 559947.541 171926.310 559948.245 171926.571 559947.894 171927.776 559948.780 171927.555 559949.116 171927.445 559949.203 171926.933 559949.781 171924.772 559947.957 171924.551 559947.739 171921.447 559945.086 171904.966 559931.238 171903.318 559929.846 171903.809 559929.240 171904.049 559928.924 171905.147 559929.763 171904.883 559930.122</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9f948dfc-18a6-bc1d-140d-4c7408ade34d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:34</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e080469fb48d496f9bdb6992f0c3de63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171992.584 559897.402 171996.233 559901.004 171987.968 559906.678 171979.680 559912.301 171973.034 559916.836 171968.080 559920.198 171964.772 559922.450 171956.313 559928.004 171953.955 559929.536 171950.920 559926.537 171950.358 559925.982 171936.575 559912.366 171938.121 559911.365 171942.358 559908.628 171944.502 559907.218 171948.487 559904.578 171952.632 559901.813 171956.436 559899.259 171961.147 559896.069 171964.460 559893.817 171968.880 559890.798 171973.398 559887.708 171978.894 559883.924 171992.584 559897.402</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="ba41b2165-f3c2-c456-8c71-629d2c0f5eed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T11:55:31</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e080469fb48d496f9bdb6992f0c3de63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171979.680 559912.301 171973.034 559916.836 171968.080 559920.198 171964.772 559922.450 171956.313 559928.004 171953.955 559929.536 171953.919 559929.500 171950.920 559926.537 171950.358 559925.982 171936.575 559912.366 171938.121 559911.365 171942.358 559908.628 171944.502 559907.218 171948.487 559904.578 171952.632 559901.813 171956.436 559899.259 171961.147 559896.069 171964.460 559893.817 171968.880 559890.798 171973.398 559887.708 171978.894 559883.924 171992.584 559897.402 171996.233 559901.004 171987.968 559906.678 171979.680 559912.301</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bf08d5045-9b23-ed89-2938-e38663232d7a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T11:55:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e080469fb48d496f9bdb6992f0c3de63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171979.680 559912.301 171973.034 559916.836 171968.080 559920.198 171964.772 559922.450 171956.313 559928.004 171953.955 559929.536 171953.919 559929.500 171950.920 559926.537 171950.358 559925.982 171936.575 559912.366 171938.121 559911.365 171942.358 559908.628 171944.502 559907.218 171948.487 559904.578 171952.632 559901.813 171956.436 559899.259 171961.147 559896.069 171964.460 559893.817 171968.880 559890.798 171973.398 559887.708 171978.894 559883.924 171992.584 559897.402 171996.233 559901.004 171987.968 559906.678 171979.680 559912.301</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b5574aac3-c3cd-9b8b-bb7a-309b5bef7608">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:34.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.e080469fb48d496f9bdb6992f0c3de63</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171992.584 559897.402 171996.233 559901.004 171987.968 559906.678 171979.680 559912.301 171973.034 559916.836 171968.080 559920.198 171964.772 559922.450 171956.313 559928.004 171953.955 559929.536 171950.920 559926.537 171950.358 559925.982 171936.575 559912.366 171938.121 559911.365 171942.358 559908.628 171944.502 559907.218 171948.487 559904.578 171952.632 559901.813 171956.436 559899.259 171961.147 559896.069 171964.460 559893.817 171968.880 559890.798 171973.398 559887.708 171978.894 559883.924 171992.584 559897.402</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b58a94632-4419-f9b6-cf3f-d1519781bca7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2016-09-21T11:45:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-10-09T23:06:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-08-15T13:12:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.5e9eefaa86664f13a703c5de4bae5d7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171906.403 559958.055 171905.144 559958.720 171901.329 559960.739 171899.318 559961.802 171879.185 559944.900 171875.784 559942.062 171877.088 559940.492 171880.550 559936.322</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="be72bc99e-16aa-5c66-9487-c59c7a40fddc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T08:55:09</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-10-09T23:06:48.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.5e9eefaa86664f13a703c5de4bae5d7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171899.318 559961.802 171879.185 559944.900 171875.784 559942.062 171877.088 559940.492 171880.131 559936.827 171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171906.403 559958.055 171905.144 559958.720 171901.329 559960.739 171899.318 559961.802</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b954792fe-8e45-5e76-c09c-d6585e76d1a0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-07-14</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.5e9eefaa86664f13a703c5de4bae5d7c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171906.588 559957.992 171906.837 559958.199 171908.811 559959.844 171910.579 559961.317 171910.483 559961.433 171909.683 559962.393 171907.122 559965.466 171908.275 559966.426 171908.115 559966.618 171906.962 559965.658 171906.897 559965.736 171906.642 559966.042 171906.255 559966.507 171905.881 559966.956 171905.785 559967.072 171903.608 559965.258 171899.725 559962.023 171899.475 559961.815 171879.510 559945.179 171879.179 559944.903 171877.730 559943.696 171875.833 559942.115 171875.929 559942.000 171876.342 559941.504 171876.691 559941.086 171876.988 559940.730 171877.011 559940.702 171875.897 559939.774 171876.057 559939.582 171877.171 559940.510 171879.732 559937.437 171880.186 559936.892 171880.532 559936.476 171880.628 559936.361 171882.698 559938.086 171886.447 559941.210 171886.739 559941.453 171906.588 559957.992</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b217881b0-d7bd-6c45-94b9-2768075058dd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T21:00:18</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:06.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f2826a28c00d4a4eab0a2646d819936f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.784 559942.062 171877.088 559940.492 171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171886.727 559941.459 171886.652 559941.499 171882.267 559943.765 171882.233 559943.782 171879.515 559945.176 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b2aaf5184-a047-3dfe-3eac-e2a8fb41a759">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-01-11T14:04:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T21:00:18.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f2826a28c00d4a4eab0a2646d819936f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.784 559942.062 171877.088 559940.492 171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171886.727 559941.459 171886.652 559941.499 171882.267 559943.765 171882.233 559943.782 171879.515 559945.176 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b1bf5dcf3-5563-3432-b954-d2821f1a8e8b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2021-01-26T16:58:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2021-01-11T14:04:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f2826a28c00d4a4eab0a2646d819936f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.784 559942.062 171877.088 559940.492 171880.131 559936.827 171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171886.727 559941.459 171886.652 559941.499 171882.267 559943.765 171882.233 559943.782 171879.515 559945.176 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b766a5344-0ea1-11bd-d494-3477f7447f61">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-03</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2022-06-03T09:42:48</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2021-01-11T14:04:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.f2826a28c00d4a4eab0a2646d819936f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.784 559942.062 171877.088 559940.492 171880.131 559936.827 171880.550 559936.322 171880.569 559936.299 171882.702 559938.076 171886.456 559941.205 171886.727 559941.459 171886.652 559941.499 171882.267 559943.765 171882.233 559943.782 171879.515 559945.176 171879.185 559944.900 171875.784 559942.062</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4c0c8826-42b5-80f5-beef-2f7fabbb7e09">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:40</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.1461c70b51974a9395152f77529007d4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171861.452 559953.269 171861.200 559952.790 171861.682 559952.547 171861.855 559952.914 171861.885 559952.900 171861.955 559952.866 171866.695 559950.617 171866.779 559950.577 171866.854 559950.542 171866.677 559950.168 171867.174 559949.932 171867.421 559950.432 171867.556 559950.706 171867.359 559950.802 171867.482 559951.063 171867.500 559951.102 171864.351 559952.599 171864.294 559952.626 171861.995 559953.702 171861.988 559953.687 171861.857 559953.412 171861.588 559953.528 171861.452 559953.269</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b36e6f9f5-03fb-d44c-e1e2-d8ae19887b93">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:40.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.1461c70b51974a9395152f77529007d4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171861.452 559953.269 171861.200 559952.790 171861.682 559952.547 171861.855 559952.914 171861.885 559952.900 171861.955 559952.866 171866.695 559950.617 171866.779 559950.577 171866.854 559950.542 171866.677 559950.168 171867.174 559949.932 171867.421 559950.432 171867.556 559950.706 171867.359 559950.802 171867.482 559951.063 171867.500 559951.102 171864.351 559952.599 171864.294 559952.626 171861.995 559953.702 171861.988 559953.687 171861.857 559953.412 171861.588 559953.528 171861.452 559953.269</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b04076cf6-8949-822f-49b3-f48825b40fbd">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-08-29T13:25:43</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.21b786518dfb4c52a3e3a023d9bbe431</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171864.463 559946.569 171865.511 559948.072 171866.352 559949.746 171866.677 559950.168 171877.929 559973.858 171878.124 559974.373 171879.314 559976.982 171879.088 559977.093 171878.688 559977.289 171877.000 559978.113 171874.926 559979.124 171874.394 559979.387 171872.247 559975.251 171871.723 559974.128 171870.580 559971.679 171861.865 559952.672 171859.961 559949.001 171864.463 559946.569</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b1206024f-dceb-1ae4-b3c5-fa77b7da10eb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2024-09-18T09:51:44</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2023-08-29T13:25:43.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.21b786518dfb4c52a3e3a023d9bbe431</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171864.463 559946.569 171865.511 559948.072 171866.352 559949.746 171866.677 559950.168 171877.929 559973.858 171878.124 559974.373 171879.314 559976.982 171879.088 559977.093 171878.688 559977.289 171877.000 559978.113 171874.926 559979.124 171874.394 559979.387 171872.247 559975.251 171871.723 559974.128 171870.580 559971.679 171861.865 559952.672 171859.961 559949.001 171864.463 559946.569</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b61986f48-0120-d5b8-b713-02a3bfc06334">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-03-04T15:36:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:41:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.b9f4a4244bd34514a3b4b4c8600a1065</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171924.468 559134.159 171924.468 559130.182 171925.826 559130.182 171925.826 559134.159 171924.468 559134.159</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b5e92d427-dc5b-93fd-4b7d-bddf3a5ac6a5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-16</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-16T16:04:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.efab9ff6cf76406c81e870f17da76d6c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171968.162 559165.342 171971.375 559167.738 171972.129 559168.383 171971.384 559169.265 171970.694 559168.643 171967.463 559166.304 171968.162 559165.342</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4b288e96-8f04-20c4-78d9-1d9a88251b4e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-16</terminationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2021-09-16T16:04:53</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.efab9ff6cf76406c81e870f17da76d6c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171968.162 559165.342 171971.375 559167.738 171972.129 559168.383 171971.384 559169.265 171970.694 559168.643 171967.463 559166.304 171968.162 559165.342</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b59c4d23c-9a34-eb6f-39fd-3436a399b4e1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2021-09-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-09-21T16:40:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2021-09-16T16:04:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f92bfe194b92483f818879881e282257</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171967.463 559166.304 171968.162 559165.342 171971.375 559167.738 171972.129 559168.383 171971.384 559169.265 171967.463 559166.304</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b5d53e266-eee8-de1e-cb37-6dab927ec4d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-17T11:20:45</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.48b15d3470b64a09977f8cbc96abb314</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171875.833 559942.115 171875.929 559942.000 171876.342 559941.504 171876.691 559941.086 171876.988 559940.730 171877.011 559940.702 171875.897 559939.774 171876.057 559939.582 171877.171 559940.510 171879.732 559937.437 171880.186 559936.892 171880.532 559936.476 171880.628 559936.361 171882.698 559938.086 171886.447 559941.210 171882.050 559943.426 171879.179 559944.903 171877.730 559943.696 171875.833 559942.115</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b636f5cf9-59d8-d062-5779-dd63180801a1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2025-03-17T11:20:45.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.48b15d3470b64a09977f8cbc96abb314</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">landhoofd</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171877.171 559940.510 171879.732 559937.437 171880.186 559936.892 171880.532 559936.476 171880.628 559936.361 171882.698 559938.086 171886.447 559941.210 171882.050 559943.426 171879.179 559944.903 171877.730 559943.696 171875.833 559942.115 171875.929 559942.000 171876.342 559941.504 171876.691 559941.086 171876.988 559940.730 171877.011 559940.702 171877.171 559940.510</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">viaduct</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b69968233-ad10-cc1f-c859-4153e8377b30">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-10T14:45:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2024-10-31T12:43:47.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7f50f54bf7ee4975ab6600b14f1584b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173470.203 559500.222 173466.133 559500.436 173466.030 559498.730 173470.107 559498.509 173484.445 559497.732 173488.604 559497.506 173488.696 559499.247 173484.526 559499.467 173470.203 559500.222</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9dedb7b2-11fa-de0e-5983-7fc71087e278">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-11T13:48:05</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-05T11:10:57.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.16a257686ad14f089a2b0f377e31c54c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173801.442 559976.900 173804.634 559979.042 173803.544 559980.675 173797.921 559989.097 173797.531 559989.681 173796.673 559990.966 173793.498 559988.733 173794.719 559986.914 173800.332 559978.554 173801.442 559976.900</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b5b836aeb-b07f-b54b-16f5-84ae33e83440">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-06-13</terminationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-06-13T12:10:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e73ca268636a49d68ce3d0df402b765f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172907.014 559037.305 172907.075 559039.010 172895.120 559039.268 172895.146 559037.499 172907.014 559037.305</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b29731bc5-fb6e-1ef8-c288-dd0ea33b0e41">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-06-13</terminationDate>
            <imgeo:LV-publicatiedatum>2025-07-11T11:46:48</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-06-13T12:10:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e73ca268636a49d68ce3d0df402b765f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172907.014 559037.305 172907.075 559039.010 172895.120 559039.268 172895.146 559037.499 172907.014 559037.305</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bedf60002-9fbb-4d83-15c2-721cbcc0e4d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-12-05T11:10:57</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.16a257686ad14f089a2b0f377e31c54c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173801.442 559976.900 173804.634 559979.042 173803.544 559980.675 173797.921 559989.097 173796.673 559990.966 173793.498 559988.733 173794.719 559986.914 173800.332 559978.554 173801.442 559976.900</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bc9c5eb62-654c-8929-2bd0-e1a29975a306">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2020-12-29T14:22:10</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:33:42.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.83330dcbc05f41619eb777406413d3f7</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173814.555 559529.231 173824.161 559510.954 173826.813 559512.377 173817.392 559530.753 173814.555 559529.231</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b71073e52-0290-6538-773c-1432e147a1e1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cb8f68b906534c8e836f3252e9214194</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173711.093 558856.883 173711.632 558856.893 173711.664 558858.870 173711.283 558858.892 173703.943 558859.056 173703.555 558859.065 173703.553 558857.098 173704.356 558857.063 173711.093 558856.883</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b056a7e34-9770-1ed2-cb6c-ca512d3dacf9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cb5c6099d7c64f9586a676f3b3a844e4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173654.529 558858.376 173654.531 558860.263 173654.116 558860.365 173646.921 558860.561 173646.489 558860.572 173646.414 558858.618 173646.774 558858.596 173654.083 558858.383 173654.529 558858.376</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9a8ed4eb-9e08-e4f9-c4df-c74e07bdc899">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-12T12:43:40</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.6ed2b1debf194cef9dd57305ae44b628</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173512.799 558751.639 173513.403 558754.667 173512.656 558754.843 173511.908 558755.013 173511.159 558755.179 173504.851 558756.373 173498.488 558757.220 173492.087 558757.716 173491.233 558757.756 173490.378 558757.789 173489.523 558757.816 173489.291 558754.764 173490.101 558754.737 173490.910 558754.705 173491.719 558754.667 173498.098 558754.169 173504.439 558753.318 173510.724 558752.116 173511.417 558751.961 173512.108 558751.802 173512.799 558751.639</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b840af19a-5c04-9314-3196-420d03c31880">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:57:11</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-07T00:02:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.aaa3b0c921ff4bcd8ef7bfb874a0e6d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173525.433 559520.739 173525.884 559520.027 173526.789 559520.674 173532.468 559524.727 173532.650 559524.857 173532.448 559525.175 173532.420 559525.172 173525.433 559520.740 173525.428 559520.736 173525.433 559520.739</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bb17442c4-a912-106e-29b3-cce71ceb3a67">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.aaa3b0c921ff4bcd8ef7bfb874a0e6d6</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173525.433 559520.739 173525.884 559520.027 173526.789 559520.674 173532.468 559524.727 173532.650 559524.857 173532.448 559525.175 173532.420 559525.172 173525.433 559520.740 173525.428 559520.736 173525.433 559520.739</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b0ec185fb-9823-27ca-c3e0-8505becb9bbe">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-03-24T12:16:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2bf36245a2dd46b296997bde085d3209</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173525.433 559520.740 173532.420 559525.172 173524.452 559537.699 173517.508 559533.299 173525.433 559520.740</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b76dd33fc-9a18-8bfd-7114-fb87bd383646">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:43:47</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:17.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7f50f54bf7ee4975ab6600b14f1584b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173466.030 559498.730 173488.604 559497.506 173488.696 559499.247 173466.133 559500.436 173466.030 559498.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b2565e9f8-fd51-dcb0-97b5-3891c5be08be">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:17</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7f50f54bf7ee4975ab6600b14f1584b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173466.030 559498.730 173488.604 559497.506 173488.696 559499.247 173466.133 559500.436 173466.030 559498.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b1b123b8b-06f9-ad78-ec32-73dabb488707">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2024-11-05T15:01:04</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-10-31T12:43:47.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f2b2a8735f124ccdbdfb033dc867ce80</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173470.732 559509.676 173470.665 559508.222 173468.390 559467.834 173468.284 559463.753 173469.384 559463.749 173469.680 559467.799 173481.598 559467.311 173481.476 559463.073 173482.607 559463.048 173483.021 559467.255 173483.421 559475.822 173484.968 559508.923 173470.732 559509.676</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b69ea20d6-f4c0-6b4a-d45f-2f10f068a331">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-10-31T12:43:47</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.f2b2a8735f124ccdbdfb033dc867ce80</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173474.585 559508.606 173472.192 559508.751 173471.506 559508.793 173470.698 559508.842 173470.665 559508.222 173470.326 559501.743 173467.768 559463.827 173468.284 559463.753 173469.156 559463.715 173469.680 559467.799 173470.615 559467.750 173472.500 559467.649 173473.375 559467.603 173473.590 559467.592 173480.731 559467.214 173480.687 559466.435 173480.498 559463.078 173481.476 559463.073 173482.028 559463.052 173484.253 559508.019 173483.776 559508.048 173482.758 559508.110 173479.392 559508.314 173475.542 559508.548 173474.585 559508.606</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b94c232f1-a450-de47-7271-2ebd1db0bbc4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-08-13T12:09:36</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-11-16T08:56:28.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2d841016231b48d7bbdced5f7cdbf4a9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172547.222 559213.362 172547.961 559213.294 172551.969 559212.923 172553.957 559212.740 172554.352 559212.703 172554.116 559213.119 172554.000 559213.541 172553.963 559214.583 172554.196 559217.619 172554.473 559221.227 172554.711 559221.843 172555.084 559222.494 172555.084 559222.495 172554.970 559222.502 172554.787 559222.515 172547.883 559222.981 172547.637 559222.997 172547.502 559223.000 172547.677 559222.528 172547.859 559221.822 172547.483 559216.649 172547.439 559215.164 172547.301 559214.319 172547.133 559213.780 172546.920 559213.388 172547.033 559213.379 172547.222 559213.362</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4b1517d9-acdf-ebf2-8815-1d2d0bb9ab05">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-08-13T12:09:36.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2d841016231b48d7bbdced5f7cdbf4a9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172547.222 559213.362 172547.961 559213.294 172551.969 559212.923 172553.957 559212.740 172554.352 559212.703 172554.116 559213.119 172554.000 559213.541 172553.963 559214.583 172554.196 559217.619 172554.473 559221.227 172554.711 559221.843 172555.284 559222.869 172555.023 559222.888 172547.840 559223.416 172547.289 559223.457 172547.677 559222.528 172547.859 559221.822 172547.483 559216.649 172547.439 559215.164 172547.301 559214.319 172547.133 559213.780 172546.920 559213.388 172547.033 559213.379 172547.222 559213.362</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b07d015cb-792e-8555-bd9e-dc0fb4a8726b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:32:08.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.2e3c8e4acf9c4b268c7add4a24399ae9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172964.911 559629.105 172966.015 559616.981 172968.007 559617.153 172971.347 559617.441 172969.945 559629.519 172966.973 559629.274 172964.911 559629.105</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bac16e522-f5aa-1602-b9c2-1872dbea352d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-11-17T22:22:36</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-09-15T15:21:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8b3a0082bd40444582b4c416957540b4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173002.598 559633.352 172994.189 559634.118 172991.043 559634.404 172982.433 559635.188 172980.609 559635.354 172982.074 559616.408 172984.846 559616.140 172993.694 559615.285 172996.780 559614.987 173004.568 559614.235 173006.143 559614.083 173004.684 559633.162 173002.598 559633.352</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6d07a755-59cf-47c8-ed38-9a37b8d13f65">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2016-09-15T15:21:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2015-12-08T14:18:53.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8b3a0082bd40444582b4c416957540b4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173002.450 559634.605 172994.564 559635.254 172991.595 559635.657 172983.665 559636.126 172982.512 559636.179 172982.435 559636.745 172980.616 559636.774 172980.912 559634.550 172981.080 559631.004 172981.235 559627.751 172982.058 559617.775 172982.104 559617.094 172985.126 559617.029 172985.944 559617.012 172993.805 559616.408 172996.543 559616.225 173004.630 559615.537 173004.560 559616.151 173006.483 559616.315 173005.394 559629.342 173005.134 559632.441 173004.942 559634.741 173002.450 559634.605</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6caac1c2-51fe-be51-3020-1d426f9f697e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T21:00:07</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ed2242c0bae04460a84b6e73cbc4e6c1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173023.197 559497.782 173013.603 559498.260 173012.124 559498.331 173012.093 559497.745 173013.548 559497.675 173015.078 559497.601 173021.287 559497.302 173023.281 559497.230 173023.197 559497.782</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6434c21e-da07-5b00-eabc-349a7ea2d059">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T21:00:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.ed2242c0bae04460a84b6e73cbc4e6c1</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173023.197 559497.782 173013.603 559498.260 173012.124 559498.331 173012.093 559497.745 173013.548 559497.675 173015.078 559497.601 173021.287 559497.302 173023.281 559497.230 173023.197 559497.782</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4e2ab695-75ce-a8cb-bed7-6273ae966a50">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:29</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0fec914b25f146c689c2f7931467cf52</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173024.076 559521.104 173014.416 559521.568 173013.243 559497.740 173022.914 559497.274 173024.076 559521.104</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9d458942-aba3-cf17-4449-99f8d050eb5a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:29.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0fec914b25f146c689c2f7931467cf52</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173024.076 559521.104 173014.416 559521.568 173013.243 559497.740 173022.914 559497.274 173024.076 559521.104</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b5291f40d-e6e3-9fad-4e45-81f4c6a113ac">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:54:41</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.711e24dd73b7436eb5e5dd23b3771ed5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173014.470 559521.617 173013.673 559521.656 173013.658 559521.104 173015.485 559521.019 173022.976 559520.643 173024.319 559520.555 173024.405 559521.127 173022.544 559521.228 173016.258 559521.530 173014.470 559521.617</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b28d6f2d4-5cb3-2e83-8048-7e661bfbc53a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:54:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.711e24dd73b7436eb5e5dd23b3771ed5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173014.470 559521.617 173013.673 559521.656 173013.658 559521.104 173015.485 559521.019 173022.976 559520.643 173024.319 559520.555 173024.405 559521.127 173022.544 559521.228 173016.258 559521.530 173014.470 559521.617</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b86477cc2-4324-e276-2755-8332a4297805">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:53:51</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5d05b070d26049bc9e16f85d47194b8e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172971.650 559523.705 172969.837 559523.822 172969.864 559523.187 172973.034 559523.054 172980.627 559522.692 172980.598 559523.292 172979.763 559523.326 172978.120 559523.393 172971.650 559523.705</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bb47a3be1-1db1-289b-f72e-6ac2c06e9b97">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:53:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.5d05b070d26049bc9e16f85d47194b8e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172971.650 559523.705 172969.837 559523.822 172969.864 559523.187 172973.034 559523.054 172980.627 559522.692 172980.598 559523.292 172979.763 559523.326 172978.120 559523.393 172971.650 559523.705</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b700aaf0f-6dbb-5ef0-5af1-5b5ae8011188">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:55:07</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7b643d077d494c2fb7c5969531ce3d4e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172978.901 559499.393 172979.247 559507.401 172979.385 559510.397 172979.601 559515.393 172979.812 559519.888 172979.947 559523.255 172970.299 559523.717 172969.154 559499.925 172978.901 559499.393</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bf2c8e674-0ec3-1757-4bb2-9641b698312c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:55:07.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7b643d077d494c2fb7c5969531ce3d4e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172978.901 559499.393 172979.247 559507.401 172979.385 559510.397 172979.601 559515.393 172979.812 559519.888 172979.947 559523.255 172970.299 559523.717 172969.154 559499.925 172978.901 559499.393</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b38694ca4-e354-fc3a-d866-0be830549add">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:57:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b5d0eacac8d446d0ae93182c1332ba87</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172980.014 559499.876 172971.151 559500.295 172968.790 559500.431 172968.739 559499.909 172970.794 559499.786 172976.966 559499.449 172978.463 559499.368 172978.572 559499.361 172979.945 559499.291 172980.014 559499.876</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4d0ca4bd-d456-0b0d-d435-587d8526d4f4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:57:49.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b5d0eacac8d446d0ae93182c1332ba87</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172980.014 559499.876 172971.151 559500.295 172968.790 559500.431 172968.739 559499.909 172970.794 559499.786 172976.966 559499.449 172978.463 559499.368 172978.572 559499.361 172979.945 559499.291 172980.014 559499.876</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b52280c2d-e730-a681-5ac8-9c2f23ccc42d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:50:24</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0da43f77cc214d9ba25596a865ec9f32</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172961.877 559538.028 172961.224 559538.094 172961.198 559537.741 172960.173 559523.844 172960.169 559523.794 172960.821 559523.771 172960.952 559525.536 172961.753 559536.350 172961.877 559538.028</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b4bc1e3d0-edda-7470-8d0c-6966c766475c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:50:24.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.0da43f77cc214d9ba25596a865ec9f32</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172961.877 559538.028 172961.224 559538.094 172961.198 559537.741 172960.173 559523.844 172960.169 559523.794 172960.821 559523.771 172960.952 559525.536 172961.753 559536.350 172961.877 559538.028</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b1c5e234f-9009-0339-4312-eb95a3467133">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:58:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.cee4c771d72e4fe7a66d7b8ba242c900</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172948.453 559501.239 172947.782 559501.276 172947.657 559499.587 172946.923 559489.726 172946.830 559488.479 172946.775 559487.809 172947.435 559487.633 172947.463 559487.941 172947.488 559488.273 172948.453 559501.239</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b89b3edd9-c179-46d5-031b-3e2cdae23959">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:58:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.cee4c771d72e4fe7a66d7b8ba242c900</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172948.453 559501.239 172947.782 559501.276 172947.657 559499.587 172946.923 559489.726 172946.830 559488.479 172946.775 559487.809 172947.435 559487.633 172947.463 559487.941 172947.488 559488.273 172948.453 559501.239</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="be1f7058f-7f3b-1beb-a765-6e72764833fb">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:49:56</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.07338982104140459e3e773e2262032f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172952.362 559536.764 172951.699 559536.784 172951.568 559534.979 172950.907 559525.839 172950.791 559524.240 172951.450 559524.223 172951.453 559524.267 172952.346 559536.492 172952.362 559536.764</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="be042cef2-d64b-77ae-c0f6-db3c3752e188">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:49:56.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.07338982104140459e3e773e2262032f</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172952.362 559536.764 172951.699 559536.784 172951.568 559534.979 172950.907 559525.839 172950.791 559524.240 172951.450 559524.223 172951.453 559524.267 172952.346 559536.492 172952.362 559536.764</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b0c7d2101-a7dd-97ed-1752-175dd01227d1">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.27fe7b8ddebc446b81c76cc70cfc0c67</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172961.808 559537.777 172951.718 559536.353 172950.849 559524.346 172960.778 559523.865 172961.808 559537.777</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="ba9f03b25-a97d-f96d-f9fa-04080771a387">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-21</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.723a05f68da74eab8813336c8a7a2f60</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172950.928 559486.776 172952.134 559486.300 172953.278 559485.799 172954.492 559485.238 172955.710 559484.607 172956.898 559483.953 172957.796 559483.464 172957.826 559483.801 172958.909 559500.676 172947.830 559501.222 172946.880 559488.475 172946.851 559488.127 172948.444 559487.642 172949.723 559487.221 172950.928 559486.776</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b22b50f35-8cd2-a549-1c5c-73854e50cad9">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:54:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-06T23:59:03.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.784a65b7048940bc9101358ed475ac5d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172957.194 559483.566 172957.185 559483.473 172957.831 559483.301 172957.876 559483.797 172957.965 559485.178 172958.345 559491.104 172958.555 559494.385 172958.854 559499.043 172958.962 559500.722 172958.303 559500.777 172957.237 559484.161 172957.220 559483.889 172957.220 559483.884 172957.218 559483.861 172957.202 559483.661 172957.201 559483.646 172957.194 559483.566</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b21709e20-1f85-b8b2-b81b-508287618b32">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-11-19T20:54:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.784a65b7048940bc9101358ed475ac5d</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172957.194 559483.566 172957.185 559483.473 172957.831 559483.301 172957.876 559483.797 172957.965 559485.178 172958.345 559491.104 172958.555 559494.385 172958.854 559499.043 172958.962 559500.722 172958.303 559500.777 172957.237 559484.161 172957.220 559483.889 172957.220 559483.884 172957.218 559483.861 172957.202 559483.661 172957.201 559483.646 172957.194 559483.566</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b10cd5044-2bec-9a7f-8e15-94a38f7fbca0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1b6161acff24189a542ea1189f02c93</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172375.335 558999.603 172384.991 558993.529 172385.557 558993.145 172385.734 558993.043 172386.646 558994.468 172380.012 558998.773 172374.861 559001.814 172373.835 559000.474 172375.335 558999.603</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b9cd879c2-851a-f4de-06e9-0b9a59f69601">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2015-08-03T00:00:00.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a8cbdba9b4774d9cb437acd667de2653</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172461.604 559212.566 172463.142 559213.728 172455.088 559223.594 172453.768 559222.643 172461.604 559212.566</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bd4374b6f-b56f-fc9f-4e8e-7463c61b2f72">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2016-12-11T13:46:02</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>true</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2020-11-19T20:59:59</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2016-12-01T13:58:09.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.eaadcceed2554f94bab12d75f3644b5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172506.014 559581.827 172490.244 559586.331 172489.646 559584.397 172505.458 559579.941 172506.014 559581.827</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b43dff9b8-bd49-4179-02f5-072d2631ec1c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2020-11-20T16:38:58</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2023-03-10T12:09:12</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2020-11-19T20:59:59.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.eaadcceed2554f94bab12d75f3644b5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172506.014 559581.827 172490.244 559586.331 172489.646 559584.397 172505.458 559579.941 172506.014 559581.827</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b6bde8068-7de1-c963-f656-c372d87d0e5c">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2023-03-10T12:16:23</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2023-03-10T12:09:12.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.eaadcceed2554f94bab12d75f3644b5b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">pijler</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172506.014 559581.827 172490.244 559586.331 172489.646 559584.397 172505.458 559579.941 172506.014 559581.827</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bae268683-45d4-16a0-895d-11c0e9876139">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2015-08-03</creationDate>
            <imgeo:LV-publicatiedatum>2016-08-08T10:13:11</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2016-03-24T13:29:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.cd326a95ed574c71b6bab5b8e625d297</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172487.831 559552.960 172487.832 559552.960 172491.426 559551.898 172491.432 559551.896 172492.396 559551.650 172492.458 559551.861 172493.433 559551.585 172492.315 559547.588 172492.744 559547.495 172493.285 559547.377 172494.740 559552.677 172495.830 559556.604 172504.790 559588.438 172505.626 559591.410 172506.130 559593.202 172506.346 559593.969 172508.163 559600.426 172508.375 559601.104 172508.596 559601.811 172507.693 559602.085 172507.577 559601.672 172506.695 559601.920 172505.471 559602.264 172502.002 559603.240 172500.637 559603.624 172500.060 559603.786 172499.133 559604.047 172499.254 559604.421 172498.391 559604.660 172497.955 559603.274 172495.665 559595.092 172495.461 559594.362 172495.138 559593.209 172494.138 559589.635 172485.811 559559.878 172484.594 559555.529 172484.496 559555.557 172483.052 559550.228 172483.967 559549.948 172485.078 559553.944 172485.974 559553.691 172486.393 559553.573 172486.345 559553.399 172487.831 559552.960</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="b002f3f0e-52ee-653b-b5d6-36fc0eff6870">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2020-06-16</creationDate>
            <imgeo:LV-publicatiedatum>2021-01-21T11:56:29</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2020-06-16T14:30:02.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.e480ba3829ad497798446ed9f425b456</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbruggingsdeel">dek</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172472.720 559610.932 172474.677 559607.263 172475.327 559606.112 172492.438 559615.139 172491.802 559616.394 172490.105 559619.739 172472.720 559610.932</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:overbruggingIsBeweegbaar>false</imgeo:overbruggingIsBeweegbaar>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeOverbrugging">brug</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
    <cityObjectMember>
        <BridgeConstructionElement xmlns="http://www.opengis.net/citygml/bridge/2.0" gml:id="bcdf2abd0-682a-53c8-b319-b617be2adc33">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2016-12-01</creationDate>
            <imgeo:LV-publicatiedatum>2024-12-10T14:54:38</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-12-10T14:45:41.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.7f50f54bf7ee4975ab6600b14f1584b2</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0002</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <class codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</class>
            <imgeo:geometrie2dOverbruggingsdeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">173466.030 559498.730 173488.604 559497.506 173488.696 559499.247 173466.133 559500.436 173466.030 559498.730</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dOverbruggingsdeel>
            <imgeo:hoortBijTypeOverbrugging codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">waardeOnbekend</imgeo:hoortBijTypeOverbrugging>
        </BridgeConstructionElement>
    </cityObjectMember>
</CityModel>