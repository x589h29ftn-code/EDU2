<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <BuildingInstallation xmlns="http://www.opengis.net/citygml/building/2.0" gml:id="b5b6cd328-8451-b952-93f4-d40aa66e030d">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-19</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-19T15:49:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2843a3dfb3054ecfa0e4e319497dfa8b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatie">niet-bgt</function>
            <imgeo:geometrie2dGebouwInstallatie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171906.897 559965.736 171909.097 559967.905 171908.395 559968.617 171906.255 559966.507 171906.642 559966.042 171906.897 559965.736</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dGebouwInstallatie>
            <imgeo:plus-typeGebouwInstallatie codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatiePlus">toegangstrap</imgeo:plus-typeGebouwInstallatie>
        </BuildingInstallation>
    </cityObjectMember>
    <cityObjectMember>
        <BuildingInstallation xmlns="http://www.opengis.net/citygml/building/2.0" gml:id="b987daf27-1d8d-333a-179e-774a81aef413">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-19</terminationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-19T15:49:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.2843a3dfb3054ecfa0e4e319497dfa8b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatie">niet-bgt</function>
            <imgeo:geometrie2dGebouwInstallatie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171906.897 559965.736 171909.097 559967.905 171908.395 559968.617 171906.255 559966.507 171906.642 559966.042 171906.897 559965.736</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dGebouwInstallatie>
            <imgeo:plus-typeGebouwInstallatie codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatiePlus">toegangstrap</imgeo:plus-typeGebouwInstallatie>
        </BuildingInstallation>
    </cityObjectMember>
    <cityObjectMember>
        <BuildingInstallation xmlns="http://www.opengis.net/citygml/building/2.0" gml:id="b05275584-ae90-3209-8b3f-15a00f244b36">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-19</terminationDate>
            <imgeo:LV-publicatiedatum>2022-06-03T10:16:53</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-19T15:49:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.c99f828b3b3e4266b4fd20e63a05caa9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatie">niet-bgt</function>
            <imgeo:geometrie2dGebouwInstallatie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171876.691 559941.086 171876.342 559941.504 171873.790 559939.879 171874.327 559939.036 171876.988 559940.730 171876.691 559941.086</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dGebouwInstallatie>
            <imgeo:plus-typeGebouwInstallatie codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatiePlus">toegangstrap</imgeo:plus-typeGebouwInstallatie>
        </BuildingInstallation>
    </cityObjectMember>
    <cityObjectMember>
        <BuildingInstallation xmlns="http://www.opengis.net/citygml/building/2.0" gml:id="bc9e74da1-a15c-2a29-e13e-99d37e2044a4">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2022-06-01</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2025-03-19</terminationDate>
            <imgeo:LV-publicatiedatum>2025-03-19T16:03:30</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2025-03-19T15:49:16</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2022-06-03T08:55:04.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0004.c99f828b3b3e4266b4fd20e63a05caa9</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>L0004</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatie">niet-bgt</function>
            <imgeo:geometrie2dGebouwInstallatie><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">171876.691 559941.086 171876.342 559941.504 171873.790 559939.879 171874.327 559939.036 171876.988 559940.730 171876.691 559941.086</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dGebouwInstallatie>
            <imgeo:plus-typeGebouwInstallatie codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeGebouwInstallatiePlus">toegangstrap</imgeo:plus-typeGebouwInstallatie>
        </BuildingInstallation>
    </cityObjectMember>
</CityModel>