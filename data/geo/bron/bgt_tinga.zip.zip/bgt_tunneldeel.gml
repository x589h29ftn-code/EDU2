<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="b90f8ba38-ddad-aef6-4708-bf78fec9cef7">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-05-11</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-05-11T15:17:31.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.63d347c4d1dc4eee803a9d4f898c5358</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172954.845 559527.844 172952.915 559527.970 172950.422 559493.582 172950.727 559493.264 172952.854 559493.082 172954.845 559527.844</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="be2574058-2c4f-1d4b-ebbb-66c0a87d3864">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-05-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.63d347c4d1dc4eee803a9d4f898c5358</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172955.213 559528.121 172953.342 559528.243 172950.736 559493.364 172952.658 559493.199 172955.213 559528.121</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="b378204bd-ca12-4eec-345d-6e31df4760bc">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-05-11</creationDate>
            <imgeo:LV-publicatiedatum>2018-01-08T17:11:19</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2024-01-25T10:53:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2017-05-11T15:16:58.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a7db1eacb16d4fc2bba2891060776f44</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172954.845 559527.844 172952.854 559493.082 172956.270 559492.789 172956.762 559493.190 172959.315 559527.552 172954.845 559527.844</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="b73e787e2-f750-a031-25c8-536f43b2574a">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2017-05-11</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a7db1eacb16d4fc2bba2891060776f44</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172955.213 559528.121 172952.658 559493.199 172956.279 559492.889 172958.940 559527.877 172955.213 559528.121</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="b4429e6d2-2ec2-d7ca-f487-3d7cb16a65da">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.b9895b1e679045948e99e506e275c592</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172960.260 559546.426 172956.497 559546.650 172956.035 559539.346 172959.842 559539.118 172960.260 559546.426</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
    <cityObjectMember>
        <TunnelPart xmlns="http://www.opengis.net/citygml/tunnel/2.0" gml:id="b0b82f9bf-f221-e64d-621b-5b4d21e84436">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2023-12-20</creationDate>
            <imgeo:LV-publicatiedatum>2024-01-29T13:15:27</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>-1</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:tijdstipRegistratie>2024-01-25T10:53:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>L0002.c14a331f8ff549c3831fc59375eebe2a</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <imgeo:geometrie2dTunneldeel><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:exterior><gml:LinearRing><gml:posList srsDimension="2">172956.497 559546.650 172954.802 559546.751 172954.253 559539.453 172956.035 559539.346 172956.497 559546.650</gml:posList></gml:LinearRing></gml:exterior></gml:Polygon></imgeo:geometrie2dTunneldeel>
        </TunnelPart>
    </cityObjectMember>
</CityModel>