<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:gml="http://www.opengis.net/gml" xmlns:imgeo="http://www.geostandaarden.nl/imgeo/2.1" xmlns="http://www.opengis.net/citygml/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/imgeo/2.1 http://register.geostandaarden.nl/gmlapplicatieschema/imgeo/2.1.1/imgeo.xsd">
    <cityObjectMember>
        <imgeo:Bak gml:id="b8ef36ae1-f9ae-5a76-a85a-9307e84caf7e">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T11:44:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:23:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0305b0cff66349fcaf1554290648f34b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171422.363 558012.071</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b16b5192b-5533-d996-5540-67501301b6e5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T13:54:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:23:55.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.0305b0cff66349fcaf1554290648f34b</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171422.363 558012.071</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="be0a55e50-be92-c0df-8241-c3f3ab3addfa">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T13:54:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T09:42:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.27bff2010ad0439dac8734d5472cae20</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171426.843 558023.303</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="be3079ed9-7a3f-7f2b-54a3-70b365ea4949">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T11:44:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:08:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1d6c97f870c4eee843da8cf1ad7157c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171417.509 558011.118</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="be7760c65-c9b1-b2ea-01bb-29f5a85b3eaf">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T13:54:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:08:11.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1d6c97f870c4eee843da8cf1ad7157c</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171417.509 558011.118</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b1935dbad-4388-2264-af80-7e83ba51426b">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T11:44:31</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:19:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a9fc88e671f84473851e88f80a7fda8e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171420.080 558011.638</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="bb91b23a5-814a-d34d-cdc1-fc9a83e833a2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-08</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T13:54:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-08T10:19:32.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a9fc88e671f84473851e88f80a7fda8e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171420.080 558011.638</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="be22fc0c6-ddb6-54ea-1f3a-9c8dbb9a97ad">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-15</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T14:50:22</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-15T14:12:05</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T14:46:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5c43ed1e8c8b47f39f89fc528af616be</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171431.468 558022.120</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b0bde0911-17d8-8586-1d61-2f20eb919807">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-15</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-15T14:16:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-15T14:12:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T15:39:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1fe40bbe54f49eb94657627402ce20e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171434.405 558022.519</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b84405244-b0be-6c56-2fa4-d809d586a5c5">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-24</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-16T10:29:41</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-24T16:23:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-16T10:25:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d8c321d58ad148ae9b6ddfa7b92e9fd4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171437.846 558015.829</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b7baf5071-0c1e-823c-9736-3789ae0e7044">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-16</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-24</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-24T16:27:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-24T16:23:49</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-16T10:25:01.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.d8c321d58ad148ae9b6ddfa7b92e9fd4</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171437.846 558015.829</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b9c337770-45ff-9c0c-7c4f-68562a669eb0">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T09:50:50</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T09:42:37.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.27bff2010ad0439dac8734d5472cae20</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171426.843 558023.303</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="bbb893dc8-fb87-465a-a016-1fb2cdba9cc2">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T10:04:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T10:00:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8d72e4f68d674d26a8be068aa65ffeb5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171429.309 558024.106</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="be50b1fb2-acc9-d592-2a62-0e4cfbe5d6ed">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T13:54:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-14T13:48:52</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T10:00:51.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.8d72e4f68d674d26a8be068aa65ffeb5</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171429.309 558024.106</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b1b346dfa-3792-4412-7234-d08bea451fd3">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-15</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-15T14:16:52</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-15T14:12:05</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T14:46:44.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.5c43ed1e8c8b47f39f89fc528af616be</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171431.468 558022.120</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
    <cityObjectMember>
        <imgeo:Bak gml:id="b770bbc4a-0f9d-5a41-3341-e074ff740701">
                        <creationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-14</creationDate>
            <terminationDate xmlns="http://www.opengis.net/citygml/2.0">2026-04-15</terminationDate>
            <imgeo:LV-publicatiedatum>2026-04-14T15:44:32</imgeo:LV-publicatiedatum>
            <imgeo:relatieveHoogteligging>0</imgeo:relatieveHoogteligging>
            <imgeo:inOnderzoek>false</imgeo:inOnderzoek>
            <imgeo:eindRegistratie>2026-04-15T14:12:06</imgeo:eindRegistratie>
            <imgeo:tijdstipRegistratie>2026-04-14T15:39:52.000</imgeo:tijdstipRegistratie>
            <imgeo:identificatie>
                <imgeo:NEN3610ID>
                    <imgeo:namespace>NL.IMGeo</imgeo:namespace>
                    <imgeo:lokaalID>G1900.a1fe40bbe54f49eb94657627402ce20e</imgeo:lokaalID>
                </imgeo:NEN3610ID>
            </imgeo:identificatie>
            <imgeo:bronhouder>G1900</imgeo:bronhouder>
            <imgeo:bgt-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#Status">bestaand</imgeo:bgt-status>
            <imgeo:plus-status codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#VoidReasonValue">geenWaarde</imgeo:plus-status>
            <function xmlns="http://www.opengis.net/citygml/cityfurniture/2.0" codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBak">niet-bgt</function>
            <imgeo:plus-type codeSpace="http://www.geostandaarden.nl/imgeo/def/2.1#TypeBakPlus">afvalbak</imgeo:plus-type>
            <imgeo:geometrie2dBak><gml:Point xmlns:gml="http://www.opengis.net/gml" srsName="urn:ogc:def:crs:EPSG::28992"><gml:pos srsDimension="2">171434.405 558022.519</gml:pos></gml:Point></imgeo:geometrie2dBak>
        </imgeo:Bak>
    </cityObjectMember>
</CityModel>